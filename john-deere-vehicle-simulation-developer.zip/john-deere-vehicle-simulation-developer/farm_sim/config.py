import os

# General config / constants

WINDOW_SIZE = (1280, 720)

GRID_SIZE = 1.0
PLANT_SPACING = 1.0
CROP_GROW_SECONDS = 20.0
HARVEST_DISTANCE = 2.0

# Deere organization ID is resolved lazily to avoid requiring .env on import
_ORG_ID_CACHE = None

def get_org_id() -> int:
    """
    Get organization ID with lazy loading.
    Only attempts to load from API if .env is available.
    Falls back to default if .env is missing.
    """
    global _ORG_ID_CACHE
    if _ORG_ID_CACHE is not None:
        return _ORG_ID_CACHE
    
    env_value = os.getenv("JD_ORG_ID")
    if env_value:
        try:
            _ORG_ID_CACHE = int(env_value.strip())
            return _ORG_ID_CACHE
        except ValueError as exc:
            raise RuntimeError(f"Invalid JD_ORG_ID value: {env_value!r}") from exc
    
    # Try to get from API only if needed (when upload or John Deere field is used)
    try:
        from operations_center.org_service import get_primary_org_id
        _ORG_ID_CACHE = get_primary_org_id()
        return _ORG_ID_CACHE
    except Exception:
        # Fall back to legacy default if API lookup fails or .env is missing
        _ORG_ID_CACHE = 6175035
        return _ORG_ID_CACHE

# For backward compatibility - modules can import ORG_ID but it won't fail until used
# This allows the simulation to start without .env
class _LazyOrgId:
    """Lazy evaluation wrapper for ORG_ID"""
    def __int__(self):
        return get_org_id()
    
    def __str__(self):
        return str(get_org_id())
    
    def __repr__(self):
        return f"LazyOrgId({get_org_id()})"
    
    # Support comparison operations
    def __eq__(self, other):
        return get_org_id() == other
    
    def __ne__(self, other):
        return get_org_id() != other
    
    def __lt__(self, other):
        return get_org_id() < other
    
    def __le__(self, other):
        return get_org_id() <= other
    
    def __gt__(self, other):
        return get_org_id() > other
    
    def __ge__(self, other):
        return get_org_id() >= other
    
    def __hash__(self):
        return hash(get_org_id())

ORG_ID = _LazyOrgId()

# OpenGL clear color (sky)
CLEAR_COLOR = (0.55, 0.82, 0.98, 1.0)

# Time interval (seconds) between telemetry entries
LOG_INTERVAL = 0.25

# Directory to store generated telemetry files
LOG_DIR = "logs"

# Enable sample GPS fields for development/testing (disable for customers)
ENABLE_SAMPLE_GPS_FIELDS = False

# Season color palettes (RGB tuples, 0.0-1.0 range)
SEASON_COLORS = {
    "Spring": {
        "grass": (0.20, 0.45, 0.22),      # Fresh spring green
        "soil": (0.38, 0.25, 0.14),       # Light brown soil
        "soil_lines": (0.24, 0.16, 0.09), # Dark brown lines
        "cross_lines": (0.30, 0.20, 0.11),# Dark brown cross lines
        "grid_lines": (0.12, 0.22, 0.13), # Dark green grid
        "sky": (0.58, 0.85, 0.99),        # Bright spring blue sky
    },
    "Summer": {
        "grass": (0.10, 0.60, 0.12),      # Intense vibrant deep green
        "soil": (0.50, 0.38, 0.14),       # Rich saturated soil
        "soil_lines": (0.30, 0.20, 0.08), # Dark brown lines
        "cross_lines": (0.38, 0.25, 0.10),# Dark brown cross lines
        "grid_lines": (0.12, 0.30, 0.14), # Deep rich green grid
        "sky": (0.68, 0.92, 1.00),        # Intense bright summer sky
    },
    "Autumn": {
        "grass": (0.45, 0.35, 0.12),      # Deep golden-brown grass
        "soil": (0.58, 0.32, 0.10),       # Deep red-orange-brown soil
        "soil_lines": (0.50, 0.20, 0.05), # Deep dark red-brown lines
        "cross_lines": (0.55, 0.25, 0.08),# Deep warm red-brown cross lines
        "grid_lines": (0.38, 0.18, 0.06), # Deep dark red-brown grid
        "sky": (0.75, 0.70, 0.80),        # Warm autumn sky with orange cast
    },
    "Winter": {
        "grass": (0.72, 0.77, 0.80),      # Pale frosted grass
        "soil": (0.58, 0.60, 0.65),       # Gray-blue frozen soil
        "soil_lines": (0.42, 0.44, 0.48), # Dark gray lines
        "cross_lines": (0.50, 0.52, 0.56),# Dark gray cross lines
        "grid_lines": (0.38, 0.40, 0.44), # Dark gray grid
        "sky": (0.80, 0.86, 0.92),        # Pale, washed-out winter sky
    },
}

# Season-specific lighting and effects
SEASON_EFFECTS = {
    "Spring": {
        "ambient_light": (0.35, 0.35, 0.35),      # Soft ambient
        "diffuse_light": (0.90, 0.90, 0.90),      # Neutral white diffuse
        "crop_stem_color": (0.12, 0.70, 0.25),    # Bright green stems
        "crop_head_color": (0.95, 0.88, 0.15),    # Golden grain heads
        "fog_enabled": True,
        "fog_density": 0.15,
    },
    "Summer": {
        "ambient_light": (0.45, 0.45, 0.42),      # Warmer, stronger ambient
        "diffuse_light": (0.98, 0.96, 0.92),      # Warm white diffuse
        "crop_stem_color": (0.10, 0.62, 0.20),    # Deep rich green
        "crop_head_color": (0.98, 0.92, 0.08),    # Vibrant bright yellow
        "fog_enabled": False,
        "fog_density": 0.0,
    },
    "Autumn": {
        "ambient_light": (0.50, 0.40, 0.28),      # Warm golden ambient
        "diffuse_light": (0.95, 0.85, 0.70),      # Warm golden diffuse
        "crop_stem_color": (0.40, 0.32, 0.10),    # Gold-brownish stems
        "crop_head_color": (0.95, 0.68, 0.08),    # Golden-orange heads
        "fog_enabled": False,
        "fog_density": 0.0,
    },
    "Winter": {
        "ambient_light": (0.28, 0.30, 0.35),      # Cold blue ambient
        "diffuse_light": (0.75, 0.78, 0.85),      # Cool white diffuse
        "crop_stem_color": (0.55, 0.60, 0.50),    # Pale grey-green frosty stems
        "crop_head_color": (0.98, 0.98, 0.98),    # Frosty white heads
        "fog_enabled": True,
        "fog_density": 0.25,
    },
}
