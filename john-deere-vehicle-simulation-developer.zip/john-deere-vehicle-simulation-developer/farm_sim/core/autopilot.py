import math
from typing import List, Optional, Sequence, Tuple

from OpenGL.GL import *

from farm_sim.util import clamp
from farm_sim.world.obstacles import Obstacle, collision_radius

class AutoPilot:
    """
    Boustrophedon snake pattern with smooth semicircle turns,
    adapted from the working radius-based version.

    Key difference vs the old version:
    - Instead of using a single `field_radius`, we take `field_w` and `field_h`
      and convert them into "usable" min/max x/z bounds.
    """
    MAX_DETOUR_DEPTH = 3
    DETOUR_PADDING = 0.8
    def __init__(self, field_w, field_h,
                 lane_spacing=1.5,
                 margin=0.5,
                 turn_inset=4.0,
                 soil_margin=0.0,
                 extra_clearance: float = 0.0):
        # store full field dimensions
        self.field_w = field_w
        self.field_h = field_h

        # path params (same meaning as before)
        self.lane_spacing = lane_spacing
        self.margin = margin
        self.turn_inset = turn_inset
        self.soil_margin = max(0.0, soil_margin)
        # extra half-width we must keep away from obstacles (tractor + implement)
        self.extra_clearance = max(0.0, float(extra_clearance))

        # dynamics / control
        self.lookahead = 2.0
        self.v_straight = 7.0
        self.v_turn = 3.0

        # user-adjustable multiplier (K/M keys)
        self.speed_scale = 1.0

        # runtime state
        self.enabled = False
        self.show_path = False
        self.path = []
        self.idx = 0
        self.reached_end = False
        self.obstacles: Sequence[Obstacle] = ()
        half_w = self.field_w * 0.5
        half_h = self.field_h * 0.5
        self._usable_bounds: Tuple[float, float, float, float] = (-half_w, half_w, -half_h, half_h)

    # --- speed scaling controls (keep EXACTLY like your good version) ---
    # def increase_speed_scale(self, amount=0.2):
    #     self.speed_scale = min(5.0, self.speed_scale + amount)

    # def decrease_speed_scale(self, amount=0.2):
    #     self.speed_scale = max(0.2, self.speed_scale - amount)
    # --------------------------------------------------------------------

    def _semi_arc(self, x_left, x_right, z_const, bulge_sign=+1, steps=28):
        """
        Semicircle from (x_left, z_const) -> (x_right, z_const),
        bulging in +Z (bulge_sign=+1) or -Z (bulge_sign=-1).

        EXACT math from your working code:
        - Start at left lane
        - Sweep theta from π -> 0
        => no 'flat chord' before the arc, no diagonal.
        """
        cx = (x_left + x_right) / 2.0
        R  = (x_right - x_left) / 2.0
        pts = []
        for i in range(steps + 1):
            theta = math.pi - (math.pi * i / steps)  # π → 0 (left → right)
            x = cx + R * math.cos(theta)
            z = z_const + bulge_sign * R * math.sin(theta)
            pts.append((x, z))
        return pts

    def _push(self, x, z):
        """Append (x,z) only if it differs from the prev point. (same as before)"""
        if self.path:
            px, pz = self.path[-1]
            if abs(px - x) < 1e-6 and abs(pz - z) < 1e-6:
                return
        self.path.append((x, z))

    def build_path(self, obstacles: Optional[Sequence[Obstacle]] = None):
        if obstacles is not None:
            self.obstacles = tuple(obstacles)
        """
        This is your old build_path(), but instead of using a circle radius r,
        we derive rectangular bounds and feed them into the same algorithm.

        OLD meaning:
            Rf = self.r - self.margin
            x0,x1 = -Rf, +Rf
            z0,z1 = -Rf, +Rf
            z_start = z0 + self.turn_inset
            z_end   = z1 - self.turn_inset

        NEW meaning:
            -x goes from left usable boundary to right usable boundary
            -z goes from bottom usable boundary to top usable boundary
        """

        # half extents
        half_w = self.field_w * 0.5
        half_h = self.field_h * 0.5

        # working "usable" region after outer margin (clamped to soil band)
        safe_margin = max(self.margin, self.soil_margin)
        x_left  = -half_w + safe_margin
        x_right =  half_w - safe_margin
        z_bot   = -half_h + safe_margin
        z_top   =  half_h - safe_margin
        self._usable_bounds = (x_left, x_right, z_bot, z_top)

        # Just like old z_start/z_end, we inset further for the turn semicircle
        z_start = z_bot + self.turn_inset   # "bottom lane end" we start from
        z_end   = z_top - self.turn_inset   # "top lane end"

        # lane spacing sanity (same logic you had)
        half_spacing = self.lane_spacing * 0.5
        if half_spacing > self.turn_inset:
            # if spacing is too big to fit a U-turn inside inset,
            # shrink spacing just like old code
            self.lane_spacing = max(1.0, 2.0 * (self.turn_inset - 0.1))
            half_spacing = self.lane_spacing * 0.5

        # reset path
        self.path = []
        self.idx = 0
        self.reached_end = False

        lane_x = x_left
        forward = True
        while lane_x <= x_right + 1e-6:
            lane_x_next = lane_x + self.lane_spacing

            # straight lane (unchanged logic)
            if forward:
                # bottom -> top
                self._push(lane_x, z_start)
                self._push(lane_x, z_end)
            else:
                # top -> bottom
                self._push(lane_x, z_end)
                self._push(lane_x, z_start)

            # U-turn via perfect semicircle (unchanged logic)
            if lane_x_next <= x_right + 1e-6:
                if forward:
                    # we ended at z_end (near the "top"); turn across the TOP
                    arc = self._semi_arc(lane_x, lane_x_next, z_end, bulge_sign=+1)
                else:
                    # we ended at z_start (near the "bottom"); turn across the BOTTOM
                    arc = self._semi_arc(lane_x, lane_x_next, z_start, bulge_sign=-1)

                for (ax, az) in arc:
                    self._push(ax, az)

            lane_x = lane_x_next
            forward = not forward

        raw_path = list(self.path)
        if self.obstacles:
            raw_path = self._avoid_obstacles(raw_path, self.obstacles)
        self.path = self._ensure_path_within_bounds(raw_path)
        self.idx = 0
        self.reached_end = False

    def toggle(self):
        self.enabled = not self.enabled
        if self.enabled and not self.path:
            self.build_path()

    def align_to_vehicle(self, tractor):
        """
        Snap the internal waypoint index to the segment closest to the tractor's
        current location. A temporary point is inserted when needed so the
        controller starts from the proper spot along the curve.
        """
        if not self.path:
            self.build_path()
        if len(self.path) < 2:
            return

        tx = getattr(tractor, "x", 0.0)
        tz = getattr(tractor, "z", 0.0)
        best_idx = 0
        best_t = 0.0
        best_dist = float("inf")

        for i in range(len(self.path) - 1):
            start = self.path[i]
            end = self.path[i + 1]
            dist_sq, t = self._distance_sq_to_segment((tx, tz), start, end)
            if dist_sq < best_dist:
                best_dist = dist_sq
                best_idx = i
                best_t = t

        end_dist = self._distance_sq_tuple((tx, tz), self.path[-1])
        if end_dist < best_dist:
            best_idx = len(self.path) - 2
            best_t = 1.0

        if best_t <= 1e-3:
            self.idx = best_idx
        elif best_t >= 1.0 - 1e-3:
            self.idx = best_idx + 1
        else:
            sx, sz = self.path[best_idx]
            ex, ez = self.path[best_idx + 1]
            insert_pt = (
                sx + (ex - sx) * best_t,
                sz + (ez - sz) * best_t,
            )
            self.path.insert(best_idx + 1, insert_pt)
            self.idx = best_idx + 1

        if self.idx >= len(self.path) - 1:
            self.idx = max(0, len(self.path) - 2)
        self.reached_end = False

    def teleport_to_start(self, tractor):
        """
        Same as before:
        Snap tractor to first two waypoints and orient yaw along the path.
        """
        if not self.path:
            self.build_path()
        if len(self.path) >= 2:
            (x0, z0), (x1, z1) = self.path[0], self.path[1]
            tractor.x, tractor.z = x0, z0

            dx, dz = x1 - x0, z1 - z0
            tractor.yaw = math.atan2(dx, -dz)  # same convention you used
            tractor.v = 0.0

            self.idx = 0
            self.reached_end = False

    def draw(self):
        if not self.show_path or not self.path:
            return
        glDisable(GL_LIGHTING)
        glLineWidth(2.0)
        glColor3f(1.0, 0.95, 0.2)
        glBegin(GL_LINE_STRIP)
        for (x, z) in self.path:
            glVertex3f(x, 0.003, z)
        glEnd()
        glEnable(GL_LIGHTING)
    def _avoid_obstacles(
        self,
        path: Sequence[Tuple[float, float]],
        obstacles: Sequence[Obstacle]
    ) -> List[Tuple[float, float]]:
        if len(path) < 2:
            return list(path)
        carved: List[Tuple[float, float]] = [path[0]]
        for target in path[1:]:
            start = carved[-1]
            carved.extend(self._reroute_segment(start, target, obstacles, depth=0))
        return carved

    def _reroute_segment(
        self,
        start: Tuple[float, float],
        end: Tuple[float, float],
        obstacles: Sequence[Obstacle],
        depth: int
    ) -> List[Tuple[float, float]]:
        if depth > self.MAX_DETOUR_DEPTH:
            return [end]
        blocker = self._first_blocker(start, end, obstacles)
        if not blocker:
            if self._distance_sq_tuple(start, end) < 1e-6:
                return []
            return [end]
        obs, t_hit, clearance = blocker
        detour_points = self._construct_detour(start, end, obs, t_hit, clearance)
        result: List[Tuple[float, float]] = []
        current = start
        for pt in detour_points:
            result.extend(self._reroute_segment(current, pt, obstacles, depth + 1))
            current = pt
        return result

    def _first_blocker(
        self,
        start: Tuple[float, float],
        end: Tuple[float, float],
        obstacles: Sequence[Obstacle]
    ):
        """Return the first obstacle (possibly merged) intersecting the segment."""
        closest = None
        closest_t = float("inf")
        for obs in obstacles:
            # Support both real Obstacle and MergedObstacle
            if hasattr(obs, "radius"):
                # merged virtual obstacle
                base = float(getattr(obs, "radius", 0.0))
            else:
                base = collision_radius(obs)

            clearance = base + self.DETOUR_PADDING + 0.5 + self.extra_clearance
            ox = getattr(obs, "x")
            oz = getattr(obs, "z")
            dist_sq, t = self._distance_sq_to_segment((ox, oz), start, end)
            if 0.0 <= t <= 1.0 and dist_sq <= clearance * clearance:
                if t < closest_t:
                    closest = (obs, t, clearance)
                    closest_t = t
        return closest

    def _construct_detour(
        self,
        start: Tuple[float, float],
        end: Tuple[float, float],
        obs: Obstacle,
        t_hit: float,
        clearance: float
    ) -> List[Tuple[float, float]]:
        """Build arc detour around either a single or merged obstacle."""
        sx, sz = start
        ex, ez = end
        dx = ex - sx
        dz = ez - sz
        seg_len = math.hypot(dx, dz)
        if seg_len < 1e-6:
            return [end]
        dir_x = dx / seg_len
        dir_z = dz / seg_len
        travel = t_hit * seg_len
        buffer = clearance + self.DETOUR_PADDING * 0.4
        entry_s = max(0.0, travel - buffer)
        exit_s = min(seg_len, travel + buffer)

        entry = self._clamp_to_bounds((sx + dir_x * entry_s, sz + dir_z * entry_s), inset=self.DETOUR_PADDING)
        exit = self._clamp_to_bounds((sx + dir_x * exit_s, sz + dir_z * exit_s), inset=self.DETOUR_PADDING)

        cx = getattr(obs, "x")
        cz = getattr(obs, "z")
        centre = (cx, cz)

        # For merged obstacles, obs.kind may not exist; treat as generic.
        if hasattr(obs, "kind") and str(getattr(obs, "kind", "")).lower() == "pond":
            extra_radius = 0.9
        else:
            extra_radius = 0.35

        avoid_radius = clearance + extra_radius
        entry = self._project_to_circle(entry, centre, avoid_radius)
        exit = self._project_to_circle(exit, centre, avoid_radius)

        rel_cx = cx - sx
        rel_cz = cz - sz
        cross = dir_x * rel_cz - dir_z * rel_cx
        direction = 1 if cross >= 0.0 else -1
        arc_points = self._arc_around(centre, entry, exit, avoid_radius, direction)

        points: List[Tuple[float, float]] = []
        if self._distance_sq_tuple(start, arc_points[0]) > 1e-6:
            points.append(arc_points[0])
        points.extend(arc_points[1:])
        if self._distance_sq_tuple(points[-1], end) > 1e-6:
            points.append(end)
        return points

    def _pick_target_index(self, tractor):
        if self.idx >= len(self.path) - 1:
            return self.idx
        tx, tz = self.path[self.idx]
        while self.idx < len(self.path) - 1:
            dx = tx - tractor.x
            dz = tz - tractor.z
            if dx*dx + dz*dz >= self.lookahead*self.lookahead:
                break
            self.idx += 1
            tx, tz = self.path[self.idx]
        return self.idx

    def control(self, tractor, dt, speed_scale: float = 1.0, steer_bias: float = 0.0): # bias comment
        """
        SAME control logic you had:
        - pure pursuit style steering using kappa
        - speed target blended between v_straight and v_turn
        - then scaled by self.speed_scale
        """
        if not self.path or self.reached_end:
            return False, False, 0.0

        i = self._pick_target_index(tractor)
        tx, tz = self.path[i]

        #bias autopilot code:
        # Lateral target offset from steer_bias (shift target left/right of the lane)
        # if abs(steer_bias) > 1e-6:
        #     if i < len(self.path) - 1:
        #         sx, sz = self.path[i+1][0] - tx, self.path[i+1][1] - tz
        #     else:
        #         sx, sz = tx - self.path[i-1][0], tz - self.path[i-1][1]
        #     seg_len = math.hypot(sx, sz) + 1e-6
        #     # left normal of the path segment on XZ
        #     nx, nz = -(sz / seg_len), (sx / seg_len)
        #     # convert bias (radians) into meters of lateral shift near the target
        #     lat_offset = float(steer_bias) * self.lookahead * 0.8
        #     tx += nx * lat_offset
        #     tz += nz * lat_offset


        # tractor.forward_vec() gives heading in world XZ.
        fx, fz = tractor.forward_vec()

        # rx, rz is the "right" vector relative to current yaw
        rx, rz = math.cos(tractor.yaw), math.sin(tractor.yaw)

        dx, dz = tx - tractor.x, tz - tractor.z
        x_local = dx * rx + dz * rz  # lateral error to the target

        L = tractor.WHEELBASE
        Ld = max(self.lookahead, 0.5)
        kappa = 2.0 * x_local / (Ld * Ld + 1e-6)

        steer_target = clamp(
            math.atan(kappa * L),
            -tractor.MAX_STEER,
            tractor.MAX_STEER
        )

        # bias comment
        # Small additive bias so taps are immediately visible even on short segments
        # steer_target = clamp(
        #     steer_target + 0.5 * float(steer_bias),
        #     -tractor.MAX_STEER, tractor.MAX_STEER
        # )


        turn_factor = min(1.0, abs(kappa) * 2.0)
        base_v = self.v_straight * (1.0 - turn_factor) + self.v_turn * turn_factor

        # apply your speed scale (K/M keys)
        # v_set = base_v * self.speed_scale # SC comment
        v_set = base_v * max(0.01, float(speed_scale))


        eps = 0.3
        throttle = (tractor.v < v_set - eps)
        brake    = (tractor.v > v_set + eps)

        # did we finish?
        if i >= len(self.path) - 1 and math.hypot(dx, dz) < 1.0:
            self.reached_end = True

        return throttle, brake, steer_target

    def _ensure_path_within_bounds(self, path: Sequence[Tuple[float, float]]) -> List[Tuple[float, float]]:
        clamped: List[Tuple[float, float]] = []
        for x, z in path:
            bx, bz = self._clamp_to_bounds((x, z))
            if clamped:
                px, pz = clamped[-1]
                if abs(px - bx) < 1e-6 and abs(pz - bz) < 1e-6:
                    continue
            clamped.append((bx, bz))
        return clamped

    def _clamp_to_bounds(self, point: Tuple[float, float], inset: float = 0.0) -> Tuple[float, float]:
        left, right, bottom, top = self._usable_bounds
        left += inset
        right -= inset
        bottom += inset
        top -= inset
        return (
            clamp(point[0], left, right),
            clamp(point[1], bottom, top)
        )

    def _distance_to_bounds(self, point: Tuple[float, float]) -> float:
        left, right, bottom, top = self._usable_bounds
        return min(point[0] - left, right - point[0], point[1] - bottom, top - point[1])

    @staticmethod
    def _distance_sq_tuple(a: Tuple[float, float], b: Tuple[float, float]) -> float:
        dx = a[0] - b[0]
        dz = a[1] - b[1]
        return dx * dx + dz * dz

    @staticmethod
    def _distance_sq_to_segment(point, start, end):
        px, pz = point
        sx, sz = start
        ex, ez = end
        dx = ex - sx
        dz = ez - sz
        seg_len_sq = dx * dx + dz * dz
        if seg_len_sq < 1e-9:
            return ((px - sx) * (px - sx) + (pz - sz) * (pz - sz), 0.0)
        t = ((px - sx) * dx + (pz - sz) * dz) / seg_len_sq
        t = max(0.0, min(1.0, t))
        closest = (sx + dx * t, sz + dz * t)
        dist_sq = (px - closest[0]) * (px - closest[0]) + (pz - closest[1]) * (pz - closest[1])
        return dist_sq, t

    def _project_to_circle(
        self,
        point: Tuple[float, float],
        centre: Tuple[float, float],
        radius: float
    ) -> Tuple[float, float]:
        """Project a point onto a circle around centre, then clamp to bounds."""
        vx = point[0] - centre[0]
        vz = point[1] - centre[1]
        length = math.hypot(vx, vz)
        if length < 1e-4:
            vx, vz = 1.0, 0.0
            length = 1.0
        scale = radius / length
        projected = (
            centre[0] + vx * scale,
            centre[1] + vz * scale,
        )
        return self._clamp_to_bounds(projected, inset=self.DETOUR_PADDING * 0.5)

    def _arc_around(
        self,
        centre: Tuple[float, float],
        entry: Tuple[float, float],
        exit: Tuple[float, float],
        radius: float,
        direction: int
    ) -> List[Tuple[float, float]]:
        """Generate an arc from entry to exit around centre with given radius."""
        cx, cz = centre
        start_angle = math.atan2(entry[1] - cz, entry[0] - cx)
        end_angle = math.atan2(exit[1] - cz, exit[0] - cx)

        direction = 1 if direction >= 0 else -1
        min_span = math.radians(20.0)
        max_span = math.radians(270.0)

        if direction > 0:
            sweep = (end_angle - start_angle) % (2.0 * math.pi)
            if sweep < min_span:
                sweep = min_span
            sweep = min(sweep, max_span)
        else:
            sweep = (start_angle - end_angle) % (2.0 * math.pi)
            if sweep < min_span:
                sweep = min_span
            sweep = min(sweep, max_span)
            sweep = -sweep

        end_angle = start_angle + sweep
        steps = max(6, int(abs(sweep) / (math.pi / 32)) + 1)
        arc: List[Tuple[float, float]] = []
        for i in range(steps):
            t = i / (steps - 1)
            theta = start_angle + sweep * t
            px = cx + math.cos(theta) * radius
            pz = cz + math.sin(theta) * radius
            arc.append(self._clamp_to_bounds((px, pz), inset=self.DETOUR_PADDING * 0.2))
        return arc
