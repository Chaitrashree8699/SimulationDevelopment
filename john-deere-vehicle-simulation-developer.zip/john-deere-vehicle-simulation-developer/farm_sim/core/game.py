import sys, random, pygame, json, os, math
from collections import deque
from tkinter import font
from datetime import datetime
from typing import Optional
import tkinter as tk
root = tk.Tk()          # initialize Tk on the main thread first
root.withdraw() 

from pygame.locals import DOUBLEBUF, OPENGL
from OpenGL.GL import *
from OpenGL.GLU import *
from typing import List, Tuple

from farm_sim.config import *
from farm_sim.entities import Tractor, Crop
from farm_sim.render import DriverCamera, CamMode, draw_tractor_john_deere, draw_crop, draw_obstacles
from farm_sim.world import draw_ground, generate_obstacles
from farm_sim.core.autopilot import AutoPilot
from farm_sim.util import clamp
from operations_center.sim_data_controller import push_simulation, push_simulation_sandbox
from farm_sim.gps_utils import CoordinateConverter, JohnDeereAPI, create_field_from_gps, SAMPLE_GPS_BOUNDARY

class Game:
    SOIL_MARGIN = 6.0  # further increased to ensure implements stay within brown soil area
    def __init__(
        self,
        width,
        height,
        field_w,
        field_h,
        vehicle_key=None,
        field_map_key=None,
        field_map_name="Open Field",
        obstacles_enabled=False,
        season="Spring",
        implement_key="plow",
        gps_boundary=None,
        john_deere_token=None,
        field_id=None
    ):
        self.width, self.height = width, height
        self.vehicle_key = vehicle_key
        self.field_map_key = field_map_key
        self.field_map_name = field_map_name or "Open Field"
        self.obstacles_enabled = obstacles_enabled
        self.season = season
        self.implement_key = implement_key
        # GPS field setup
        self.gps_converter = None
        self.gps_boundary = None
        
        # Initialize field dimensions from GPS if provided
        if john_deere_token and field_id:
            # Fetch from John Deere API
            api = JohnDeereAPI(john_deere_token)
            gps_points = api.get_field_boundaries(field_id)
            if gps_points:
                self.field_w, self.field_h, self.gps_converter = create_field_from_gps(gps_points)
                self.gps_boundary = gps_points
                self.field_map_name = f"JD Field {field_id}"
            else:
                self.field_w, self.field_h = field_w, field_h
        elif gps_boundary:
            # Use provided GPS boundary
            self.field_w, self.field_h, self.gps_converter = create_field_from_gps(gps_boundary)
            self.gps_boundary = gps_boundary
            self.field_map_name = "GPS Field"
        else:
            # Use traditional rectangular field
            self.field_w, self.field_h = field_w, field_h

        # --- Speed and steering control ---
        self.speed_scale = 1.0
        self.speed_scale_min = 0.20
        self.speed_scale_max = 3.00
        self.speed_scale_step = 0.10

        #bias commented
        # self.steer_bias = 0.0
        # self.steer_bias_step = 0.05
        # self.steer_bias_max = 0.40

        pygame.display.set_caption("JD Tiny Farm (Driver Cam v2)")
        self.screen = pygame.display.set_mode((width, height), DOUBLEBUF | OPENGL)
        self.clock = pygame.time.Clock()
        self.running = True
        self.paused = False



        # --- OpenGL setup ---
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        
        # Apply season-specific lighting
        season_effects = SEASON_EFFECTS.get(self.season, SEASON_EFFECTS["Spring"])
        season_colors = SEASON_COLORS.get(self.season, SEASON_COLORS["Spring"])
        
        glLightfv(GL_LIGHT0, GL_POSITION, (0.4, 1.0, 0.5, 0.0))
        glLightfv(GL_LIGHT0, GL_DIFFUSE, (*season_effects["diffuse_light"], 1))
        glLightfv(GL_LIGHT0, GL_AMBIENT, (*season_effects["ambient_light"], 1))
        
        # Apply season-specific sky color
        sky_color = season_colors["sky"]
        glClearColor(*sky_color, 1.0)

        # NEW: enable blending for translucent overlays
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(60.0, width / float(height), 0.1, 800.0)
        glMatrixMode(GL_MODELVIEW)

        # --- Game state ---
        self.tractor = Tractor(vehicle_key)
        self.vehicle_name = self.tractor.name
        self.vehicle_model_id = self.tractor.spec.model_id

        # Ensure no implements are attached initially
        self.tractor.implement_enabled = False
        self.tractor.attached_implement = None
        self.camera = DriverCamera(mode=CamMode.CHASE)

        # --- Attach implement from menu selection (NEW) ---
        from farm_sim.entities.implements import ImplementType
        key_to_impl = {
            "plow":       ImplementType.PLOW,
            "sower":      ImplementType.SOWER,
            "sprayer":    ImplementType.SPRAYER,
            "irrigation": ImplementType.IRRIGATION,
            "harvester":  ImplementType.HARVESTER,
        }
        impl = key_to_impl.get(self.implement_key)
        if impl is not None:
            self.tractor.attached_implement = impl
            self.tractor.implement_enabled = True

            # Pre-create same session structures as the key handlers:

            if impl == ImplementType.PLOW:
                width = self.tractor.spec.working_width
                num_lines = max(3, int(width / 1.5))  # Match plow blades
                if not hasattr(self, "all_furrow_sessions"):
                    self.all_furrow_sessions = []
                new_session = [[] for _ in range(num_lines)]
                self.all_furrow_sessions.append(new_session)
                self.multi_furrow_points = new_session

            elif impl == ImplementType.SOWER:
                if not hasattr(self, "all_sowing_sessions"):
                    self.all_sowing_sessions = []
                new_session = self._make_trail_buffer()
                self.all_sowing_sessions.append(new_session)
                self.sowing_points = new_session

            elif impl == ImplementType.SPRAYER:
                width = self.tractor.spec.working_width
                num_lines = max(3, int(width / 2.0))  # 1 line per 2m
                if not hasattr(self, "all_spray_sessions"):
                    self.all_spray_sessions = []
                new_session = [[] for _ in range(num_lines)]
                self.all_spray_sessions.append(new_session)
                self.multi_spray_points = new_session

            elif impl == ImplementType.IRRIGATION:
                width = self.tractor.spec.working_width
                num_lines = max(6, int(width * 1.5))
                if not hasattr(self, "all_irrigation_sessions"):
                    self.all_irrigation_sessions = []
                new_session = [[] for _ in range(num_lines)]
                self.all_irrigation_sessions.append(new_session)
                self.multi_irrigation_points = new_session

            elif impl == ImplementType.HARVESTER:
                if not hasattr(self, "all_harvest_sessions"):
                    self.all_harvest_sessions = []
                new_session = []
                self.all_harvest_sessions.append(new_session)
                self.harvest_points = new_session

        # --- Effective machine width for safe obstacle clearance (tractor + implement) ---
        # Base width from tractor alone (no implements)
        base_machine_width = float(self.tractor.spec.working_width)

        if getattr(self.tractor, "attached_implement", None):
            # Implement present: keep old logic (currently same as tractor width,
            # but ready for per-implement widths later).
            tractor_width = float(self.tractor.spec.working_width)
            implement_width = tractor_width  # hook for per-implement overrides
            machine_width = max(tractor_width, implement_width)
            # half-width minus 0.5m baseline already accounted for in AutoPilot
            self.autopilot_extra_clearance = max(0.0, 0.5 * machine_width - 0.5)
        else:
            # No implement: do not add extra clearance on top of tractor radius
            self.autopilot_extra_clearance = 0.0
        # --- Sensor pose cache (true vs noisy) ---
        # last_meas_pose = (x, y, z, yaw) from tractor.get_noisy_pose()
        self.last_meas_pose = self.tractor.get_pose()

        # NEW: fonts for HUD (menu-like look)
        pygame.font.init()  # Ensure font system is initialized
        self.ui_font_big = pygame.font.SysFont(None, 56)
        self.ui_font = pygame.font.SysFont(None, 28)
        self.ui_font_small = pygame.font.SysFont(None, 20)

        # Text rendering cache to avoid re-uploading textures every frame
        # key -> (tex_id, w, h)
        self._text_cache = {}
        self._text_cache_limit = 128
        self._frame_counter = 0

        # Performance tuning
        self.TARGET_FPS = 120
        self.sow_record_rate = 3          # only sample sowing every N frames
        self.MAX_TRAIL_POINTS = getattr(self, "MAX_TRAIL_POINTS", 2000)
        # existing: FURROW_SPACING, IMPLEMENT_OFFSET already set later

        lane_spacing, margin, turn_inset = self._derive_autopilot_geometry()
        self.auto = AutoPilot(
            field_w=self.field_w,
            field_h=self.field_h,
            lane_spacing=lane_spacing,
            margin=margin,
            turn_inset=turn_inset,
            soil_margin=self.SOIL_MARGIN,
            extra_clearance=self.autopilot_extra_clearance,
        )
        self._configure_autopilot_behavior()
        self.obstacles = []
        self._refresh_obstacles(initial=True)

        # Manual driving trace state
        self.manual_trace_sessions: List[List[Tuple[float, float]]] = []
        self.current_manual_trace: List[Tuple[float, float]] = []
        self.MANUAL_TRACE_SPACING = 0.5
        self.MANUAL_TRACE_MAX_SESSIONS = 12
        self.MANUAL_TRACE_MAX_POINTS = 1800
        self.autopilot_trace_points: List[Tuple[float, float]] = []
        self.AUTO_TRACE_SPACING = 0.7
        self.show_autopilot_trace = True
        # GNSS noisy path (magenta)
        self.gnss_points: List[Tuple[float, float]] = []
        self.MAX_GNSS_POINTS = 3000

        # --- Crops ---
        self.crops = []
        self.crop_grid = {}  # O(1) lookup: {(grid_x, grid_z): crop}
        half_w = self.field_w * 0.5
        half_h = self.field_h * 0.5
        for _ in range(20):
            rx = random.uniform(-half_w * 0.7, half_w * 0.7)
            rz = random.uniform(-half_h * 0.7, half_h * 0.7)
            crop = Crop(rx, rz, -random.uniform(0, CROP_GROW_SECONDS))
            self.crops.append(crop)
            # Add to grid
            grid_x = int(rx // PLANT_SPACING)
            grid_z = int(rz // PLANT_SPACING)
            self.crop_grid[(grid_x, grid_z)] = crop
        # --- Pre-populate field with row crops for implements that need them ---
        attached_impl = getattr(self.tractor, "attached_implement", None)
        if attached_impl == key_to_impl.get("harvester"):
            # Full grown crop rows for immediate harvesting
            self._populate_harvest_rows(maturity=1.1)
        elif attached_impl in (key_to_impl.get("sprayer"), key_to_impl.get("irrigation")):
            # Early stage rows for spraying/irrigation practice
            early_growth = 0.25 if attached_impl == key_to_impl.get("sprayer") else 0.15
            self._populate_harvest_rows(maturity=early_growth)

        self.score = 0
        self.time = 0.0
        self.time_scale = 1.0

        # Spawn tractor at start of autopilot path
        self._teleport_vehicle_to_start()

        # --- Telemetry setup ---
        self.trace_data = []
        self.trace_segments = []  # Store completed path segments
        self.last_log_time = 0.0
        self.user_wants_upload = None
        self.request_upload = False
        self.teleporting = False
        self.last_tractor_pos = (0.0, 0.0)
        self.skip_implement_frames = 0
        
        # --- Pause buttons ---
        self.resume_button_rect = pygame.Rect(0, 0, 100, 50)
        self.exit_button_rect = pygame.Rect(0, 0, 100, 50)
        
        # --- End simulation button ---
        self.end_sim_button_rect = pygame.Rect(0, 0, 120, 36)
        
        # --- Upload dialog state ---
        self.show_upload_dialog = False
        self.upload_success = False
        self.upload_message = ""
        self.upload_in_progress = False
        
        # --- Notifications ---
        self.notification_text = ""
        self.notification_time = 0.0
        self.notification_duration = 2.0
        self.last_action_time = 0.0

        # --- Plow furrow tracking (NEW) ---
        self.furrow_points = []           # stores (x, z) of the plow path
        self._last_furrow_drop_t = 0.0
        self.FURROW_SPACING = 0.7         # distance between furrow points (m)
        self.IMPLEMENT_OFFSET = -1.8      # offset in front of tractor
        self.MAX_TRAIL_POINTS = 2000      # Limit trail points for performance

        # --- Overlay toggles ---
        self.show_furrows = True
        self.show_sowing = True
        self.show_spray = True
        
        # --- GNSS noisy pose trace (magenta line) ---
        self.gnss_trace_points: List[Tuple[float, float]] = []
        self.GNSS_TRACE_SPACING = 0.7
        self.latest_noisy_pose = None  # updated each frame
        # --- Implement menu ---
        self.implement_button_rect = pygame.Rect(0, 0, 120, 30)
        self.show_implement_menu = False
        self.implement_menu_rects = {
            'plow': pygame.Rect(0, 0, 120, 25),
            'sower': pygame.Rect(0, 0, 120, 25),
            'sprayer': pygame.Rect(0, 0, 120, 25),
            'irrigation': pygame.Rect(0, 0, 120, 25),
            'harvester': pygame.Rect(0, 0, 120, 25)
        }
       
        # --- Autopilot button (NEW) ---
        self.autopilot_button_rect = pygame.Rect(0, 0, 120, 36)


        # --- U button ---
        self.u_button_rect = pygame.Rect(0, 0, 40, 36)

        # --- U button ---
        self.u_button_rect = pygame.Rect(0, 0, 40, 36)
        
        # --- Speed menu ---
        self.speed_button_rect = pygame.Rect(0, 0, 100, 36)
        self.show_speed_menu = False
        self.speed_options = [1.0, 2.0, 5.0]
        self.speed_menu_rects = {}
        self.speed_menu_animation = 0.0  # 0.0 = closed, 1.0 = fully open
        for i, speed in enumerate(self.speed_options):
            self.speed_menu_rects[speed] = pygame.Rect(0, 0, 100, 25)
            
        # --- Help button ---
        self.help_button_rect = pygame.Rect(0, 0, 40, 36)
        self.show_help = False

        
    # -------------------------------------------------------------------------
    # Collision Detection
    # -------------------------------------------------------------------------
    def _check_collision(self, x, z):
        """Check if position (x, z) collides with any obstacles"""
        if not self.obstacles:
            return False
        
        from farm_sim.world.obstacles import collision_radius
        
        # Tractor collision radius (approximate)
        tractor_radius = max(self.tractor.spec.wheelbase, self.tractor.spec.working_width) * 0.5
        
        for obstacle in self.obstacles:
            # Calculate distance between tractor center and obstacle center
            dx = x - obstacle.x
            dz = z - obstacle.z
            distance = (dx * dx + dz * dz) ** 0.5
            
            # Get obstacle collision radius
            obs_radius = collision_radius(obstacle)
            
            # Check if collision occurs
            if distance < (tractor_radius + obs_radius):
                return True
        
        return False
    
    # -------------------------------------------------------------------------
    # Crop Functions
    # -------------------------------------------------------------------------
    def _is_in_soil_area(self, x, z):
        """Check if position is in the brown soil area (not green grass)"""
        soil_margin = 2.0  # matches ground.py
        half_w = self.field_w * 0.5
        half_h = self.field_h * 0.5
        soil_half_w = half_w - soil_margin
        soil_half_h = half_h - soil_margin
        return abs(x) <= soil_half_w and abs(z) <= soil_half_h
    
    def plant_crop(self):
        fx, fz = self.tractor.forward_vec()
        # Plant on both sides of tractor
        perp_x, perp_z = -fz, fx  # Perpendicular to tractor direction
        offset = self.tractor.spec.working_width * 0.3  # 30% of working width to each side
        
        for side in (-1, 1):  # Left and right sides
            px = self.tractor.x + perp_x * side * offset
            pz = self.tractor.z + perp_z * side * offset
            px = round(px / PLANT_SPACING) * PLANT_SPACING
            pz = round(pz / PLANT_SPACING) * PLANT_SPACING
            
            # O(1) duplicate check using grid
            grid_x = int(px // PLANT_SPACING)
            grid_z = int(pz // PLANT_SPACING)
            grid_key = (grid_x, grid_z)
            
            # Only plant if in soil area and grid cell is empty
            if self._is_in_soil_area(px, pz) and grid_key not in self.crop_grid:
                crop = Crop(px, pz, self.time)
                self.crops.append(crop)
                self.crop_grid[grid_key] = crop

    def harvest_nearby(self):
        hx, hz = self.tractor.x, self.tractor.z
        candidates = self._query_crops_in_radius(hx, hz, HARVEST_DISTANCE)
        harvested = []
        for crop in candidates:
            if crop.growth(self.time) >= 0.999:
                crop.harvested = True
                harvested.append(crop)
                self.score += 1

        self._prune_harvested(harvested)

        if harvested:
            count = len(harvested)
            self._show_notification(f"Harvested {count} crop{'s' if count > 1 else ''}!")

    def _query_crops_in_radius(self, x: float, z: float, radius: float):
        """Return list of crops near (x,z) using crop_grid (cheap, local cells)."""
        res = []
        if not self.crop_grid:
            return res
        cell_r = max(1, int(math.ceil(radius / max(PLANT_SPACING, 0.01))))
        cx = int(x // PLANT_SPACING)
        cz = int(z // PLANT_SPACING)
        r2 = radius * radius
        for dx in range(-cell_r, cell_r + 1):
            for dz in range(-cell_r, cell_r + 1):
                key = (cx + dx, cz + dz)
                c = self.crop_grid.get(key)
                if c and not c.harvested:
                    dxw = c.x - x
                    dzw = c.z - z
                    if dxw * dxw + dzw * dzw <= r2:
                        res.append(c)
        return res

    def _prune_harvested(self, harvested_crops):
        if not harvested_crops:
            return
        for c in harvested_crops:
            grid_x = int(c.x // PLANT_SPACING)
            grid_z = int(c.z // PLANT_SPACING)
            self.crop_grid.pop((grid_x, grid_z), None)
        harvested_ids = {id(c) for c in harvested_crops}
        self.crops = [c for c in self.crops if id(c) not in harvested_ids]

    # -------------------------------------------------------------------------
    # HUD Overlay
    # -------------------------------------------------------------------------
    def _draw_hud(self):
        """Draws a non-intrusive status HUD at the top of the screen."""
        self._begin_2d()

        HUD_BG = (12, 60, 22, 160)  # semi-transparent deep green
        TEXT_COLOR = (255, 230, 90, 255)  # John Deere yellow
        PANEL_H = 38
        PAD = 12

        # Background bar (across the top)
        self._draw_rect(0, 0, self.width, PANEL_H, HUD_BG)
        # Draw dark gradient bar instead of flat color
        for i in range(PANEL_H):
            alpha = 180 - int(i * 3)   # fade out vertically
            self._draw_rect(0, i, self.width, 1, (12, 60, 22, max(0, alpha)))
            
        #The HUD stays visible but less intrusive when zoomed out.
        if self.camera.mode == CamMode.TOP:
            HUD_BG = (12, 60, 22, 120)
        else:
            HUD_BG = (12, 60, 22, 180)

        # Left-aligned info
        ap_status = "Autopilot: ON" if self.auto.enabled else "Autopilot: OFF"
        map_info = f"Map: {self.field_map_name}"
        time_scale = f"Time ×{self.time_scale:.1f}"
        season_info = f"Season: {self.season}"
        left_text = f"{ap_status}   |   {map_info}   |   {season_info}   |   {time_scale}"

        self._draw_text(left_text, PAD, 8, self.ui_font, TEXT_COLOR)

        # Right-aligned info
        # right_text = (
        #     f"Score: {self.score}   |   Speed: {self.tractor.speed:.1f} m/s   |   Bias: {self.steer_bias:+.2f}"
        # )
        right_text = (
            f"Score: {self.score}   |   Speed: {self.tractor.speed:.1f} m/s"
        )
        text_width = self.ui_font.size(right_text)[0]
        self._draw_text(right_text, self.width - text_width - PAD, 8, self.ui_font, TEXT_COLOR)

        # compass (positioned to avoid collision with right text)
        heading = (math.degrees(self.tractor.yaw) + 360) % 360
        heading_text = f"{heading:03.0f}°"
        compass_width = self.ui_font.size(heading_text)[0]
        self._draw_text(heading_text, self.width - text_width - compass_width - PAD * 3, 8, self.ui_font, (255, 255, 200, 255))

        #Add “FPS” Counter for Performance Debugging
        fps = int(self.clock.get_fps())
        fps_color = (255, 255, 255, 180) if fps > 55 else (255, 180, 120, 200)
        self._draw_text(f"FPS: {fps}", 12, self.height - 28, self.ui_font, fps_color)

        # colour grading for autopilot and manual
        if self.auto.enabled:
            ap_color = (180, 255, 180, 255)  # soft green
        else:
            ap_color = (255, 160, 80, 255)   # amber for OFF

        # Draw AP status separately in color
        self._draw_text(ap_status, PAD, 8, self.ui_font, ap_color)
        # Update clickable autopilot HUD text rect
        ap_width, ap_height = self.ui_font.size(ap_status)
        self.autopilot_hud_rect = pygame.Rect(PAD, 8, ap_width, ap_height)

        # Implement state (NEW + dynamic)
        from farm_sim.entities.implements import ImplementType

        if getattr(self.tractor, "attached_implement", None) == ImplementType.PLOW:
            imp_name = "PLOWER"
        elif getattr(self.tractor, "attached_implement", None) == ImplementType.SOWER:
            imp_name = "SOWER"
        elif getattr(self.tractor, "attached_implement", None) == ImplementType.SPRAYER:
            imp_name = "SPRAYER"
        elif getattr(self.tractor, "attached_implement", None) == ImplementType.IRRIGATION:
            imp_name = "IRRIGATOR"
        elif getattr(self.tractor, "attached_implement", None) == ImplementType.HARVESTER:
            imp_name = "HARVESTER"
        else:
            imp_name = "NONE"

        imp_state = "ON" if getattr(self.tractor, "implement_enabled", False) else "OFF"

        # Choose colour depending on state
        if imp_state == "ON":
            color = (255, 230, 90, 255)   # JD yellow
        else:
            color = (180, 180, 180, 255)  # greyed out

        self._draw_text(f"Implement: {imp_name} [{imp_state}]", 12, self.height - 56, self.ui_font, color)
                
        # GPS coordinates display (if GPS field is active)
        if self.gps_converter:
            # Use noisy sensor pose so the GPS readout "jitters" realistically
            mx, my, mz, myaw = self.last_meas_pose
            lat, lon = self.gps_converter.local_to_gps(mx, mz)
            gps_text = f"GPS: {lat:.6f}, {lon:.6f}"
            self._draw_text(gps_text, 12, self.height - 84, self.ui_font, (200, 200, 255, 255))
        # --- Implement menu ---
        mx, my = pygame.mouse.get_pos()
        
        
        # Position buttons - arrow on left, implements on right, speed below arrow, help in bottom right
        self.u_button_rect = pygame.Rect(15, 50, 40, 36)
        self.speed_button_rect = pygame.Rect(15, 95, 60, 36)
        
        # More padding + better size
        self.autopilot_button_rect = pygame.Rect(15, 140, 150, 42)
        
        # End simulation button
        self.end_sim_button_rect = pygame.Rect(self.width - 70, 50, 40, 36)

        self.implement_button_rect = pygame.Rect(self.width - 155, 50, 140, 36)
        self.help_button_rect = pygame.Rect(self.width - 50, self.height - 50, 40, 36)
        
        # Get current implement
        from farm_sim.entities.implements import ImplementType
        current_impl = getattr(self.tractor, "attached_implement", None)
        
        # button_text = "IMPLEMENTS"
        # Draw main button
        # self._draw_implement_button(self.implement_button_rect, button_text, current_impl is not None, mx, my)
        
        # Draw U button with arrow symbol
        self._draw_u_button_with_arrow(self.u_button_rect, mx, my)
        
        # Draw speed button
        speed_text = f"x{self.time_scale:.1f}"
        self._draw_implement_button(self.speed_button_rect, speed_text, False, mx, my)
        # Draw autopilot button
        ap_text = "AUTOPILOT"
        self._draw_implement_button(
            self.autopilot_button_rect,
            ap_text,
            self.auto.enabled,   # highlight when ON
            mx, my
        )
        
        # Draw end simulation button with stop symbol
        self._draw_end_sim_button(self.end_sim_button_rect, mx, my)

        # Draw help button
        # self._draw_implement_button(self.help_button_rect, "?", False, mx, my)
        
        # Draw dropdown menu if open
        # if self.show_implement_menu:
        #     menu_x = self.width - 160
        #     menu_y = 90
        #     menu_w, menu_h = 150, 140
            
        #     # Drop shadow
        #     self._draw_rect(menu_x + 5, menu_y + 4, menu_w, menu_h, (0, 0, 0, 120))
            
        #     # Menu background with John Deere themed gradient
        #     for i in range(menu_h):
        #         t = i / menu_h
        #         r = int(15 + t * 10)  # 15 -> 25
        #         g = int(45 + t * 15)  # 45 -> 60
        #         b = int(20 + t * 10)  # 20 -> 30
        #         alpha = 250 - int(i * 0.2)
        #         self._draw_rect(menu_x, menu_y + i, menu_w, 1, (r, g, b, alpha))
            
        #     # Menu border with John Deere colors
        #     border_color = (120, 180, 60, 255)  # John Deere green
        #     self._draw_rect(menu_x, menu_y, menu_w, 2, border_color)
        #     self._draw_rect(menu_x, menu_y + menu_h - 2, menu_w, 2, border_color)
        #     self._draw_rect(menu_x, menu_y, 2, menu_h, border_color)
        #     self._draw_rect(menu_x + menu_w - 2, menu_y, 2, menu_h, border_color)
            
        #     # Position menu items with better padding
        #     menu_h = 140  # Increased height for 5 items
        #     self.implement_menu_rects['plow'] = pygame.Rect(menu_x + 5, menu_y + 8, 140, 25)
        #     self.implement_menu_rects['sower'] = pygame.Rect(menu_x + 5, menu_y + 35, 140, 25)
        #     self.implement_menu_rects['sprayer'] = pygame.Rect(menu_x + 5, menu_y + 62, 140, 25)
        #     self.implement_menu_rects['irrigation'] = pygame.Rect(menu_x + 5, menu_y + 89, 140, 25)
        #     self.implement_menu_rects['harvester'] = pygame.Rect(menu_x + 5, menu_y + 116, 140, 25)
            
        #     # Menu items
        #     plow_active = current_impl == ImplementType.PLOW
        #     sower_active = current_impl == ImplementType.SOWER
        #     sprayer_active = current_impl == ImplementType.SPRAYER
        #     irrigation_active = current_impl == ImplementType.IRRIGATION
        #     harvester_active = current_impl == ImplementType.HARVESTER
            
        #     self._draw_menu_item(self.implement_menu_rects['plow'], "Plow", plow_active, mx, my)
        #     self._draw_menu_item(self.implement_menu_rects['sower'], "Sower", sower_active, mx, my)
        #     self._draw_menu_item(self.implement_menu_rects['sprayer'], "Sprayer", sprayer_active, mx, my)
        #     self._draw_menu_item(self.implement_menu_rects['irrigation'], "Irrigation", irrigation_active, mx, my)
        #     self._draw_menu_item(self.implement_menu_rects['harvester'], "Harvester", harvester_active, mx, my)
        
        # Animate speed menu
        if self.show_speed_menu and self.speed_menu_animation < 1.0:
            self.speed_menu_animation = min(1.0, self.speed_menu_animation + 0.15)
        elif not self.show_speed_menu and self.speed_menu_animation > 0.0:
            self.speed_menu_animation = max(0.0, self.speed_menu_animation - 0.15)
        
        # Draw horizontal speed dropdown if animating or open
        if self.speed_menu_animation > 0.0:
            # Position dropdown to the right of the button
            menu_x = self.speed_button_rect.right + 10
            menu_y = self.speed_button_rect.y
            menu_w = int(200 * self.speed_menu_animation)
            menu_h = 36
            
            # Ensure it stays within screen bounds
            menu_x = min(self.width - menu_w - 10, menu_x)
            
            # Draw background with fade
            alpha = int(200 * self.speed_menu_animation)
            # Drop shadow
            self._draw_rect(menu_x + 3, menu_y + 3, menu_w, menu_h, (0, 0, 0, alpha // 3))
            
            # Menu background with gradient
            for i in range(menu_h):
                t = i / menu_h
                r = int(15 + t * 10)
                g = int(45 + t * 15)
                b = int(20 + t * 10)
                bg_alpha = alpha - int(i * 0.5)
                self._draw_rect(menu_x, menu_y + i, menu_w, 1, (r, g, b, bg_alpha))
            
            # Menu border
            border_color = (120, 180, 60, alpha)
            self._draw_rect(menu_x, menu_y, menu_w, 2, border_color)
            self._draw_rect(menu_x, menu_y + menu_h - 2, menu_w, 2, border_color)
            self._draw_rect(menu_x, menu_y, 2, menu_h, border_color)
            self._draw_rect(menu_x + menu_w - 2, menu_y, 2, menu_h, border_color)
            
            # Position speed options horizontally
            option_w = (menu_w - 10) // len(self.speed_options)
            for i, speed in enumerate(self.speed_options):
                option_x = menu_x + 5 + i * option_w
                option_y = menu_y + 3
                option_rect = pygame.Rect(option_x, option_y, option_w - 2, menu_h - 6)
                self.speed_menu_rects[speed] = option_rect
                
                # Check if active or hovered
                speed_active = abs(self.time_scale - speed) < 0.05
                hovered = option_rect.collidepoint((mx, my))
                
                # Draw option background
                if speed_active:
                    self._draw_rect(option_x, option_y, option_w - 2, menu_h - 6, (80, 160, 50, alpha))
                elif hovered:
                    self._draw_rect(option_x, option_y, option_w - 2, menu_h - 6, (100, 120, 60, alpha // 2))
                
                # Draw speed text
                text = f"x{speed:.0f}" if speed >= 10 else f"x{speed:.1f}"
                text_w = self.ui_font.size(text)[0]
                text_x = option_x + (option_w - text_w) // 2
                text_y = option_y + (menu_h - self.ui_font.get_height()) // 2
                text_alpha = int(255 * self.speed_menu_animation)
                text_color = (255, 255, 255, text_alpha) if speed_active else (220, 220, 220, text_alpha)
                self._draw_text(text, text_x, text_y, self.ui_font, text_color)
        
        # Draw help overlay if open
        if self.show_help:
            # Help panel in bottom right
            panel_w, panel_h = 300, 200
            panel_x = self.width - panel_w - 15
            panel_y = self.height - panel_h - 60
            
            # Drop shadow
            self._draw_rect(panel_x + 5, panel_y + 5, panel_w, panel_h, (0, 0, 0, 120))
            
            # Panel background
            self._draw_rect(panel_x, panel_y, panel_w, panel_h, (25, 55, 30, 240))
            
            # Panel border
            border_color = (120, 180, 60, 255)
            self._draw_rect(panel_x, panel_y, panel_w, 3, border_color)
            self._draw_rect(panel_x, panel_y + panel_h - 3, panel_w, 3, border_color)
            self._draw_rect(panel_x, panel_y, 3, panel_h, border_color)
            self._draw_rect(panel_x + panel_w - 3, panel_y, 3, panel_h, border_color)
            
            # Help content
            title_y = panel_y + 15
            self._draw_text("CONTROLS", panel_x + 15, title_y, self.ui_font, (255, 230, 90, 255))
            
            # Key controls
            controls = [
                "W/S - Move",
                "A/D - Steer", 
                "P - Autopilot",
                "C - Camera",
                # "L/J/H/I/R - Implements",
                "Space - Plant",
                "E - Harvest"
            ]
            
            y_offset = title_y + 30
            for control in controls:
                self._draw_text(control, panel_x + 15, y_offset, self.ui_font_small, (220, 220, 220, 255))
                y_offset += 18
            
            # Close instruction
            self._draw_text("Click to close", panel_x + 15, panel_y + panel_h - 25, self.ui_font_small, (180, 180, 180, 255))

        self._end_2d()
    
    def _draw_upload_dialog(self):
        """Draw upload confirmation dialog."""
        self._begin_2d()
        
        # Dim background
        self._draw_rect(0, 0, self.width, self.height, (0, 0, 0, 120))
        
        # Dialog dimensions
        dialog_w, dialog_h = 400, 200
        dialog_x = (self.width - dialog_w) // 2
        dialog_y = (self.height - dialog_h) // 2
        
        # Dialog background
        self._draw_rect(dialog_x, dialog_y, dialog_w, dialog_h, (25, 55, 30, 240))
        
        # Dialog border
        border_color = (120, 180, 60, 255)
        self._draw_rect(dialog_x, dialog_y, dialog_w, 3, border_color)
        self._draw_rect(dialog_x, dialog_y + dialog_h - 3, dialog_w, 3, border_color)
        self._draw_rect(dialog_x, dialog_y, 3, dialog_h, border_color)
        self._draw_rect(dialog_x + dialog_w - 3, dialog_y, 3, dialog_h, border_color)
        
        # Title
        title_text = "Simulation Complete"
        self._draw_text(title_text, dialog_x + 20, dialog_y + 20, self.ui_font, (255, 230, 90, 255))
        
        # Message
        if self.upload_success:
            message = "Data uploaded successfully to Operations Center!"
            msg_color = (120, 255, 120, 255)
        elif self.upload_message:
            message = self.upload_message
            msg_color = (255, 120, 120, 255)
        else:
            message = "Would you like to upload the telemetry data?"
            msg_color = (220, 220, 220, 255)
        
        self._draw_text(message, dialog_x + 20, dialog_y + 60, self.ui_font_small, msg_color)
        
        # Buttons
        if not self.upload_success and not self.upload_message:
            # Yes/No buttons
            btn_w, btn_h = 80, 35
            yes_x = dialog_x + dialog_w // 2 - btn_w - 10
            no_x = dialog_x + dialog_w // 2 + 10
            btn_y = dialog_y + dialog_h - 60
            
            self.upload_yes_rect = pygame.Rect(yes_x, btn_y, btn_w, btn_h)
            self.upload_no_rect = pygame.Rect(no_x, btn_y, btn_w, btn_h)
            
            mx, my = pygame.mouse.get_pos()
            
            # Yes button
            yes_hovered = self.upload_yes_rect.collidepoint((mx, my))
            yes_color = (80, 140, 60, 220) if yes_hovered else (45, 85, 35, 200)
            self._draw_rect(yes_x, btn_y, btn_w, btn_h, yes_color)
            self._draw_rect(yes_x, btn_y, btn_w, 2, border_color)
            self._draw_rect(yes_x, btn_y + btn_h - 2, btn_w, 2, border_color)
            self._draw_rect(yes_x, btn_y, 2, btn_h, border_color)
            self._draw_rect(yes_x + btn_w - 2, btn_y, 2, btn_h, border_color)
            
            yes_text_w = self.ui_font_small.size("Yes")[0]
            self._draw_text("Yes", yes_x + (btn_w - yes_text_w) // 2, btn_y + 8, self.ui_font_small, (255, 255, 255, 255))
            
            # No button
            no_hovered = self.upload_no_rect.collidepoint((mx, my))
            no_color = (140, 80, 60, 220) if no_hovered else (85, 45, 35, 200)
            self._draw_rect(no_x, btn_y, btn_w, btn_h, no_color)
            self._draw_rect(no_x, btn_y, btn_w, 2, border_color)
            self._draw_rect(no_x, btn_y + btn_h - 2, btn_w, 2, border_color)
            self._draw_rect(no_x, btn_y, 2, btn_h, border_color)
            self._draw_rect(no_x + btn_w - 2, btn_y, 2, btn_h, border_color)
            
            no_text_w = self.ui_font_small.size("No")[0]
            self._draw_text("No", no_x + (btn_w - no_text_w) // 2, btn_y + 8, self.ui_font_small, (255, 255, 255, 255))
        else:
            # OK button
            btn_w, btn_h = 80, 35
            ok_x = dialog_x + (dialog_w - btn_w) // 2
            btn_y = dialog_y + dialog_h - 60
            
            self.upload_ok_rect = pygame.Rect(ok_x, btn_y, btn_w, btn_h)
            
            mx, my = pygame.mouse.get_pos()
            ok_hovered = self.upload_ok_rect.collidepoint((mx, my))
            ok_color = (80, 140, 60, 220) if ok_hovered else (45, 85, 35, 200)
            
            self._draw_rect(ok_x, btn_y, btn_w, btn_h, ok_color)
            self._draw_rect(ok_x, btn_y, btn_w, 2, border_color)
            self._draw_rect(ok_x, btn_y + btn_h - 2, btn_w, 2, border_color)
            self._draw_rect(ok_x, btn_y, 2, btn_h, border_color)
            self._draw_rect(ok_x + btn_w - 2, btn_y, 2, btn_h, border_color)
            
            ok_text_w = self.ui_font_small.size("OK")[0]
            self._draw_text("OK", ok_x + (btn_w - ok_text_w) // 2, btn_y + 8, self.ui_font_small, (255, 255, 255, 255))
        
        self._end_2d()
    
    def _handle_upload_yes(self):
        """Handle Yes button click in upload dialog."""
        if self.upload_in_progress or self.upload_success:
            return
        self.upload_in_progress = True
        try:
            # Save telemetry data first
            saved_path = self._save_telemetry_data()
            if saved_path:
                # Try to upload
                geojson_path = saved_path.replace('.json', '.geojson').replace('vehicle_trace_', 'vehicle_path_')
                if os.path.exists(geojson_path):
                    push_simulation_sandbox(self.vehicle_model_id, geojson_path)
                    self.upload_success = True
                    self.upload_message = ""
                else:
                    self.upload_message = "GeoJSON file not found for upload"
            else:
                self.upload_message = "Failed to save telemetry data"
        except Exception as e:
            self.upload_message = f"Upload failed: {str(e)}"
        finally:
            self.upload_in_progress = False
    
    def _handle_upload_no(self):
        """Handle No button click in upload dialog."""
        self.show_upload_dialog = False
        self.paused = False
        self.running = False
    
    def _handle_upload_ok(self):
        """Handle OK button click in upload dialog."""
        self.show_upload_dialog = False
        self.running = False
    
    def _save_telemetry_data(self):
        """Save telemetry data and return file path."""
        if not self.trace_data:
            return None
        
        os.makedirs(LOG_DIR, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(LOG_DIR, f"vehicle_trace_{timestamp}.json")
        
        with open(file_path, "w") as f:
            json.dump(self.trace_data, f, indent=2)
        
        # Auto-create GeoJSON file
        self._create_geojson_export(file_path, timestamp)
        
        return file_path

  
    # -------------------------------------------------------------------------
    # Event Handling
    # -------------------------------------------------------------------------
    def handle_events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.running = False
            elif e.type == pygame.KEYDOWN:
                print(f"Key pressed: {pygame.key.name(e.key)}")  # Debug all key presses
                
                if e.key in (pygame.K_ESCAPE, pygame.K_q):
                    # Show upload dialog instead of immediate quit
                    self.show_upload_dialog = True

                elif e.key in (pygame.K_l, pygame.K_j, pygame.K_h, pygame.K_i, pygame.K_r):
                    self._show_notification("Implements can only be chosen in the start menu.")

                elif e.key == pygame.K_SPACE:
                    old_count = len([c for c in self.crops if not c.harvested])
                    self.plant_crop()
                    new_count = len([c for c in self.crops if not c.harvested])
                    if new_count > old_count:
                        self._show_notification("Crop planted!")
                elif e.key == pygame.K_e:
                    self.harvest_nearby()
                elif e.key == pygame.K_c:
                    self.camera.cycle_mode()
                elif e.key == pygame.K_PAGEUP:
                    self.camera.height_chase = max(2.0, self.camera.height_chase + 0.2)
                elif e.key == pygame.K_PAGEDOWN:
                    self.camera.height_chase = max(1.5, self.camera.height_chase - 0.2)
                elif e.key == pygame.K_k:
                    self.paused = not self.paused

                # --- Autopilot controls ---
                elif e.key == pygame.K_p:
                    # Finalize manual trace when switching to autopilot
                    if not self.auto.enabled:
                        self._finalize_manual_trace_segment()
                    self.auto.toggle()
                    if self.auto.enabled:
                        self.auto.align_to_vehicle(self.tractor)
                        self.autopilot_trace_points = []
                        self._record_autopilot_trace_point(force=True)
                    status = "ON" if self.auto.enabled else "OFF"
                    self._show_notification(f"Autopilot {status}")
                elif e.key == pygame.K_v:
                    self.auto.show_path = not self.auto.show_path
                elif e.key == pygame.K_u:
                    # Finalize current telemetry segment before teleport
                    self._finalize_telemetry_segment()
                    # Disable implements and autopilot before teleport,
                    # but KEEP the selected implement type.
                    # self.tractor.implement_enabled = False
                    # self.tractor.attached_implement = None  # <-- remove clearing, retain selection
                    self.auto.enabled = False
                    # Reset speeds to default
                    self.speed_scale = 1.0
                    self.time_scale = 1.0
                    self._teleport_vehicle_to_start()
                # elif e.key == pygame.K_F5:
                #     self._refresh_obstacles()
                #     self._teleport_vehicle_to_start()
                
                # --- Noise level toggle (N key) ---
                elif e.key == pygame.K_n:
                    # Cycle noise level 0 -> 1 -> 2 -> 0
                    current = getattr(self.tractor, "noise_level", self.tractor.NOISE_LEVEL)
                    new_level = (current + 1) % 3
                    self.tractor.set_noise_level(new_level)

                    # Optional: small HUD notification so you see the change
                    labels = ["Noise: OFF", "Noise: REALISTIC", "Noise: STRONG"]
                    label = labels[new_level] if 0 <= new_level < len(labels) else f"Noise level {new_level}"
                    self._show_notification(label)

                elif e.key == pygame.K_g:
                    print("G key pressed - loading GPS field")
                    try:
                        # Clear telemetry data to prevent line connection
                        self.trace_data = []
                        self.last_log_time = 0.0
                        
                        # Load sample GPS field for testing
                        self.load_sample_gps_field()
                        # Rebuild autopilot for new field dimensions
                        lane_spacing, margin, turn_inset = self._derive_autopilot_geometry()
                        self.auto = AutoPilot(
                            field_w=self.field_w,
                            field_h=self.field_h,
                            lane_spacing=lane_spacing,
                            margin=margin,
                            turn_inset=turn_inset,
                            soil_margin=self.SOIL_MARGIN
                        )
                        self._configure_autopilot_behavior()
                        self._refresh_obstacles()
                        self._teleport_vehicle_to_start()
                        print("GPS field loaded successfully!")
                    except Exception as e:
                        print(f"Error in G key handler: {e}")
                        import traceback
                        traceback.print_exc()

                # --- Time scaling ---
                elif e.key == pygame.K_1:
                    self.time_scale = 1.0
                elif e.key == pygame.K_2:
                    self.time_scale = 2.0
                elif e.key == pygame.K_3:
                    self.time_scale = 5.0
                

                # --- Autopilot speed / bias ---
                elif e.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                    if self.auto.enabled:
                        self.speed_scale = min(self.speed_scale_max, self.speed_scale + self.speed_scale_step)
                    elif self.camera.mode == CamMode.TOP or (pygame.key.get_mods() & pygame.KMOD_CTRL):
                        self.camera.top_zoom = max(4.0, self.camera.top_zoom - 1.0)
                elif e.key in (pygame.K_MINUS, pygame.K_UNDERSCORE, pygame.K_KP_MINUS):
                    if self.auto.enabled:
                        self.speed_scale = max(self.speed_scale_min, self.speed_scale - self.speed_scale_step)
                    elif self.camera.mode == CamMode.TOP or (pygame.key.get_mods() & pygame.KMOD_CTRL):
                        self.camera.top_zoom = min(150.0, self.camera.top_zoom + 1.0)
                # elif e.key == pygame.K_RIGHTBRACKET:
                #     self.steer_bias = min(self.steer_bias_max, self.steer_bias + self.steer_bias_step)
                # elif e.key == pygame.K_LEFTBRACKET:
                #     self.steer_bias = max(-self.steer_bias_max, self.steer_bias - self.steer_bias_step)
                # elif e.key == pygame.K_BACKSLASH:
                #     self.steer_bias = 0.0
                    
                # --- Overlay toggles ---
                elif e.key == pygame.K_F1:
                    self.show_furrows = not self.show_furrows
                elif e.key == pygame.K_F2:
                    self.show_sowing = not self.show_sowing
                elif e.key == pygame.K_F3:
                    self.show_spray = not self.show_spray
                elif e.key == pygame.K_t:
                    self.show_autopilot_trace = not self.show_autopilot_trace
                    
            elif e.type == pygame.MOUSEBUTTONDOWN:
                # Handle upload dialog clicks first
                if self.show_upload_dialog:
                    if hasattr(self, 'upload_yes_rect') and self.upload_yes_rect.collidepoint(e.pos):
                        self._handle_upload_yes()
                        return
                    elif hasattr(self, 'upload_no_rect') and self.upload_no_rect.collidepoint(e.pos):
                        self._handle_upload_no()
                        return
                    elif hasattr(self, 'upload_ok_rect') and self.upload_ok_rect.collidepoint(e.pos):
                        self._handle_upload_ok()
                        return
                    # Ignore other clicks when dialog is open
                    return
                
                if self.paused:
                    if self.resume_button_rect.collidepoint(e.pos):
                        self.paused = False
                    elif self.exit_button_rect.collidepoint(e.pos):
                        self.running = False
                # Click on AUTOPILOT HUD text
                if self.autopilot_hud_rect.collidepoint(e.pos):
                    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_p))
                    return

                else:
                    # U button click
                    if self.u_button_rect.collidepoint(e.pos):
                        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_u))
                    # Speed button click
                    elif self.speed_button_rect.collidepoint(e.pos):
                        self.show_speed_menu = not self.show_speed_menu
                    # Autopilot button click
                    elif self.autopilot_button_rect.collidepoint(e.pos):
                        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_p))
                        return
                    
                    # End simulation button click
                    elif self.end_sim_button_rect.collidepoint(e.pos):
                        self.paused = True
                        self.show_upload_dialog = True
                        return

                    # Help button click
                    elif self.help_button_rect.collidepoint(e.pos):
                        self.show_help = not self.show_help
                    # Implement menu clicks
                    elif self.implement_button_rect.collidepoint(e.pos):
                        self.show_implement_menu = not self.show_implement_menu
                    elif self.show_speed_menu:
                        clicked_speed = False
                        for speed in self.speed_options:
                            if speed in self.speed_menu_rects and self.speed_menu_rects[speed].collidepoint(e.pos):
                                self.time_scale = speed
                                self.show_speed_menu = False
                                clicked_speed = True
                                break
                        if not clicked_speed:
                            self.show_speed_menu = False
                    elif self.show_implement_menu:
                        # Implement switching is now disabled mid-session
                        for key in ('plow', 'sower', 'sprayer', 'irrigation', 'harvester'):
                            if self.implement_menu_rects[key].collidepoint(e.pos):
                                self._show_notification("Restart the sim to change implements.")
                                break
                        self.show_implement_menu = False
                    elif self.show_help:
                        # Close help overlay when clicking anywhere
                        self.show_help = False


    # -------------------------------------------------------------------------
    # Soil slip map
    # -------------------------------------------------------------------------
    def _slip_multiplier_at(self, x: float, z: float) -> float:
        """
        1.0 = normal grip.
        >1.0 = more slip / noise (wet / soft soil).
        You can tune the shapes later.
        """
        base = 1.0

        # Example: wet strip along the bottom (negative z)
        if z < -0.2 * self.field_h:
            base *= 1.6

        # Softer band in the center of the field
        if abs(x) < 0.15 * self.field_w:
            base *= 1.3

        # Harder soil near the top edge (less slip)
        if z > 0.3 * self.field_h:
            base *= 0.8

        return base
    # -------------------------------------------------------------------------
    # Update Logic
    # -------------------------------------------------------------------------
    def update(self, dt):
        # Decrement skip counter once per frame (not per substep)
        if self.skip_implement_frames > 0:
            self.skip_implement_frames -= 1
        
        dt_total = dt * self.time_scale
        MAX_SUBSTEP = 1.0 / 120.0
        steps = max(1, int(dt_total / MAX_SUBSTEP + 0.999))
        sub_dt = dt_total / steps

        for _ in range(steps):
            self.time += sub_dt
            field_limit = min(self.field_w, self.field_h) * 0.5
            # soil-dependent slip multiplier
            slip_mult = self._slip_multiplier_at(self.tractor.x, self.tractor.z)
            if self.auto.enabled:
                throttle, brake, steer_target = self.auto.control(
                    self.tractor, sub_dt,
                    speed_scale=self.speed_scale,
                    # steer_bias=self.steer_bias
                )
                self.tractor.steer = clamp(steer_target, -self.tractor.MAX_STEER, self.tractor.MAX_STEER)
                
                # Disable implements and autopilot when reaching end
                if self.auto.reached_end:
                    # Stop autopilot but keep the current implement state so it remains attached
                    self.auto.enabled = False
                    self._show_notification("Autopilot drive completed!")

                class FakeKeys(dict):
                    def __getitem__(self, k):
                        return dict.get(self, k, False)

                keys = FakeKeys({
                    pygame.K_w: bool(throttle),
                    pygame.K_s: bool(brake),
                    pygame.K_a: False,
                    pygame.K_d: False,
                })
                # CHANGED: pass slip_mult
                self.tractor.update(sub_dt, keys, field_limit, slip_mult=slip_mult)
                self._record_autopilot_trace_point()
            else:
                # CHANGED: pass slip_mult and collision fn
                self.tractor.update(
                    sub_dt,
                    pygame.key.get_pressed(),
                    field_limit,
                    self._check_collision,
                    slip_mult=slip_mult,
                )
            # GNSS noisy pose (used for visual trace + logs)
            noisy_x, noisy_y, noisy_z, noisy_yaw = self.tractor.get_noisy_pose()
            self.latest_noisy_pose = (noisy_x, noisy_y, noisy_z, noisy_yaw)
            self._record_gnss_trace_point(noisy_x, noisy_z)    
            # keep tractor in bounds
            half_w = self.field_w * 0.5
            half_h = self.field_h * 0.5
            margin = 1.0
            self.tractor.x = clamp(self.tractor.x, -half_w + margin, half_w - margin)
            self.tractor.z = clamp(self.tractor.z, -half_h + margin, half_h - margin)
            
            # Update position tracking at end
            self.last_tractor_pos = (self.tractor.x, self.tractor.z)
            
            # Record manual trace when not on autopilot
            if not self.auto.enabled:
                self._record_manual_trace_point()

            # --- Record multiple furrow lines when plow is ON ---
            if self.skip_implement_frames == 0 and getattr(self.tractor, "implement_enabled", False) and str(getattr(self.tractor, "attached_implement", "")) == "ImplementType.PLOW":
                # Skip if moving too fast (teleportation)
                if abs(self.tractor.speed) > 50.0:
                    continue
                    
                fx, fz = self.tractor.forward_vec()

                # Position plow in front of tractor at -2.0m
                px = self.tractor.x + fx * -2.0
                pz = self.tractor.z + fz * -2.0

                # Vector perpendicular to tractor direction
                perp_x, perp_z = -fz, fx
                width = self.tractor.spec.working_width
                num_lines = max(3, int(width / 1.5))  # Match implement
                plow_width = width * 0.7
                line_spacing = plow_width / num_lines if num_lines > 1 else 0.5

                # Center furrows across plow width
                half_span = (num_lines - 1) * line_spacing * 0.5
                blade_positions = [
                    (px + perp_x * (i * line_spacing - half_span),
                    pz + perp_z * (i * line_spacing - half_span))
                    for i in range(num_lines)
                ]

                # Record each blade's furrow path (only if arrays exist)
                if not hasattr(self, "multi_furrow_points"):
                    continue
                
                destroyed_crops = []
                for i, (bx, bz) in enumerate(blade_positions):
                    # Only record if within field boundaries
                    if abs(bx) <= half_w and abs(bz) <= half_h:
                        # Destroy crops near plow blade (use spatial query)
                        nearby = self._query_crops_in_radius(bx, bz, 1.5)
                        for crop in nearby:
                            crop.harvested = True
                            destroyed_crops.append(crop)
                        
                        furrow = self.multi_furrow_points[i]
                        if not furrow:
                            furrow.append((bx, bz))
                        else:
                            lx, lz = furrow[-1]
                            dx, dz = bx - lx, bz - lz
                            if (dx * dx + dz * dz) >= (self.FURROW_SPACING ** 2):
                                furrow.append((bx, bz))
                                # Limit trail length
                                if len(furrow) > self.MAX_TRAIL_POINTS // 10:
                                    furrow.pop(0)
                
                # Remove destroyed crops from grid and list (batch operation)
                for c in destroyed_crops:
                    grid_x = int(c.x // PLANT_SPACING)
                    grid_z = int(c.z // PLANT_SPACING)
                    self.crop_grid.pop((grid_x, grid_z), None)
                if destroyed_crops:
                    self.crops = [c for c in self.crops if not c.harvested]

            # --- Record sowing trail + auto-plant crops when SOWER is ON ---
            if (
                self.skip_implement_frames == 0
                and getattr(self.tractor, "implement_enabled", False)
                and str(getattr(self.tractor, "attached_implement", "")) == "ImplementType.SOWER"
            ):
                # Skip if moving too fast (teleportation)
                if abs(self.tractor.speed) > 50.0:
                    continue  # skip this frame

                fx, fz = self.tractor.forward_vec()
                px = self.tractor.x + fx * -2.0
                pz = self.tractor.z + fz * -2.0

                # Store seed trails on both sides
                perp_x, perp_z = -fz, fx
                offset = self.tractor.spec.working_width * 0.3

                # Initialize sowing_points if needed
                if not hasattr(self, "sowing_points"):
                    new_session = self._make_trail_buffer()
                    self.sowing_points = new_session
                    if not hasattr(self, "all_sowing_sessions"):
                        self.all_sowing_sessions = []
                    self.all_sowing_sessions.append(new_session)

                # sample sowing less frequently to reduce per-frame work
                if (self._frame_counter % self.sow_record_rate) == 0:
                    for side in (-1, 1):
                        sx = px + perp_x * side * offset
                        sz = pz + perp_z * side * offset

                        if abs(sx) <= half_w and abs(sz) <= half_h:
                            if not self.sowing_points:
                                self.sowing_points.append((sx, sz))
                            else:
                                lx, lz = self.sowing_points[-1]
                                dx, dz = sx - lx, sz - lz
                                if (dx * dx + dz * dz) >= (self.FURROW_SPACING ** 2):
                                    self.sowing_points.append((sx, sz))

                # auto-plant crops every few meters
                if not hasattr(self, "_last_sow_pos"):
                    self._last_sow_pos = (self.tractor.x, self.tractor.z)
                lx, lz = self._last_sow_pos
                dx = self.tractor.x - lx
                dz = self.tractor.z - lz
                if dx * dx + dz * dz >= (PLANT_SPACING * 4.0) ** 2:
                    self.plant_crop()
                    self._last_sow_pos = (self.tractor.x, self.tractor.z)
            else:
                if hasattr(self, "_last_sow_pos"):
                    del self._last_sow_pos

            # --- Record multiple spray lines when SPRAYER is ON ---
            if self.skip_implement_frames == 0 and getattr(self.tractor, "implement_enabled", False) and str(getattr(self.tractor, "attached_implement", "")) == "ImplementType.SPRAYER":
                # Skip if moving too fast (teleportation)
                if abs(self.tractor.speed) > 50.0:
                    continue
                    
                fx, fz = self.tractor.forward_vec()
                px = self.tractor.x + fx * -2.0
                pz = self.tractor.z + fz * -2.0

                # Vector perpendicular to tractor direction
                perp_x, perp_z = -fz, fx
                width = self.tractor.spec.working_width
                num_lines = max(3, int(width / 2.0))
                spray_width = width * 0.8
                line_spacing = spray_width / num_lines if num_lines > 1 else 0.5

                # Center spray lines across boom width
                half_span = (num_lines - 1) * line_spacing * 0.5
                nozzle_positions = [
                    (px + perp_x * (i * line_spacing - half_span),
                    pz + perp_z * (i * line_spacing - half_span))
                    for i in range(num_lines)
                ]

                # Record each nozzle's spray path
                if not hasattr(self, "multi_spray_points"):
                    self.multi_spray_points = [[] for _ in range(num_lines)]

                for i, (sx, sz) in enumerate(nozzle_positions):
                    # Only record if within field boundaries
                    if abs(sx) <= half_w and abs(sz) <= half_h:
                        spray_line = self.multi_spray_points[i]
                        if not spray_line:
                            spray_line.append((sx, sz))
                        else:
                            lx, lz = spray_line[-1]
                            dx, dz = sx - lx, sz - lz
                            if (dx * dx + dz * dz) >= (self.FURROW_SPACING ** 2):
                                spray_line.append((sx, sz))
                                # Limit trail length
                                if len(spray_line) > self.MAX_TRAIL_POINTS // 10:
                                    spray_line.pop(0)
                        
                        # Mark nearby crops as sprayed
                        nearby = self._query_crops_in_radius(sx, sz, 2.0)
                        for crop in nearby:
                            if not getattr(crop, 'sprayed', False):
                                crop.sprayed = True

            # --- Record irrigation lines when IRRIGATION is ON ---
            if self.skip_implement_frames == 0 and getattr(self.tractor, "implement_enabled", False) and str(getattr(self.tractor, "attached_implement", "")) == "ImplementType.IRRIGATION":
                if abs(self.tractor.speed) <= 50.0:
                    fx, fz = self.tractor.forward_vec()
                    px = self.tractor.x + fx * -2.0
                    pz = self.tractor.z + fz * -2.0
                    perp_x, perp_z = -fz, fx
                    width = self.tractor.spec.working_width
                    num_lines = 4  # 2 lines on each side of tractor
                    
                    if not hasattr(self, "multi_irrigation_points") or len(self.multi_irrigation_points) != num_lines:
                        self.multi_irrigation_points = [[] for _ in range(num_lines)]

                    # Create 2 nozzles on each side near sowing lines
                    positions = [
                        -width * 0.35,  # Left outer
                        -width * 0.25,  # Left inner
                        width * 0.25,   # Right inner
                        width * 0.35    # Right outer
                    ]
                    
                    for i, offset in enumerate(positions):
                        ix = px + perp_x * offset
                        iz = pz + perp_z * offset
                        if abs(ix) <= half_w and abs(iz) <= half_h:
                            irrigation_line = self.multi_irrigation_points[i]
                            if not irrigation_line or (ix - irrigation_line[-1][0])**2 + (iz - irrigation_line[-1][1])**2 >= self.FURROW_SPACING**2:
                                irrigation_line.append((ix, iz))
                                if len(irrigation_line) > self.MAX_TRAIL_POINTS // 10:
                                    irrigation_line.pop(0)
                            
                            nearby = self._query_crops_in_radius(ix, iz, 2.0)
                            for crop in nearby:
                                if not getattr(crop, 'watered', False):
                                    crop.watered = True

            # --- Auto-harvest when HARVESTER is ON ---
            if self.skip_implement_frames == 0 and getattr(self.tractor, "implement_enabled", False) and str(getattr(self.tractor, "attached_implement", "")) == "ImplementType.HARVESTER":
                if abs(self.tractor.speed) <= 50.0:
                    fx, fz = self.tractor.forward_vec()
                    px = self.tractor.x + fx * 0.6
                    pz = self.tractor.z + fz * 0.6
                    
                    if not hasattr(self, "harvest_points"):
                        self.harvest_points = []
                    
                    if abs(px) <= half_w and abs(pz) <= half_h:
                        if not self.harvest_points or (px - self.harvest_points[-1][0])**2 + (pz - self.harvest_points[-1][1])**2 >= self.FURROW_SPACING**2:
                            self.harvest_points.append((px, pz))

                    width = self.tractor.spec.working_width
                    perp_x, perp_z = -fz, fx
                    harvest_width = width * 0.9
                    
                    harvest_radius = math.hypot(harvest_width * 0.5, 2.0) + PLANT_SPACING
                    candidates = self._query_crops_in_radius(px, pz, harvest_radius)
                    harvested_crops = []
                    for crop in candidates:
                        if crop.growth(self.time) < 0.999:
                            continue
                        crop_vec_x, crop_vec_z = crop.x - px, crop.z - pz
                        lateral_dist = abs(crop_vec_x * perp_x + crop_vec_z * perp_z)
                        forward_dist = abs(crop_vec_x * fx + crop_vec_z * fz)
                        if lateral_dist <= harvest_width / 2 and forward_dist <= 2.0:
                            crop.harvested = True
                            harvested_crops.append(crop)
                            self.score += 1

                    if harvested_crops:
                        self._prune_harvested(harvested_crops)
                
        self.last_meas_pose = self.tractor.get_noisy_pose()
        # Telemetry logging (true pose + noisy GNSS/IMU)
        if self.time - self.last_log_time >= LOG_INTERVAL:
            self.last_log_time = self.time

            x, y, z, yaw = self.tractor.get_pose()
            mx, my, mz, myaw = self.tractor.get_noisy_pose()

            # append to GNSS polyline (magenta)
            if not self.gnss_points:
                self.gnss_points.append((mx, mz))
            else:
                lx, lz = self.gnss_points[-1]
                dx = mx - lx
                dz = mz - lz
                # avoid crazy spikes / teleports
                if dx*dx + dz*dz < 25.0:  # max 5 m between samples
                    self.gnss_points.append((mx, mz))
                else:
                    # start a new “segment” by just continuing but without the big jump
                    self.gnss_points.append((mx, mz))

            # trim GNSS buffer
            if len(self.gnss_points) > self.MAX_GNSS_POINTS:
                self.gnss_points = self.gnss_points[-self.MAX_GNSS_POINTS:]

            # log both true and noisy pose
            self.trace_data.append({
                "sim_time": round(self.time, 3),
                "real_time": datetime.now().isoformat(timespec="milliseconds"),

                "x": round(x, 3),
                "y": round(y, 3),
                "z": round(z, 3),
                "yaw": round(yaw, 4),

                "gps_x": round(mx, 3),
                "gps_y": round(my, 3),
                "gps_z": round(mz, 3),
                "gps_yaw": round(myaw, 4),

                "speed": round(self.tractor.speed, 3),
                "noise_level": int(self.tractor.NOISE_LEVEL),
            })



    def _record_manual_trace_point(self):
        """Append tractor position to the current manual-driving trace."""
        pt = (self.tractor.x, self.tractor.z)
        if not self.current_manual_trace:
            self.current_manual_trace.append(pt)
            return

        lx, lz = self.current_manual_trace[-1]
        dx = pt[0] - lx
        dz = pt[1] - lz
        if (dx * dx + dz * dz) >= (self.MANUAL_TRACE_SPACING ** 2):
            self.current_manual_trace.append(pt)
            if len(self.current_manual_trace) > self.MANUAL_TRACE_MAX_POINTS:
                # keep recent points to avoid unbounded growth
                overflow = len(self.current_manual_trace) - self.MANUAL_TRACE_MAX_POINTS
                if overflow > 0:
                    self.current_manual_trace = self.current_manual_trace[overflow:]

    def _finalize_manual_trace_segment(self):
        """Store the current manual trace as a finished segment."""
        if not self.current_manual_trace:
            return
        self.manual_trace_sessions.append(self.current_manual_trace)
        if len(self.manual_trace_sessions) > self.MANUAL_TRACE_MAX_SESSIONS:
            self.manual_trace_sessions.pop(0)
        self.current_manual_trace = []

    def _record_autopilot_trace_point(self, force: bool = False):
        if not self.auto.enabled:
            return
        pt = (self.tractor.x, self.tractor.z)
        if not self.autopilot_trace_points:
            self.autopilot_trace_points.append(pt)
            return
        lx, lz = self.autopilot_trace_points[-1]
        dx = pt[0] - lx
        dz = pt[1] - lz
        if force or (dx * dx + dz * dz) >= self.AUTO_TRACE_SPACING * self.AUTO_TRACE_SPACING:
            self.autopilot_trace_points.append(pt)
            if len(self.autopilot_trace_points) > self.MANUAL_TRACE_MAX_POINTS:
                overflow = len(self.autopilot_trace_points) - self.MANUAL_TRACE_MAX_POINTS
                if overflow > 0:
                    self.autopilot_trace_points = self.autopilot_trace_points[overflow:]

    def _record_gnss_trace_point(self, noisy_x: float, noisy_z: float):
        """Store path of noisy GNSS pose for visualization."""
        pt = (noisy_x, noisy_z)
        if not self.gnss_trace_points:
            self.gnss_trace_points.append(pt)
            return
        lx, lz = self.gnss_trace_points[-1]
        dx = pt[0] - lx
        dz = pt[1] - lz
        if dx * dx + dz * dz >= self.GNSS_TRACE_SPACING ** 2:
            self.gnss_trace_points.append(pt)
            if len(self.gnss_trace_points) > self.MANUAL_TRACE_MAX_POINTS:
                overflow = len(self.gnss_trace_points) - self.MANUAL_TRACE_MAX_POINTS
                if overflow > 0:
                    self.gnss_trace_points = self.gnss_trace_points[overflow:]
    def _teleport_vehicle_to_start(self):
        """Teleport helper that keeps manual trace segments discrete."""
        self._finalize_manual_trace_segment()
        self.autopilot_trace_points = []
        self.manual_trace_sessions.clear()
        self.current_manual_trace = []
        # Reset any path tracing visuals so a teleport feels like a clean start.
        if hasattr(self, "gnss_points"):
            self.gnss_points.clear()
        if hasattr(self, "gnss_trace_points"):
            self.gnss_trace_points.clear()
        self._clear_implement_trails()
        self.auto.teleport_to_start(self.tractor)
        # NOTE: do NOT change implement selection here; only position/yaw is reset.
    
    def _clear_implement_trails(self):
        """Remove all implement trail buffers so teleporting yields a blank field."""
        def _clear_nested_lists(container):
            if not isinstance(container, list):
                return
            for entry in container:
                if hasattr(entry, "clear"):
                    entry.clear()

        def _clear_sessions(sessions, nested=False):
            if not isinstance(sessions, list):
                return
            for session in sessions:
                if nested and isinstance(session, list):
                    _clear_nested_lists(session)
                elif hasattr(session, "clear"):
                    session.clear()

        # Plow / furrow lines (sessions are lists-of-lists)
        if hasattr(self, "all_furrow_sessions"):
            _clear_sessions(self.all_furrow_sessions, nested=True)
        if hasattr(self, "multi_furrow_points"):
            _clear_nested_lists(self.multi_furrow_points)

        # Sower seed drops
        if hasattr(self, "all_sowing_sessions"):
            _clear_sessions(self.all_sowing_sessions)
        if hasattr(self, "sowing_points") and hasattr(self.sowing_points, "clear"):
            self.sowing_points.clear()

        # Sprayer droplets
        if hasattr(self, "all_spray_sessions"):
            _clear_sessions(self.all_spray_sessions, nested=True)
        if hasattr(self, "multi_spray_points"):
            _clear_nested_lists(self.multi_spray_points)

        # Irrigation water lines
        if hasattr(self, "all_irrigation_sessions"):
            _clear_sessions(self.all_irrigation_sessions, nested=True)
        if hasattr(self, "multi_irrigation_points"):
            _clear_nested_lists(self.multi_irrigation_points)

        # Harvester breadcrumb trail
        if hasattr(self, "all_harvest_sessions"):
            _clear_sessions(self.all_harvest_sessions)
        if hasattr(self, "harvest_points") and isinstance(self.harvest_points, list):
            self.harvest_points.clear()
    
    def _make_trail_buffer(self, max_points: Optional[int] = None):
        """Return a deque configured to drop old points in O(1) time."""
        limit = max_points if max_points is not None else getattr(self, "MAX_TRAIL_POINTS", 2000)
        limit = max(1, int(limit))
        return deque(maxlen=limit)
    
    def _finalize_telemetry_segment(self):
        """Store current telemetry data as a completed segment and start fresh."""
        if self.trace_data:
            self.trace_segments.append(self.trace_data.copy())
            self.trace_data = []  # Start new segment
            self.last_log_time = 0.0


    # --- 2D overlay helpers (OpenGL) ---
    def _begin_2d(self):
        glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)
        glDisable(GL_CULL_FACE)
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.width, self.height, 0, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()

    def _end_2d(self):
        glMatrixMode(GL_MODELVIEW)
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glEnable(GL_LIGHTING)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)

    def _draw_rect(self, x, y, w, h, rgba):
        r, g, b, a = rgba
        glColor4f(r/255.0, g/255.0, b/255.0, a/255.0)
        glBegin(GL_QUADS)
        glVertex2f(x,     y)
        glVertex2f(x + w, y)
        glVertex2f(x + w, y + h)
        glVertex2f(x,     y + h)
        glEnd()

    def _draw_u_button_with_arrow(self, rect, mx, my):
        hovered = rect.collidepoint((mx, my))
        if hovered:
            bg_color = (80, 140, 60, 220)
            border_color = (120, 180, 60, 255)
        else:
            bg_color = (45, 85, 35, 200)
            border_color = (80, 140, 60, 255)
        
        # Background
        self._draw_rect(rect.x, rect.y, rect.width, rect.height, bg_color)
        # Border
        self._draw_rect(rect.x, rect.y, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y + rect.height - 2, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y, 2, rect.height, border_color)
        self._draw_rect(rect.x + rect.width - 2, rect.y, 2, rect.height, border_color)
        
        # Draw simple left arrow
        cx = rect.x + rect.width // 2
        cy = rect.y + rect.height // 2
        
        glDisable(GL_TEXTURE_2D)
        glColor4f(1.0, 1.0, 1.0, 1.0)
        glLineWidth(2.5)
        
        # Arrow shaft
        glBegin(GL_LINES)
        glVertex2f(cx - 6, cy)
        glVertex2f(cx + 6, cy)
        glEnd()
        
        # Arrow head
        glBegin(GL_LINES)
        glVertex2f(cx - 6, cy)
        glVertex2f(cx - 2, cy - 4)
        glVertex2f(cx - 6, cy)
        glVertex2f(cx - 2, cy + 4)
        glEnd()
        
        glLineWidth(1.0)
    
    def _draw_end_sim_button(self, rect, mx, my):
        hovered = rect.collidepoint((mx, my))
        if hovered:
            bg_color = (140, 80, 60, 220)
            border_color = (255, 150, 100, 255)
        else:
            bg_color = (85, 45, 35, 200)
            border_color = (140, 80, 60, 255)
        
        # Background
        self._draw_rect(rect.x, rect.y, rect.width, rect.height, bg_color)
        # Border
        self._draw_rect(rect.x, rect.y, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y + rect.height - 2, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y, 2, rect.height, border_color)
        self._draw_rect(rect.x + rect.width - 2, rect.y, 2, rect.height, border_color)
        
        # Draw X symbol for end
        cx = rect.x + rect.width // 2
        cy = rect.y + rect.height // 2
        
        glDisable(GL_TEXTURE_2D)
        glColor4f(1.0, 1.0, 1.0, 1.0)
        glLineWidth(3.0)
        glBegin(GL_LINES)
        glVertex2f(cx - 8, cy - 8)
        glVertex2f(cx + 8, cy + 8)
        glVertex2f(cx - 8, cy + 8)
        glVertex2f(cx + 8, cy - 8)
        glEnd()
        glLineWidth(1.0)
    
    def _draw_u_button(self, rect, text, mx, my):
        hovered = rect.collidepoint((mx, my))
        if hovered:
            bg_color = (100, 140, 200, 220)
            border_color = (150, 180, 255, 255)
        else:
            bg_color = (70, 100, 160, 200)
            border_color = (120, 150, 220, 255)
        
        # Background
        self._draw_rect(rect.x, rect.y, rect.width, rect.height, bg_color)
        # Border
        self._draw_rect(rect.x, rect.y, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y + rect.height - 2, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y, 2, rect.height, border_color)
        self._draw_rect(rect.x + rect.width - 2, rect.y, 2, rect.height, border_color)
        
        # Text with better padding
        text_color = (255, 255, 255, 255)
        text_w = self.ui_font.size(text)[0]
        text_x = rect.x + (rect.width - text_w) // 2
        text_y = rect.y + (rect.height - self.ui_font.get_height()) // 2 + 1
        self._draw_text(text, text_x, text_y, self.ui_font, text_color)
    
    def _draw_implement_button(self, rect, text, active, mx, my):
        hovered = rect.collidepoint((mx, my))
        if active:
            bg_color = (60, 120, 40, 200) if not hovered else (80, 140, 60, 220)
            border_color = (120, 180, 60, 255)
        else:
            bg_color = (25, 55, 30, 180) if not hovered else (45, 85, 35, 200)
            border_color = (80, 140, 60, 200)
        
        # Background
        self._draw_rect(rect.x, rect.y, rect.width, rect.height, bg_color)
        # Border
        self._draw_rect(rect.x, rect.y, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y + rect.height - 2, rect.width, 2, border_color)
        self._draw_rect(rect.x, rect.y, 2, rect.height, border_color)
        self._draw_rect(rect.x + rect.width - 2, rect.y, 2, rect.height, border_color)
        
        # Text with better padding
        text_color = (255, 255, 255, 255) if active else (180, 180, 180, 255)
        text_w = self.ui_font.size(text)[0]
        text_x = rect.x + (rect.width - text_w) // 2
        text_y = rect.y + (rect.height - self.ui_font.get_height()) // 2 + 1
        self._draw_text(text, text_x, text_y, self.ui_font, text_color)
    
    def _draw_menu_item(self, rect, text, active, mx, my):
        hovered = rect.collidepoint((mx, my))
        
        if active:
            # Active item - John Deere green gradient
            for i in range(rect.height):
                t = i / rect.height
                r = int(80 - t * 20)   # 80 -> 60
                g = int(160 - t * 20)  # 160 -> 140
                b = int(50 - t * 10)   # 50 -> 40
                alpha = 220 - int(i * 2)
                self._draw_rect(rect.x, rect.y + i, rect.width, 1, (r, g, b, alpha))
            # Active border with glow
            self._draw_rect(rect.x, rect.y, rect.width, 1, (150, 220, 100, 255))
            self._draw_rect(rect.x, rect.y + rect.height - 1, rect.width, 1, (150, 220, 100, 255))
        elif hovered:
            # Hover effect - warm yellow gradient
            for i in range(rect.height):
                t = i / rect.height
                r = int(100 + t * 20)  # 100 -> 120
                g = int(100 + t * 20)  # 100 -> 120
                b = int(40 + t * 10)   # 40 -> 50
                alpha = 180 - int(i * 1.5)
                self._draw_rect(rect.x, rect.y + i, rect.width, 1, (r, g, b, alpha))
            # Hover highlight
            self._draw_rect(rect.x, rect.y, rect.width, 1, (200, 200, 100, 200))
        
        # Text with improved padding
        text_color = (255, 255, 255, 255) if active else (220, 220, 220, 255) if hovered else (180, 180, 180, 255)
        text_x = rect.x + 15
        text_y = rect.y + (rect.height - self.ui_font.get_height()) // 2 + 1
        self._draw_text(text, text_x, text_y, self.ui_font, text_color)
    
    def _draw_circle(self, x, y, radius, color):
        """Draw a filled circle using OpenGL"""
        if radius <= 0:
            return
        r, g, b, a = color
        glColor4f(r/255.0, g/255.0, b/255.0, a/255.0)
        glBegin(GL_TRIANGLE_FAN)
        glVertex2f(x, y)  # center
        segments = max(8, int(radius * 2))  # adaptive segments
        for i in range(segments + 1):
            angle = 2.0 * math.pi * i / segments
            glVertex2f(x + math.cos(angle) * radius, y + math.sin(angle) * radius)
        glEnd()
    
    def _draw_circle_border(self, x, y, radius, color):
        """Draw a circle border using OpenGL"""
        if radius <= 0:
            return
        r, g, b, a = color
        glColor4f(r/255.0, g/255.0, b/255.0, a/255.0)
        glLineWidth(2.0 * min(1.0, radius / 50.0))  # adaptive line width
        glBegin(GL_LINE_LOOP)
        segments = max(8, int(radius * 2))
        for i in range(segments):
            angle = 2.0 * math.pi * i / segments
            glVertex2f(x + math.cos(angle) * radius, y + math.sin(angle) * radius)
        glEnd()
        glLineWidth(1.0)

    def _draw_text(self, text, x, y, font, color=(255,255,255,255)):
    # --- 1) Render pygame surface (no manual flips here) ---
        surf = font.render(text, True, (color[0], color[1], color[2]))
        w, h = surf.get_width(), surf.get_height()

        # --- 2) Ask pygame to give us a V-FLIPPED buffer for OpenGL bottom-left origin
        data = pygame.image.tostring(surf, "RGBA", True)  # True = flip vertically

        # --- 3) Upload as texture ---
        tex_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, tex_id)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data)

        # --- 4) Draw quad in TOP-LEFT screen coords (glOrtho(0,w,h,0,...)) ---
        # Map (u,v)=(0,0) to *bottom-left* of the quad, so use y+h first.
        glEnable(GL_TEXTURE_2D)
        glColor4f(1, 1, 1, color[3] / 255.0)

        glBegin(GL_QUADS)
        glTexCoord2f(0.0, 0.0); glVertex2f(x,     y + h)  # bottom-left
        glTexCoord2f(1.0, 0.0); glVertex2f(x + w, y + h)  # bottom-right
        glTexCoord2f(1.0, 1.0); glVertex2f(x + w, y)      # top-right
        glTexCoord2f(0.0, 1.0); glVertex2f(x,     y)      # top-left
        glEnd()

        glDisable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, 0)
        glDeleteTextures(int(tex_id))
    
    def _show_notification(self, text):
        """Display a temporary notification message."""
        self.notification_text = text
        self.notification_time = self.time
    
    def _draw_notifications(self):
        """Draw active notifications with soft fade and motion easing."""
        if not self.notification_text or self.time - self.notification_time > self.notification_duration:
            return
        
        self._begin_2d()
        
        elapsed = self.time - self.notification_time
        t = elapsed / self.notification_duration
        
        # Smooth fade with ease-out curve
        fade = 1.0 - t * t * (3.0 - 2.0 * t)  # smoothstep
        alpha = int(255 * fade)
        
        # Gentle slide-down motion with ease-out
        slide_t = min(1.0, elapsed * 4.0)  # faster initial motion
        ease_slide = slide_t * slide_t * (3.0 - 2.0 * slide_t)
        y_offset = int(20 * (1.0 - ease_slide))
        
        text_w = self.ui_font.size(self.notification_text)[0]
        x = (self.width - text_w) // 2
        y = 60 - y_offset
        
        # Soft background with rounded effect
        bg_pad = 16
        bg_alpha = max(20, alpha // 3)
        self._draw_rect(x - bg_pad, y - 6, text_w + bg_pad * 2, 36, (0, 0, 0, bg_alpha))
        
        # Subtle glow effect
        glow_alpha = alpha //  4
        self._draw_rect(x - bg_pad - 2, y - 8, text_w + bg_pad * 2 + 4, 40, (255, 255, 100, glow_alpha))
        
        self._draw_text(self.notification_text, x, y, self.ui_font, (255, 255, 150, alpha))
        
        self._end_2d()

    # -------------------------------------------------------------------------
    # Render
    # -------------------------------------------------------------------------
    def render(self):
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        # frame counter used for optional throttles / cache policies
        self._frame_counter += 1
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        self.camera.apply(self.tractor, self.width, self.height)

        top_mode = (self.camera.mode == CamMode.TOP)
        if top_mode:
            glDisable(GL_LIGHTING)

        draw_ground(self.field_w, self.field_h, season=self.season)

        # --- Draw all plow furrows (keep previous sessions visible) ---
        if self.show_furrows and hasattr(self, "all_furrow_sessions"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)

            glColor3f(0.55, 0.25, 0.08)
            glLineWidth(3.0)
            tx, tz = self.tractor.x, self.tractor.z
            render_dist_sq = 10000  # 100m
            # draw every session stored so far
            for session in self.all_furrow_sessions:
                for furrow in session:
                    if not furrow:
                        continue
                    glBegin(GL_LINE_STRIP)
                    for (x, z) in furrow:
                        if (x - tx)**2 + (z - tz)**2 <= render_dist_sq:
                            glVertex3f(x, 0.05, z)
                    glEnd()

            if was_light:
                glEnable(GL_LIGHTING)

        # --- Draw manual traces (red lines) ---
        if hasattr(self, "manual_trace_sessions"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)
            glLineWidth(2.8)
            glColor3f(0.95, 0.15, 0.15)  # red for manual traces
            for segment in self.manual_trace_sessions:
                if len(segment) < 2:
                    continue
                glBegin(GL_LINE_STRIP)
                for (x, z) in segment:
                    glVertex3f(x, 0.1, z)
                glEnd()
            # Draw current trace
            if len(self.current_manual_trace) > 1:
                glBegin(GL_LINE_STRIP)
                for (x, z) in self.current_manual_trace:
                    glVertex3f(x, 0.1, z)
                glEnd()
            if was_light:
                glEnable(GL_LIGHTING)
        # --- Draw GNSS noisy path (magenta) ---
        if self.gnss_points:
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)

            glLineWidth(2.0)
            glColor3f(1.0, 0.0, 1.0)  # magenta
            glBegin(GL_LINE_STRIP)
            for (x, z) in self.gnss_points:
                glVertex3f(x, 0.12, z)
            glEnd()

            if was_light:
                glEnable(GL_LIGHTING)


        # --- Draw sowing trails (dotted seed drops) ---
        if self.show_sowing and hasattr(self, "all_sowing_sessions"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)
            glColor3f(0.55, 0.42, 0.25)  # light brown soil tone
            glPointSize(4.0)  # make dots visible
            tx, tz = self.tractor.x, self.tractor.z
            render_dist_sq = 10000  # 100m
            for session in self.all_sowing_sessions:
                if not session:
                    continue
                glBegin(GL_POINTS)
                for (x, z) in session:
                    if (x - tx)**2 + (z - tz)**2 <= render_dist_sq:
                        glVertex3f(x, 0.05, z)
                glEnd()
            if was_light:
                glEnable(GL_LIGHTING)

        # --- Draw spray trails (dotted droplets) ---
        if self.show_spray and hasattr(self, "all_spray_sessions"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)

            glColor3f(0.3, 0.7, 1.0)
            glPointSize(3.0)
            tx, tz = self.tractor.x, self.tractor.z
            render_dist_sq = 10000  # 100m
            for session in self.all_spray_sessions:
                for spray_line in session:
                    if not spray_line:
                        continue
                    glBegin(GL_POINTS)
                    for (x, z) in spray_line:
                        if (x - tx)**2 + (z - tz)**2 <= render_dist_sq:
                            glVertex3f(x, 0.06, z)
                    glEnd()

            if was_light:
                glEnable(GL_LIGHTING)

        # --- Draw irrigation trails (cyan water droplets) ---
        if hasattr(self, "all_irrigation_sessions"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)

            glColor3f(0.0, 0.8, 1.0)  # cyan water color
            glPointSize(6.0)  # larger water droplet size for irrigation
            tx, tz = self.tractor.x, self.tractor.z
            render_dist_sq = 10000  # 100m
            for session in self.all_irrigation_sessions:
                for irrigation_line in session:
                    if not irrigation_line:
                        continue
                    glBegin(GL_POINTS)
                    for (x, z) in irrigation_line:
                        if (x - tx)**2 + (z - tz)**2 <= render_dist_sq:
                            glVertex3f(x, 0.07, z)
                    glEnd()

            if was_light:
                glEnable(GL_LIGHTING)
        
        # --- Draw current irrigation trails ---
        if hasattr(self, "multi_irrigation_points"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)

            glColor3f(0.0, 0.8, 1.0)  # cyan water color
            glPointSize(6.0)
            tx, tz = self.tractor.x, self.tractor.z
            render_dist_sq = 10000  # 100m
            for irrigation_line in self.multi_irrigation_points:
                if not irrigation_line:
                    continue
                glBegin(GL_POINTS)
                for (x, z) in irrigation_line:
                    if (x - tx)**2 + (z - tz)**2 <= render_dist_sq:
                        glVertex3f(x, 0.07, z)
                glEnd()

            if was_light:
                glEnable(GL_LIGHTING)

        # --- Draw harvest trails (golden dots) ---
        if hasattr(self, "all_harvest_sessions"):
            was_light = glIsEnabled(GL_LIGHTING)
            if was_light:
                glDisable(GL_LIGHTING)

            glColor3f(0.9, 0.7, 0.1)  # golden harvest color
            glPointSize(5.0)  # harvest dot size
            for session in self.all_harvest_sessions:
                if not session:
                    continue
                glBegin(GL_POINTS)
                for (x, z) in session:
                    glVertex3f(x, 0.08, z)
                glEnd()

            if was_light:
                glEnable(GL_LIGHTING)



        self.auto.draw()
        if self.obstacles:
            draw_obstacles(self.obstacles, season=self.season)
        now = self.time
        tx, tz = self.tractor.x, self.tractor.z
        
        # Get camera position for LOD
        camera_pos = self.camera.get_position(self.tractor)
        
        # Render crops with LOD and distance culling
        for c in self.crops:
            draw_crop(c, now, season=self.season, camera_pos=camera_pos)
        draw_tractor_john_deere(self.tractor)

        if top_mode:
            glEnable(GL_LIGHTING)

        ap_status = "AP:on" if self.auto.enabled else "AP:off"
        zoom_txt = f" | Zoom:{self.camera.top_zoom:.1f}m" if top_mode else ""
        layout_txt = "Obstacles" if self.obstacles_enabled else "Clear"
        pygame.display.set_caption(
            f"JD Farm v2 | {ap_status} | Sim x{self.time_scale:.1f}"
            f" | Cam:{self.camera.mode.name}{zoom_txt}"
            f" | Vehicle:{self.vehicle_name}"
            f" | Score:{self.score}"
            f" | Field:{self.field_w:.1f}×{self.field_h:.1f}m"
            f" | Map:{self.field_map_name} ({layout_txt})"
            f" | Season:{self.season}"
            f" | Speed:{self.tractor.speed:.1f} m/s"
            f" | SpeedScale:x{self.speed_scale:.2f}"
            # f" | SteerBias:{self.steer_bias:+.2f}rad"
        )

        # --- Pause buttons ---
        if self.paused and not self.show_upload_dialog:
            self._begin_2d()
            
            # Draw overlay background first (behind buttons)
            self._draw_rect(0, 0, self.width, self.height, (0, 0, 0, 120))
            
            # Draw PAUSED text above buttons
            paused_text_w = self.ui_font_big.size("PAUSED")[0]
            self._draw_text("PAUSED", (self.width - paused_text_w) // 2, self.height // 2 - 120, self.ui_font_big, (255, 255, 255, 255))
            
            mx, my = pygame.mouse.get_pos()

            # --- Common layout settings ---
            btn_w, btn_h = 180, 70
            gap = 40
            center_x = self.width // 2
            center_y = self.height // 2
            radius = 12  # rounded corners

            # --- Define button rects ---
            self.resume_button_rect = pygame.Rect(center_x - btn_w - gap // 2, center_y - btn_h // 2, btn_w, btn_h)
            self.exit_button_rect = pygame.Rect(center_x + gap // 2, center_y - btn_h // 2, btn_w, btn_h)

            resume_hovered = self.resume_button_rect.collidepoint((mx, my))
            exit_hovered = self.exit_button_rect.collidepoint((mx, my))

            # --- Helper: Rounded rectangle with soft gradient ---
            def draw_rounded_button(rect, top_color, bottom_color, border_color, text, icon, hovered=False):
                x, y, w, h = rect
                # soft drop shadow
                self._draw_rect(x + 6, y + 6, w, h, (0, 0, 0, 90))
                # vertical gradient
                for i in range(h):
                    t = i / h
                    r = int(top_color[0] * (1 - t) + bottom_color[0] * t)
                    g = int(top_color[1] * (1 - t) + bottom_color[1] * t)
                    b = int(top_color[2] * (1 - t) + bottom_color[2] * t)
                    self._draw_rect(x, y + i, w, 1, (r, g, b, 240))
                # border glow
                glow = 255 if hovered else 150
                self._draw_rect(x, y, w, 3, (border_color[0], border_color[1], border_color[2], glow))
                self._draw_rect(x, y + h - 3, w, 3, (border_color[0], border_color[1], border_color[2], glow))
                self._draw_rect(x, y, 3, h, (border_color[0], border_color[1], border_color[2], glow))
                self._draw_rect(x + w - 3, y, 3, h, (border_color[0], border_color[1], border_color[2], glow))
                if hovered:
                    self._draw_rect(x + 3, y + 3, w - 6, 2, (255, 255, 255, 80))

                # --- Icon + text ---
                text_y = y + (h - self.ui_font.get_height()) // 2
                if icon == "play":
                    # white triangle icon
                    glColor4f(1.0, 1.0, 1.0, 1.0)
                    glBegin(GL_TRIANGLES)
                    glVertex2f(x + 18, y + h / 2 - 10)
                    glVertex2f(x + 18, y + h / 2 + 10)
                    glVertex2f(x + 36, y + h / 2)
                    glEnd()
                    self._draw_text(text, x + 50, text_y, self.ui_font, (255, 255, 255, 255))
                elif icon == "exit":
                    # white X
                    glColor4f(1.0, 1.0, 1.0, 1.0)
                    glLineWidth(3.0)
                    glBegin(GL_LINES)
                    glVertex2f(x + 22 - 7, y + h / 2 - 7)
                    glVertex2f(x + 22 + 7, y + h / 2 + 7)
                    glVertex2f(x + 22 - 7, y + h / 2 + 7)
                    glVertex2f(x + 22 + 7, y + h / 2 - 7)
                    glEnd()
                    glLineWidth(1.0)
                    self._draw_text(text, x + 45, text_y, self.ui_font, (255, 255, 255, 255))

    # --- Draw Resume button (John Deere Green) ---
            draw_rounded_button(
                self.resume_button_rect,
                top_color=(80, 180, 40),
                bottom_color=(40, 100, 20),
                border_color=(160, 255, 80),
                text="RESUME",
                icon="play",
                hovered=resume_hovered
            )

        # --- Draw Exit button (Bright Red-Orange) ---
            draw_rounded_button(
                self.exit_button_rect,
                top_color=(220, 90, 50),
                bottom_color=(150, 40, 30),
                border_color=(255, 150, 100),
                text="EXIT",
                icon="exit",
                hovered=exit_hovered
            )



            self._end_2d()

        # --- HUD overlay ---
        self._draw_hud()
        self._draw_notifications()
        
        # --- Upload dialog ---
        if self.show_upload_dialog:
            self._draw_upload_dialog()
        

        pygame.display.flip()

    # -------------------------------------------------------------------------
    # Run Loop + Save Telemetry
    # -------------------------------------------------------------------------
    def run(self):
        while self.running:
            try:
                dt = self.clock.tick_busy_loop(self.TARGET_FPS) / 1000.0
            except AttributeError:
                dt = self.clock.tick(self.TARGET_FPS) / 1000.0
            

            self.handle_events()
            if not self.paused:
                self.update(dt)
            # self.update(dt)
            self.render()

        # Save telemetry data on exit if not already saved through dialog
        if self.trace_data and not self.show_upload_dialog:
            self._save_telemetry_data()
            print(f" Vehicle trace saved ({len(self.trace_data)} records)")

        pygame.quit()
        sys.exit(0)
    
    def _create_geojson_export(self, telemetry_file, timestamp):
        """Automatically create GeoJSON export from telemetry data."""
        try:
            from farm_sim.gps_utils import CoordinateConverter, SAMPLE_GPS_BOUNDARY

            # Use GPS boundary if available, otherwise use sample
            gps_boundary = getattr(self, "gps_boundary", None) or SAMPLE_GPS_BOUNDARY

            # Prefer the converter that was used during the simulation
            if getattr(self, "gps_converter", None) is not None:
                # Reuse existing converter so sim and export share the exact same origin
                converter = self.gps_converter
            else:
                # Fallback: compute center from bounding box (not simple average)
                lats = [lat for (lat, lon) in gps_boundary]
                lons = [lon for (lat, lon) in gps_boundary]
                min_lat, max_lat = min(lats), max(lats)
                min_lon, max_lon = min(lons), max(lons)
                center_lat = 0.5 * (min_lat + max_lat)
                center_lon = 0.5 * (min_lon + max_lon)
                converter = CoordinateConverter(center_lat, center_lon)

            # Build GeoJSON structure
            geojson = {
                "type": "FeatureCollection",
                "features": []
            }

            # Add field boundary polygon (GeoJSON expects [lon, lat])
            boundary_coords = [[lon, lat] for (lat, lon) in gps_boundary]
            geojson["features"].append({
                "type": "Feature",
                "properties": {"name": "Field Boundary", "type": "boundary"},
                "geometry": {"type": "Polygon", "coordinates": [boundary_coords]},
            })

            # Convert telemetry segments to GPS coordinates
            segment_count = 0

            # Completed segments
            for segment in self.trace_segments:
                if segment:
                    path_coords = []
                    for point in segment:
                        # Prefer sensor position if present; fall back to true position
                        px = point.get("meas_x", point["x"])
                        pz = point.get("meas_z", point["z"])
                        lat, lon = converter.local_to_gps(px, pz)
                        path_coords.append([lon, lat])
                    
                    if len(path_coords) > 1:
                        segment_count += 1
                        geojson["features"].append({
                            "type": "Feature",
                            "properties": {
                                "name": f"Vehicle Path - Segment {segment_count}",
                                "type": "vehicle_path",
                                "total_points": len(path_coords)
                            },
                            "geometry": {"type": "LineString", "coordinates": path_coords}
                        })
            
            # Add current active segment
            if self.trace_data:
                path_coords = []
                for point in self.trace_data:
                    px = point.get("meas_x", point["x"])
                    pz = point.get("meas_z", point["z"])
                    lat, lon = converter.local_to_gps(px, pz)
                    path_coords.append([lon, lat])

                
                if len(path_coords) > 1:
                    segment_count += 1
                    geojson["features"].append({
                        "type": "Feature",
                        "properties": {
                            "name": f"Vehicle Path - Segment {segment_count}",
                            "type": "vehicle_path",
                            "total_points": len(path_coords),
                        },
                        "geometry": {"type": "LineString", "coordinates": path_coords},
                    })

            # Current active segment
            if self.trace_data:
                path_coords = []
                for point in self.trace_data:
                    lat, lon = converter.local_to_gps(point["x"], point["z"])
                    path_coords.append([lon, lat])

                if len(path_coords) > 1:
                    segment_count += 1
                    geojson["features"].append({
                        "type": "Feature",
                        "properties": {
                            "name": f"Vehicle Path - Segment {segment_count}",
                            "type": "vehicle_path",
                            "total_points": len(path_coords),
                        },
                        "geometry": {"type": "LineString", "coordinates": path_coords},
                    })

            # Save GeoJSON file
            geojson_path = os.path.join(LOG_DIR, f"vehicle_path_{timestamp}.geojson")
            with open(geojson_path, "w") as f:
                json.dump(geojson, f, indent=2)

            print(f" GeoJSON exported: {geojson_path}")

        except Exception as e:
            print(f" GeoJSON export failed: {e}")


    # -------------------------------------------------------------------------
    # Vehicle-aware Autopilot tuning
    # -------------------------------------------------------------------------
    def _refresh_obstacles(self, initial: bool = False):
        if not self.obstacles_enabled:
            self.obstacles = []
            self.auto.build_path(())
            return
        path_hint = getattr(self.auto, "path", [])
        self.obstacles = generate_obstacles(self.field_w, self.field_h, path_hint)

        # --- Logging: obstacles and their details ---
        try:
            total = len(self.obstacles)
            kinds = {}
            for o in self.obstacles:
                kinds[o.kind] = kinds.get(o.kind, 0) + 1
            print(f"[OBSTACLES] total={total}, breakdown={kinds}")
            for i, o in enumerate(self.obstacles[:50]):  # cap to avoid huge spam
                # Obstacle.describe() added in farm_sim.world.obstacles
                desc = getattr(o, "describe", lambda: str(o))()
                print(f"[OBSTACLES] #{i:02d}: {desc}")
            if total > 50:
                print(f"[OBSTACLES] ... {total - 50} more not printed")
        except Exception as log_ex:
            print(f"[OBSTACLES] logging failed: {log_ex}")

        # ensure AutoPilot knows about the latest machine width each time
        tractor_width = float(self.tractor.spec.working_width)
        if getattr(self.tractor, "attached_implement", None):
            implement_width = tractor_width  # placeholder for per-implement width
            machine_width = max(tractor_width, implement_width)
            extra_clearance = max(0.0, 0.5 * machine_width - 0.5)
        else:
            # No implement: no extra clearance beyond obstacle radius + padding
            extra_clearance = 0.0

        self.autopilot_extra_clearance = extra_clearance
        self.auto.extra_clearance = extra_clearance
        self.auto.build_path(self.obstacles)

    def _derive_autopilot_geometry(self):
        spec = self.tractor.spec
        turn_radius = self.tractor.MIN_TURN_RADIUS
        if not math.isfinite(turn_radius) or turn_radius <= 0.0:
            turn_radius = max(2.5, spec.wheelbase * 1.5)

        # lane spacing must cover implement width and allow the turning radius
        lane_spacing = max(
            3.5,
            spec.working_width,
            2.0 * turn_radius + 0.5
        )

        # margins scale with machine footprint but stay within field bounds
        base_margin = max(1.2, min(self.field_w, self.field_h) * 0.05, turn_radius * 0.25)
        max_margin = max(0.8, min(self.field_w, self.field_h) * 0.5 - 1.0)
        margin = min(base_margin, max_margin)
        margin = max(margin, 0.8)

        # ensure vertical room for the semicircle turn
        available_half_h = max(0.5, self.field_h * 0.5 - margin)
        min_half_h = lane_spacing * 0.5 + 0.5
        if available_half_h < min_half_h:
            # shrink margin first
            margin = max(0.5, self.field_h * 0.5 - min_half_h)
            available_half_h = max(0.5, self.field_h * 0.5 - margin)
            if available_half_h < min_half_h:
                # field still too short for the desired radius; reduce lane spacing
                lane_spacing = max(3.0, 2.0 * (available_half_h - 0.5))
                min_half_h = lane_spacing * 0.5 + 0.5

        lane_spacing = max(3.0, lane_spacing)
        radius = lane_spacing * 0.5

        # turn inset must exceed radius but fit within the field height
        turn_inset = max(radius + 0.5, turn_radius + margin * 0.5, 3.0)
        turn_inset = min(turn_inset, available_half_h)
        if turn_inset < radius:
            turn_inset = radius + 0.25

        return lane_spacing, margin, turn_inset

    def _configure_autopilot_behavior(self):
        # set lookahead and target speeds based on machine capability
        lane_spacing = self.auto.lane_spacing
        turn_radius = lane_spacing * 0.5

        self.auto.lookahead = max(2.5, min(12.0, lane_spacing * 0.45))

        straight_speed = 4.0 + self.tractor.MAX_ACCEL * 0.5
        straight_speed = max(5.0, min(10.0, straight_speed))

        turn_speed = max(2.0, min(straight_speed * 0.5, straight_speed - max(1.0, turn_radius * 0.2)))

        self.auto.v_straight = straight_speed
        self.auto.v_turn = turn_speed
    
    def load_sample_gps_field(self):
        """Load GPS field with user's chosen dimensions"""
        try:
            print(f"Loading GPS field with dimensions: {self.field_w:.1f}m x {self.field_h:.1f}m")
            
            # Generate GPS boundary that matches user's field dimensions
            from farm_sim.gps_utils import CoordinateConverter
            
            # Use Iowa center as reference point
            center_lat, center_lon = 42.0311, -93.6309
            converter = CoordinateConverter(center_lat, center_lon)
            
            # Create rectangular boundary matching user dimensions
            half_w, half_h = self.field_w / 2, self.field_h / 2
            corners_local = [
                (-half_w, -half_h),  # SW
                (half_w, -half_h),   # SE  
                (half_w, half_h),    # NE
                (-half_w, half_h),   # NW
                (-half_w, -half_h)   # Close polygon
            ]
            
            # Convert to GPS coordinates
            gps_boundary = [converter.local_to_gps(x, z) for x, z in corners_local]
            
            self.gps_converter = converter
            self.gps_boundary = gps_boundary
            self.field_map_name = f"GPS Field ({self.field_w:.0f}×{self.field_h:.0f}m)"
            
            print(f"SUCCESS: GPS field created with preserved dimensions: {self.field_w:.1f}m x {self.field_h:.1f}m")
            
        except Exception as e:
            print(f"ERROR loading GPS field: {e}")
            import traceback
            traceback.print_exc()

    def _populate_harvest_rows(self, maturity: float = 1.0):
        """
        Fill the field with crop rows along the autopilot's snake path.
        Plants are placed at regular intervals along the autopilot path
        to mirror the sower's drop pattern. `maturity` controls how
        grown the plants appear (1.0 = ready to harvest, 0.0 = newly planted).
        """
        # Clear any previous crops/grid
        self.crops.clear()
        self.crop_grid.clear()

        # Ensure autopilot path is built
        if not getattr(self, "auto", None):
            return
        self.auto.build_path(self.obstacles if hasattr(self, "obstacles") else ())

        path = list(getattr(self.auto, "path", []))
        if not path or len(path) < 2:
            return

        # Mirror the same seeding cadence + offsets used by the sower
        lane_drop_spacing = max(PLANT_SPACING, PLANT_SPACING * 4.0)
        lateral_offset = max(0.5, getattr(self.tractor.spec, "working_width", 4.0) * 0.3)
        grid_spacing = PLANT_SPACING
        maturity = max(0.0, maturity)
        base_time = getattr(self, "time", 0.0)
        grow_time = base_time - (CROP_GROW_SECONDS * maturity)

        # Walk the path, match the tractor's travel distance, and drop paired rows
        total_len = 0.0
        next_drop = 0.0
        for i in range(len(path) - 1):
            x0, z0 = path[i]
            x1, z1 = path[i + 1]
            seg_dx = x1 - x0
            seg_dz = z1 - z0
            seg_len = math.hypot(seg_dx, seg_dz)
            if seg_len < 1e-6:
                total_len += seg_len
                continue

            dir_x = seg_dx / seg_len
            dir_z = seg_dz / seg_len
            # Perpendicular vector for left/right rows
            perp_x = -dir_z
            perp_z = dir_x

            while next_drop <= total_len + seg_len + 1e-6:
                t = (next_drop - total_len) / seg_len
                t = max(0.0, min(1.0, t))
                px = x0 + seg_dx * t
                pz = z0 + seg_dz * t

                for side in (-1, 1):
                    sx = px + perp_x * side * lateral_offset
                    sz = pz + perp_z * side * lateral_offset
                    sx = round(sx / grid_spacing) * grid_spacing
                    sz = round(sz / grid_spacing) * grid_spacing
                    grid_x = int(sx // grid_spacing)
                    grid_z = int(sz // grid_spacing)
                    grid_key = (grid_x, grid_z)
                    if grid_key in self.crop_grid:
                        continue
                    if not self._is_in_soil_area(sx, sz):
                        continue
                    crop = Crop(sx, sz, grow_time)
                    crop.harvested = False
                    self.crops.append(crop)
                    self.crop_grid[grid_key] = crop

                next_drop += lane_drop_spacing

            total_len += seg_len
