import math
import json
from typing import Tuple, List, Dict, Optional

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    print("Warning: requests module not available. John Deere API features disabled.")

from farm_sim.config import ORG_ID

class CoordinateConverter:
    """Convert between GPS coordinates and local simulation coordinates"""
    
    def __init__(self, center_lat: float, center_lon: float):
        """Initialize with field center coordinates"""
        self.center_lat = center_lat
        self.center_lon = center_lon
        self.earth_radius = 6378137.0  # Earth radius in meters
        
    def gps_to_local(self, lat: float, lon: float) -> Tuple[float, float]:
        """Convert GPS coordinates to local X,Z coordinates (meters)"""
        # Simple equirectangular projection for small areas
        lat_rad = math.radians(lat)
        lon_rad = math.radians(lon)
        center_lat_rad = math.radians(self.center_lat)
        center_lon_rad = math.radians(self.center_lon)
        
        # Calculate offsets in meters
        x = (lon_rad - center_lon_rad) * math.cos(center_lat_rad) * self.earth_radius
        z = (lat_rad - center_lat_rad) * self.earth_radius
        
        return x, z
    
    def local_to_gps(self, x: float, z: float) -> Tuple[float, float]:
        """Convert local coordinates back to GPS"""
        center_lat_rad = math.radians(self.center_lat)
        center_lon_rad = math.radians(self.center_lon)
        
        lat_rad = center_lat_rad + (z / self.earth_radius)
        lon_rad = center_lon_rad + (x / (self.earth_radius * math.cos(center_lat_rad)))
        
        return math.degrees(lat_rad), math.degrees(lon_rad)
    
    def gps_boundary_to_local(self, gps_points: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
        """Convert list of GPS boundary points to local coordinates"""
        return [self.gps_to_local(lat, lon) for lat, lon in gps_points]

class JohnDeereAPI:
    """Interface to John Deere Operations Center API"""
    
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.base_url = "https://sandboxapi.deere.com"
        self.headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/vnd.deere.axiom.v3+json"
        }
    
    def get_organizations(self) -> Optional[List[Dict]]:
        """Get list of organizations user has access to"""
        if not HAS_REQUESTS:
            return None
            
        try:
            url = f"{self.base_url}/platform/organizations"
            print(f"Trying URL: {url}")
            response = requests.get(url, headers=self.headers)
            print(f"Response status: {response.status_code}")
            print(f"Response headers: {dict(response.headers)}")
            if response.status_code != 200:
                print(f"Response body: {response.text}")
            if response.status_code == 200:
                data = response.json()
                print(f"Response data: {data}")
                return data.get('values', [])
            return None
        except Exception as e:
            print(f"Error fetching organizations: {e}")
            return None
    
    def get_fields(self, org_id: str) -> Optional[List[Dict]]:
        """Get list of fields for an organization"""
        if not HAS_REQUESTS:
            return None
            
        try:
            url = f"{self.base_url}/platform/organizations/{org_id}/fields"
            print(f"Fetching fields from: {url}")
            response = requests.get(url, headers=self.headers)
            print(f"Fields API response: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                fields = data.get('values', [])
                print(f"Found {len(fields)} fields in API response")
                return fields
            else:
                print(f"Fields API error: {response.text}")
            return None
        except Exception as e:
            print(f"Error fetching fields: {e}")
            return None
    
    def get_field_boundaries(self, field_id: str) -> Optional[List[Tuple[float, float]]]:
        """Fetch field boundary coordinates from John Deere API"""
        if not HAS_REQUESTS:
            print("Error: requests module required for John Deere API")
            return None
        
        # Handle sample fields with predefined boundaries
        sample_boundaries = {
            'sample_field_1': [  # Iowa Corn Field
                (42.0308, -93.6319),
                (42.0315, -93.6319), 
                (42.0315, -93.6298),
                (42.0308, -93.6298),
                (42.0308, -93.6319)
            ],
            'sample_field_2': [  # Nebraska Soybean Field (larger)
                (41.2565, -96.0485),
                (41.2580, -96.0485),
                (41.2580, -96.0450),
                (41.2565, -96.0450), 
                (41.2565, -96.0485)
            ],
            'sample_field_3': [  # Kansas Wheat Field (largest)
                (39.1142, -94.6275),
                (39.1165, -94.6275),
                (39.1165, -94.6230),
                (39.1142, -94.6230),
                (39.1142, -94.6275)
            ]
        }
        
        if field_id in sample_boundaries:
            print(f"Using sample boundaries for field: {field_id}")
            return sample_boundaries[field_id]
            
        try:
            url = f"{self.base_url}/platform/fields/{field_id}/boundaries"
            print(f"Fetching boundaries from: {url}")
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                data = response.json()
                # Extract coordinates from GeoJSON format
                if 'values' in data and len(data['values']) > 0:
                    boundary = data['values'][0]  # Get first boundary
                    if 'geometry' in boundary and 'coordinates' in boundary['geometry']:
                        coords = boundary['geometry']['coordinates'][0]  # First ring
                        return [(coord[1], coord[0]) for coord in coords]  # Convert [lon,lat] to (lat,lon)
            else:
                print(f"Boundaries API error {response.status_code}: {response.text}")
            return None
        except Exception as e:
            print(f"Error fetching field boundaries: {e}")
            return None
    
    def list_available_fields(self) -> List[Dict]:
        """Get all available fields with their info"""
        all_fields = []
        
        # Get organizations
        orgs = self.get_organizations()
        if not orgs:
            return all_fields
            
        # Get fields for each organization
        for org in orgs:
            org_id = org.get('id', '').split('/')[-1]  # Extract ID from URL
            org_name = org.get('name', 'Unknown')
            
            fields = self.get_fields(org_id)
            if fields:
                for field in fields:
                    field_info = {
                        'field_id': field.get('id', '').split('/')[-1],
                        'field_name': field.get('name', 'Unnamed Field'),
                        'org_name': org_name,
                        'org_id': org_id,
                        'area': field.get('area', {}).get('value', 0)
                    }
                    all_fields.append(field_info)
        
        # Add sample fields for testing when no real fields exist
        if not all_fields:
            print("No real fields found, adding sample fields for testing")
            org_id_str = str(ORG_ID)
            sample_fields = [
                {
                    'field_id': 'sample_field_1',
                    'field_name': '[SAMPLE] Iowa Corn Field',
                    'org_name': 'Personal',
                    'org_id': org_id_str,
                    'area': 15.2
                },
                {
                    'field_id': 'sample_field_2', 
                    'field_name': '[SAMPLE] Nebraska Soybean Field',
                    'org_name': 'Personal',
                    'org_id': org_id_str,
                    'area': 22.8
                },
                {
                    'field_id': 'sample_field_3',
                    'field_name': '[SAMPLE] Kansas Wheat Field', 
                    'org_name': 'Personal',
                    'org_id': org_id_str,
                    'area': 31.5
                }
            ]
            all_fields = sample_fields
        else:
            print(f"Found {len(all_fields)} real John Deere fields")
        
        return all_fields

def create_field_from_gps(gps_boundary):
    """Create field dimensions and converter from GPS boundary points"""
    if not gps_boundary:
        return 100.0, 100.0, None

    # Use bounding box center instead of simple average
    lats = [lat for (lat, lon) in gps_boundary]
    lons = [lon for (lat, lon) in gps_boundary]

    min_lat, max_lat = min(lats), max(lats)
    min_lon, max_lon = min(lons), max(lons)

    # This is the true center of the bounding rectangle
    center_lat = 0.5 * (min_lat + max_lat)
    center_lon = 0.5 * (min_lon + max_lon)

    converter = CoordinateConverter(center_lat, center_lon)

    # Convert boundary to local coordinates
    local_points = converter.gps_boundary_to_local(gps_boundary)

    min_x = min(x for x, z in local_points)
    max_x = max(x for x, z in local_points)
    min_z = min(z for x, z in local_points)
    max_z = max(z for x, z in local_points)

    field_w = max_x - min_x
    field_h = max_z - min_z

    return field_w, field_h, converter


# Sample GPS boundary for testing (Iowa corn field)
SAMPLE_GPS_BOUNDARY = [
    (42.0308, -93.6319),
    (42.0315, -93.6319),
    (42.0315, -93.6298),
    (42.0308, -93.6298),
    (42.0308, -93.6319)  # Close the polygon
]

def test_gps_utils():
    """Quick test of GPS utilities"""
    print("Testing GPS utilities...")
    try:
        field_w, field_h, converter = create_field_from_gps(SAMPLE_GPS_BOUNDARY)
        print(f"Test successful: {field_w:.1f}m x {field_h:.1f}m")
        return True
    except Exception as e:
        print(f"Test failed: {e}")
        return False

def test_organizations_api(access_token: str):
    """Test Organizations API access and show available data"""
    api = JohnDeereAPI(access_token)
    
    print("Testing Organizations API access...")
    print("=" * 50)
    
    orgs = api.get_organizations()
    
    if orgs:
        print(f"✓ Successfully connected! Found {len(orgs)} organizations:")
        print()
        
        for i, org in enumerate(orgs, 1):
            org_id = org.get('id', '').split('/')[-1]
            org_name = org.get('name', 'Unknown')
            org_type = org.get('type', 'Unknown')
            
            print(f"{i}. {org_name}")
            print(f"   ID: {org_id}")
            print(f"   Type: {org_type}")
            print()
            
            # Try to get fields
            print(f"   Checking fields for {org_name}...")
            fields = api.get_fields(org_id)
            
            if fields:
                print(f"   ✓ Found {len(fields)} fields:")
                for j, field in enumerate(fields[:3], 1):
                    field_name = field.get('name', 'Unnamed')
                    field_id = field.get('id', '').split('/')[-1]
                    area = field.get('area', {}).get('value', 0)
                    print(f"     {j}. {field_name} (ID: {field_id}) - {area} hectares")
                
                if len(fields) > 3:
                    print(f"     ... and {len(fields) - 3} more fields")
            else:
                print("   ⚠ No fields found or Fields API not yet approved")
            
            print()
        return orgs
    else:
        print("✗ Failed to connect or no organizations found")
        print("Check your access token and API approval status")
        return []

def load_credentials():
    """Load credentials from file"""
    try:
        with open('jd_credentials.json', 'r') as f:
            return json.load(f)
    except:
        return None

if __name__ == "__main__":
    # Auto-load credentials
    creds = load_credentials()
    if creds and creds.get('access_token'):
        token = creds['access_token']
        print("Using saved credentials...")
        test_organizations_api(token)
    else:
        print("No saved credentials found")
        token = input("Enter your John Deere access token: ").strip()
        if token:
            test_organizations_api(token)
        else:
            print("No token provided")

def test_john_deere_api(access_token: str):
    """Test John Deere API connection and list available fields"""
    return test_organizations_api(access_token)
