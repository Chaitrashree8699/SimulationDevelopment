from dataclasses import dataclass
from farm_sim.config import CROP_GROW_SECONDS
from farm_sim.util import clamp

@dataclass
class Crop:
    x: float
    z: float
    planted_time: float
    harvested: bool = False
    sprayed: bool = False
    watered: bool = False

    def growth(self, now: float) -> float:
        growth_rate = 1.5 if self.watered else 1.0  # Watered crops grow 50% faster
        return clamp((now - self.planted_time) / (CROP_GROW_SECONDS / growth_rate), 0.0, 1.0)
