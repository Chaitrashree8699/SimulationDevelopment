# farm_sim/entities/implements.py
from enum import Enum
from OpenGL.GL import *
import math
from farm_sim.render.draw import draw_cube, draw_cylinder

# Cache for compiled OpenGL display lists
implement_cache = {}


class ImplementType(Enum):
    NONE = 0
    PLOW = 1
    SOWER = 2
    SPRAYER = 3
    IRRIGATION = 4
    HARVESTER = 5


def draw_plow(offset_z=-1.8, width=6.0, depth=0.35):
    """Clean, realistic plow with proper proportions."""
    glPushMatrix()
    glTranslatef(0.0, -0.15, offset_z)
    
    plow_width = width * 0.7
    blades = max(3, int(width / 1.5))

    # Main frame (Kuhn red)
    glColor3f(0.8, 0.15, 0.1)
    glPushMatrix()
    glTranslatef(0, 0.1, -0.1)
    draw_cube(plow_width, 0.15, 0.25)
    glPopMatrix()

    # Individual plow bodies
    for i in range(blades):
        x = -plow_width / 2 + (i + 0.5) * (plow_width / blades)
        
        # Support post (steel)
        glColor3f(0.6, 0.6, 0.65)
        glPushMatrix()
        glTranslatef(x, 0.0, -0.15)
        draw_cube(0.08, 0.25, 0.08)
        glPopMatrix()
        
        # Moldboard (polished steel)
        glColor3f(0.75, 0.75, 0.8)
        glPushMatrix()
        glTranslatef(x, -0.05, -0.25)
        glRotatef(-15, 0, 1, 0)
        glBegin(GL_QUADS)
        glVertex3f(-0.12, 0.0, 0.0)
        glVertex3f(0.12, 0.0, 0.0)
        glVertex3f(0.15, -0.15, -0.25)
        glVertex3f(-0.1, -0.15, -0.25)
        glEnd()
        glPopMatrix()
        
        # Coulter disc (yellow)
        glColor3f(0.9, 0.8, 0.1)
        glPushMatrix()
        glTranslatef(x, -0.02, -0.4)
        glRotatef(90, 1, 0, 0)
        draw_cylinder(0.1, 0.015, 12)
        glPopMatrix()
    glPopMatrix()


def draw_implement(kind: ImplementType, tractor=None):
    """Draws the current implement scaled to tractor."""
    width = tractor.spec.working_width if tractor else 6.0
    
    if kind == ImplementType.PLOW:
        draw_plow(width=width)
    elif kind == ImplementType.SOWER:
        draw_sower(width=width)
    elif kind == ImplementType.SPRAYER:
        draw_sprayer(width=width)
    elif kind == ImplementType.IRRIGATION:
        draw_irrigation(width=width)
    elif kind == ImplementType.HARVESTER:
        draw_harvester(width=width)


def draw_sower(offset_z=-1.8, width=6.0):
    """Clean seed drill with proper proportions."""
    glPushMatrix()
    glTranslatef(0.0, -0.12, offset_z)
    
    drill_width = width * 0.8

    # Seed hopper (John Deere green)
    glColor3f(0.07, 0.45, 0.12)
    glPushMatrix()
    glTranslatef(0, 0.25, -0.15)
    draw_cube(drill_width * 0.6, 0.4, 0.5)
    glPopMatrix()
    
    # Hopper lid
    glColor3f(0.05, 0.35, 0.1)
    glPushMatrix()
    glTranslatef(0, 0.45, -0.15)
    draw_cube(drill_width * 0.62, 0.03, 0.52)
    glPopMatrix()

    # Main frame (steel)
    glColor3f(0.6, 0.6, 0.65)
    glPushMatrix()
    glTranslatef(0, 0.0, -0.35)
    draw_cube(drill_width, 0.1, 0.12)
    glPopMatrix()

    # Seed openers
    rows = max(4, int(width / 1.2))
    for i in range(rows):
        x = -drill_width/2 + (i * drill_width / (rows - 1))
        
        # Seed tube (black)
        glColor3f(0.2, 0.2, 0.2)
        glPushMatrix()
        glTranslatef(x, -0.08, -0.45)
        draw_cylinder(0.02, 0.2, 6)
        glPopMatrix()
        
        # Opener disc (yellow)
        glColor3f(0.9, 0.8, 0.15)
        glPushMatrix()
        glTranslatef(x, -0.12, -0.55)
        glRotatef(90, 1, 0, 0)
        draw_cylinder(0.08, 0.015, 12)
        glPopMatrix()
    glPopMatrix()



def draw_sprayer(offset_z=-1.8, width=6.0):
    """Realistic sprayer with tank, boom and nozzles."""
    glPushMatrix()
    glTranslatef(0.0, -0.10, offset_z)
    
    boom_width = width * 0.9
    
    # Chemical tank (white)
    glColor3f(0.9, 0.9, 0.95)
    glPushMatrix()
    glTranslatef(0, 0.2, 0.1)
    draw_cube(1.2, 0.8, 0.6)
    glPopMatrix()
    
    # Tank cap (black)
    glColor3f(0.1, 0.1, 0.1)
    glPushMatrix()
    glTranslatef(0, 0.6, 0.1)
    draw_cylinder(0.15, 0.05, 8)
    glPopMatrix()

    # Main boom arms (aluminum)
    glColor3f(0.8, 0.8, 0.85)
    glPushMatrix()
    glTranslatef(0, 0.05, -0.1)
    draw_cube(boom_width, 0.08, 0.08)
    glPopMatrix()
    
    # Support struts
    glColor3f(0.7, 0.7, 0.75)
    for side in [-1, 1]:
        glPushMatrix()
        glTranslatef(side * boom_width * 0.3, 0.1, -0.05)
        glRotatef(45 * side, 0, 0, 1)
        draw_cube(0.05, 0.3, 0.05)
        glPopMatrix()

    # Nozzle bodies (brass)
    glColor3f(0.8, 0.7, 0.3)
    nozzles = max(6, int(width * 1.5))
    for i in range(nozzles):
        x = -boom_width/2 + i * (boom_width / (nozzles-1))
        glPushMatrix()
        glTranslatef(x, -0.05, -0.1)
        draw_cylinder(0.03, 0.08, 6)
        glPopMatrix()
    
    glPopMatrix()


def draw_irrigation(offset_z=-1.8, width=6.0):
    """Realistic irrigation system with water tank and 4 sprinklers."""
    glPushMatrix()
    glTranslatef(0.0, -0.10, offset_z)
    
    boom_width = width * 0.9
    
    # Water tank (blue-tinted)
    glColor3f(0.7, 0.85, 0.95)
    glPushMatrix()
    glTranslatef(0, 0.25, 0.1)
    draw_cube(1.4, 0.9, 0.7)
    glPopMatrix()
    
    # Tank filler cap (blue)
    glColor3f(0.2, 0.6, 0.9)
    glPushMatrix()
    glTranslatef(0, 0.7, 0.1)
    draw_cylinder(0.12, 0.06, 8)
    glPopMatrix()

    # Main water pipes (PVC white)
    glColor3f(0.95, 0.95, 1.0)
    glPushMatrix()
    glTranslatef(0, 0.08, -0.1)
    draw_cube(boom_width, 0.12, 0.12)
    glPopMatrix()

    # 4 Water sprinkler heads positioned at trail line locations
    glColor3f(0.0, 0.7, 0.9)
    positions = [-width * 0.35, -width * 0.25, width * 0.25, width * 0.35]
    for x in positions:
        glPushMatrix()
        glTranslatef(x, -0.02, -0.1)
        draw_cylinder(0.05, 0.12, 8)
        glPopMatrix()
    
    glPopMatrix()


def draw_harvester(offset_z=-1.8, width=6.0):
    """Clean combine header with proper proportions."""
    glPushMatrix()
    glTranslatef(0.0, -0.12, offset_z)
    
    header_width = width * 0.9
    
    # Main header frame (Case IH red)
    glColor3f(0.85, 0.15, 0.12)
    glPushMatrix()
    glTranslatef(0, 0.2, -0.2)
    draw_cube(header_width, 0.35, 0.5)
    glPopMatrix()
    
    # Grain pan (steel)
    glColor3f(0.7, 0.7, 0.75)
    glPushMatrix()
    glTranslatef(0, 0.05, 0.05)
    draw_cube(header_width * 0.8, 0.1, 0.3)
    glPopMatrix()

    # Reel support arms
    glColor3f(0.5, 0.5, 0.55)
    for side in [-1, 1]:
        glPushMatrix()
        glTranslatef(side * header_width * 0.4, 0.3, -0.5)
        draw_cube(0.08, 0.5, 0.08)
        glPopMatrix()
    
    # Reel cylinder (steel gray)
    glColor3f(0.6, 0.6, 0.65)
    glPushMatrix()
    glTranslatef(0, 0.45, -0.5)
    glRotatef(90, 0, 1, 0)
    draw_cylinder(0.08, header_width * 0.7, 12)
    glPopMatrix()
    
    # Reel tines (simplified)
    glColor3f(0.2, 0.2, 0.2)
    tines = 8
    for i in range(tines):
        angle = (i * 45.0)
        glPushMatrix()
        glTranslatef(0, 0.45, -0.5)
        glRotatef(angle, 1, 0, 0)
        glTranslatef(0, 0.1, 0)
        draw_cube(header_width * 0.6, 0.01, 0.15)
        glPopMatrix()

    # Cutterbar (bright yellow)
    glColor3f(1.0, 0.9, 0.1)
    glPushMatrix()
    glTranslatef(0, -0.05, -0.45)
    draw_cube(header_width, 0.08, 0.12)
    glPopMatrix()
    
    # Sickle sections (steel)
    glColor3f(0.6, 0.6, 0.65)
    sections = max(6, int(header_width * 2))
    for i in range(sections):
        x = -header_width/2 + i * (header_width / (sections-1))
        glPushMatrix()
        glTranslatef(x, -0.08, -0.52)
        glRotatef(30, 0, 1, 0)
        draw_cube(0.06, 0.02, 0.06)
        glPopMatrix()
    glPopMatrix()