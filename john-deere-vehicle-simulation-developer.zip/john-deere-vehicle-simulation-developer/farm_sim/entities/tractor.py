import math
import random  # for Gaussian noise
from dataclasses import dataclass
from typing import List, Optional, Tuple, Union, Dict

from farm_sim.util import clamp


@dataclass(frozen=True)
class TractorSpec:
    key: str
    model_id: int
    name: str
    working_width: float = 5.5
    wheelbase: float = 1.6
    rear_radius: float = 0.42
    front_radius: float = 0.32
    max_accel: float = 8.0
    max_brake: float = 12.0
    drag_k: float = 0.35
    roll_k: float = 1.2
    max_rev: float = -5.0
    max_steer_deg: float = 28.0
    steer_rate_deg: float = 180.0
    description: str = ""
    horsepower: int = 75

    @property
    def max_steer_rad(self) -> float:
        return math.radians(self.max_steer_deg)

    @property
    def min_turn_radius(self) -> float:
        angle_rad = self.max_steer_rad
        tan_val = math.tan(angle_rad)
        if abs(tan_val) < 1e-6:
            return float("inf")
        return self.wheelbase / tan_val


TRACTOR_SPECS: List[TractorSpec] = [
    TractorSpec(
        key="jd_5075e",
        model_id=599578,
        name="John Deere 5075E",
        working_width=6.0,
        description="Utility tractor; nimble and well-balanced.",
        horsepower=75,
    ),
    TractorSpec(
        key="jd_4m_4100",
        model_id=599812,
        name="John Deere 4M 4100",
        working_width=4.5,
        wheelbase=1.9,
        rear_radius=0.36,
        front_radius=0.28,
        max_accel=9.5,
        max_brake=10.5,
        drag_k=0.28,
        roll_k=0.9,
        max_rev=-6.0,
        max_steer_deg=32.0,
        steer_rate_deg=220.0,
        description="Compact utility; light with quick response.",
        horsepower=100,
    ),
    TractorSpec(
        key="jd_8r_370",
        model_id=622231,
        name="John Deere 8R 370",
        working_width=8.0,
        wheelbase=2.9,
        rear_radius=0.55,
        front_radius=0.42,
        max_accel=6.5,
        max_brake=14.0,
        drag_k=0.45,
        roll_k=1.6,
        max_rev=-4.5,
        max_steer_deg=26.0,
        steer_rate_deg=150.0,
        description="Row-crop tractor; heavier with higher grip.",
        horsepower=370,
    ),
    TractorSpec(
        key="jd_9rx_640",
        model_id=648800,
        name="John Deere 9RX 640",
        working_width=9.5,
        wheelbase=3.4,
        rear_radius=0.60,
        front_radius=0.60,
        max_accel=5.0,
        max_brake=16.0,
        drag_k=0.52,
        roll_k=1.9,
        max_rev=-4.0,
        max_steer_deg=24.0,
        steer_rate_deg=120.0,
        description="Four-track flagship; massive and steady.",
        horsepower=640,
    ),
]

TRACTOR_SPEC_BY_KEY: Dict[str, TractorSpec] = {spec.key: spec for spec in TRACTOR_SPECS}
DEFAULT_TRACTOR_KEY = TRACTOR_SPECS[0].key


def resolve_spec(value: Optional[Union[str, TractorSpec]]) -> TractorSpec:
    if isinstance(value, TractorSpec):
        return value
    if isinstance(value, str) and value in TRACTOR_SPEC_BY_KEY:
        return TRACTOR_SPEC_BY_KEY[value]
    return TRACTOR_SPEC_BY_KEY[DEFAULT_TRACTOR_KEY]


def get_tractor_spec(key: Optional[str]) -> TractorSpec:
    return resolve_spec(key)


def all_tractor_specs() -> List[TractorSpec]:
    return list(TRACTOR_SPECS)


class Tractor:
    """
    Tractor dynamics + sensor/terrain noise.

    NOISE_LEVEL:
      0 = ideal (no noise)
      1 = realistic light noise
      2 = strong / rough-field noise
    """
    NOISE_LEVEL = 1

    def __init__(self, spec: Optional[Union[str, TractorSpec]] = None):
        resolved_spec = resolve_spec(spec)
        self.spec = resolved_spec
        self.spec_key = resolved_spec.key
        self.name = resolved_spec.name

        # geometry & dynamics
        self.WHEELBASE = resolved_spec.wheelbase
        self.REAR_R = resolved_spec.rear_radius
        self.FRONT_R = resolved_spec.front_radius
        self.MAX_ACCEL = resolved_spec.max_accel
        self.MAX_BRAKE = resolved_spec.max_brake
        self.DRAG_K = resolved_spec.drag_k
        self.ROLL_K = resolved_spec.roll_k
        self.MAX_REV = resolved_spec.max_rev
        self.MAX_STEER = math.radians(resolved_spec.max_steer_deg)
        self.STEER_RATE = math.radians(resolved_spec.steer_rate_deg)
        self.MIN_TURN_RADIUS = resolved_spec.min_turn_radius

        # state
        self.x = 0.0
        self.z = 0.0
        self.y = 0.5
        self.yaw = 0.0
        self.v = 0.0
        self.steer = 0.0
        self.rear_spin = 0.0
        self.front_spin = 0.0

        # implement state
        from farm_sim.entities.implements import ImplementType
        self.attached_implement = ImplementType.PLOW
        self.implement_enabled = False

        # --- noise-related state ---
        # these will be configured by set_noise_level()
        self.speed_noise_std = 0.0
        self.yaw_noise_std = 0.0
        self.slip_lat_std = 0.0
        self.meas_pos_std = 0.0
        self.meas_yaw_std = 0.0
        self.drift_pos_std = 0.0
        self.drift_yaw_std = 0.0

        # drift (random walk bias)
        self.bias_x = 0.0
        self.bias_z = 0.0
        self.bias_yaw = 0.0

        # GNSS spike / freeze model
        self.meas_spike_prob = 0.0
        self.meas_spike_std = 0.0
        self.meas_freeze_prob = 0.0
        self.meas_freeze_frames_left = 0
        self._last_meas_pose: Optional[Tuple[float, float, float, float]] = None

        # configure noise according to global level
        self.set_noise_level(Tractor.NOISE_LEVEL)

    # ------------------------------------------------------------
    # Noise Level Setter (called by game.py)
    # ------------------------------------------------------------
    def set_noise_level(self, level: int):
        """
        Change noise level live during simulation.
        level = 0 → no noise
        level = 1 → realistic GNSS/IMU + light slip
        level = 2 → rough terrain noise
        """
        level = max(0, min(2, level))
        Tractor.NOISE_LEVEL = level

        if level == 0:
            # almost perfect
            self.speed_noise_std = 0.0
            self.yaw_noise_std = 0.0
            self.slip_lat_std = 0.0

            self.meas_pos_std = 0.0
            self.meas_yaw_std = 0.0

            self.drift_pos_std = 0.0
            self.drift_yaw_std = 0.0

            self.meas_spike_prob = 0.0
            self.meas_spike_std = 0.0
            self.meas_freeze_prob = 0.0

        elif level == 1:
            # moderate “realistic” noise
            self.speed_noise_std = 0.05
            self.yaw_noise_std = math.radians(0.05)
            self.slip_lat_std = 0.04

            self.meas_pos_std = 0.03            # ~3 cm white noise
            self.meas_yaw_std = math.radians(0.08)

            self.drift_pos_std = 0.002          # slow drift
            self.drift_yaw_std = math.radians(0.003)

            self.meas_spike_prob = 0.0015
            self.meas_spike_std = 1.2           # occasional 1–2 m jump
            self.meas_freeze_prob = 0.0008

        else:  # level == 2
            # strong / rough field
            self.speed_noise_std = 0.12
            self.yaw_noise_std = math.radians(0.12)
            self.slip_lat_std = 0.09

            self.meas_pos_std = 0.06
            self.meas_yaw_std = math.radians(0.15)

            self.drift_pos_std = 0.006
            self.drift_yaw_std = math.radians(0.008)

            self.meas_spike_prob = 0.003
            self.meas_spike_std = 2.0
            self.meas_freeze_prob = 0.0015

        print(f"[Tractor] Noise level changed -> {level}")

    # ------------------------------
    #   helpers
    # ------------------------------
    def forward_vec(self) -> Tuple[float, float]:
        return math.sin(self.yaw), -math.cos(self.yaw)

    def _update_drift(self, dt: float):
        """Random walk of GNSS bias (slow drift)."""
        if dt <= 0.0:
            return
        if self.drift_pos_std > 0.0:
            sigma_p = self.drift_pos_std * math.sqrt(dt)
            self.bias_x += random.gauss(0.0, sigma_p)
            self.bias_z += random.gauss(0.0, sigma_p)
        if self.drift_yaw_std > 0.0:
            sigma_y = self.drift_yaw_std * math.sqrt(dt)
            self.bias_yaw += random.gauss(0.0, sigma_y)
            self.bias_yaw = (self.bias_yaw + math.pi) % (2.0 * math.pi) - math.pi

    # ------------------------------
    #   main dynamics
    # ------------------------------
    def update(self, dt, keys, _field_limit_unused,
               collision_check_fn=None,
               slip_mult: float = 1.0):
        import pygame

        # update slow GNSS drift
        self._update_drift(dt)

        # --- throttle / brake ---
        throttle = 1.0 if keys[pygame.K_w] else 0.0
        brake = 1.0 if keys[pygame.K_s] else 0.0

        # --- steering with self-centering ---
        steer_input = 0.0
        if keys[pygame.K_a]:
            steer_input -= 1.0
        if keys[pygame.K_d]:
            steer_input += 1.0

        if steer_input != 0.0:
            self.steer += steer_input * self.STEER_RATE * dt
        else:
            steer_return_rate = self.STEER_RATE * 0.5
            if self.steer > 0.0:
                self.steer = max(0.0, self.steer - steer_return_rate * dt)
            elif self.steer < 0.0:
                self.steer = min(0.0, self.steer + steer_return_rate * dt)

        self.steer = clamp(self.steer, -self.MAX_STEER, self.MAX_STEER)

        # --- longitudinal dynamics ---
        a_eng = throttle * self.MAX_ACCEL
        a_brake = -brake * self.MAX_BRAKE * (1.0 if self.v > 0 else 0.5)
        a_drag = -self.DRAG_K * self.v * abs(self.v)
        a_roll = -self.ROLL_K * (1.0 if abs(self.v) > 0.01 else 0.0) * (1 if self.v > 0 else -1 if self.v < 0 else 0)

        # deterministic integration (no noise on v itself now)
        self.v += (a_eng + a_brake + a_drag + a_roll) * dt

        if self.v < self.MAX_REV:
            self.v = self.MAX_REV

        # --- yaw update (bicycle model, deterministic) ---
        self.yaw += (self.v / self.WHEELBASE) * math.tan(self.steer) * dt

        # normalize yaw to [-pi, pi] for stability
        self.yaw = (self.yaw + math.pi) % (2.0 * math.pi) - math.pi

        # --- integrate position + lateral slip ---
        fx, fz = self.forward_vec()

        # base motion
        new_x = self.x + fx * self.v * dt
        new_z = self.z + fz * self.v * dt

        # lateral slip perpendicular to heading (terrain effect)
        if self.slip_lat_std > 0.0 and dt > 0.0 and abs(self.v) > 0.1:
            nx, nz = -fz, fx  # left normal
            speed_factor = 0.5 + 0.5 * min(1.0, abs(self.v) / 7.0)
            sigma_lat = self.slip_lat_std * math.sqrt(dt) * slip_mult * speed_factor
            slip_m = random.gauss(0.0, sigma_lat)
            new_x += nx * slip_m
            new_z += nz * slip_m

        # --- collision handling ---
        if collision_check_fn and collision_check_fn(new_x, new_z):
            if not collision_check_fn(new_x, self.z):
                self.x = new_x
                self.v *= 0.5
            elif not collision_check_fn(self.x, new_z):
                self.z = new_z
                self.v *= 0.5
            else:
                self.v = 0.0
        else:
            self.x = new_x
            self.z = new_z

        # --- wheel spin visuals ---
        self.rear_spin = (self.rear_spin + (self.v / max(self.REAR_R, 1e-3)) * (180.0 / math.pi) * dt) % 360.0
        self.front_spin = (self.front_spin + (self.v / max(self.FRONT_R, 1e-3)) * (180.0 / math.pi) * dt) % 360.0

    # ------------------------------
    # implement helpers
    # ------------------------------
    def cycle_implement(self):
        from farm_sim.entities.implements import ImplementType
        if self.attached_implement == ImplementType.NONE:
            self.attached_implement = ImplementType.PLOW
        else:
            self.attached_implement = ImplementType.NONE

    def toggle_implement(self):
        self.implement_enabled = not self.implement_enabled

    # ------------------------------
    # pose (true vs noisy GNSS)
    # ------------------------------
    def get_pose(self) -> Tuple[float, float, float, float]:
        return self.x, self.y, self.z, self.yaw

    def get_noisy_pose(self) -> Tuple[float, float, float, float]:
        """
        Simulated GNSS/IMU measurement with:
        - white noise
        - slow drift (bias_x, bias_z, bias_yaw)
        - occasional spikes and short freezes
        """
        # handle freeze
        if self.meas_freeze_frames_left > 0 and self._last_meas_pose is not None:
            self.meas_freeze_frames_left -= 1
            return self._last_meas_pose

        # base = true pose + drift
        x_m = self.x + self.bias_x
        z_m = self.z + self.bias_z
        yaw_m = self.yaw + self.bias_yaw

        # white noise
        if self.meas_pos_std > 0.0:
            x_m += random.gauss(0.0, self.meas_pos_std)
            z_m += random.gauss(0.0, self.meas_pos_std)
        if self.meas_yaw_std > 0.0:
            yaw_m += random.gauss(0.0, self.meas_yaw_std)

        # occasional spike
        if self.meas_spike_prob > 0.0 and random.random() < self.meas_spike_prob:
            dx_spike = random.gauss(0.0, self.meas_spike_std)
            dz_spike = random.gauss(0.0, self.meas_spike_std)
            x_m += dx_spike
            z_m += dz_spike

        # occasional short freeze (keep last GNSS reading)
        if self.meas_freeze_prob > 0.0 and random.random() < self.meas_freeze_prob:
            self.meas_freeze_frames_left = random.randint(10, 40)  # ~0.1–0.4 s

        yaw_m = (yaw_m + math.pi) % (2.0 * math.pi) - math.pi
        pose = (x_m, self.y, z_m, yaw_m)
        self._last_meas_pose = pose
        return pose

    @property
    def speed(self):
        return self.v





