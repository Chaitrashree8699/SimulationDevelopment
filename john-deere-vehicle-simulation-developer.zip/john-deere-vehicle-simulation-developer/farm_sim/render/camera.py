import math
from enum import Enum
from OpenGL.GL import *
from OpenGL.GLU import *
from farm_sim.util import clamp

class CamMode(Enum):
    CHASE = 0   # 3D camera (default)
    TOP   = 1   # top-down camera


class DriverCamera:
    """Camera with CHASE (3D) and TOP (orthographic) modes."""
    def __init__(self, mode=CamMode.CHASE):
        self.mode = mode
        self.height_chase = 3.0
        self.dist_chase = 5.2
        self.look_ahead = 3.6
        self.fov_base = 60.0
        self.top_zoom = 18.0

    def cycle_mode(self):
        """Toggle between CHASE → TOP → CHASE …"""
        self.mode = CamMode((self.mode.value + 1) % 2)

    def get_position(self, t):
        """Camera position for LOD."""
        fx, fz = t.forward_vec()
        if self.mode == CamMode.TOP:
            return (t.x, 50.0, t.z)
        else:  # CHASE
            return (t.x - fx*self.dist_chase, self.height_chase, t.z - fz*self.dist_chase)

    def _set_projection(self, width, height, fov):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        if self.mode == CamMode.TOP:
            aspect = width / float(height)
            y = self.top_zoom
            x = y * aspect
            glOrtho(-x, x, -y, y, -200.0, 200.0)
        else:  # CHASE perspective
            gluPerspective(fov, width/float(height), 0.1, 800.0)
        glMatrixMode(GL_MODELVIEW)

    def apply(self, t, width, height):
        fx, fz = t.forward_vec()

        # FOV breathing disabled in TOP mode
        fov = self.fov_base + (0 if self.mode == CamMode.TOP else clamp(abs(t.speed)*0.5, 0, 8))
        self._set_projection(width, height, fov)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        if self.mode == CamMode.TOP:
            cam_x, cam_y, cam_z = t.x, 50.0, t.z
            gluLookAt(cam_x, cam_y, cam_z, t.x, 0.0, t.z, 0, 0, -1)
        else:  # CHASE
            cam = (t.x - fx*self.dist_chase, self.height_chase, t.z - fz*self.dist_chase)
            look= (t.x + fx*self.look_ahead, 0.95, t.z + fz*self.look_ahead)
            gluLookAt(*cam, *look, 0, 1, 0)


