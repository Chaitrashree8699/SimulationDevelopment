import math
import os
from typing import Sequence
from OpenGL.GL import *
from farm_sim.util import clamp
from farm_sim.world.obstacles import Obstacle, SIZE_MULTIPLIERS

# Global variables for 3D model and texture
_tractor_model = None
_tractor_texture = None
_use_3d_model = False

TRACTOR_AXLE_FRONT_Z = -0.80
TRACTOR_AXLE_REAR_Z = 0.90
TRACTOR_REAR_RADIUS = 0.42
TRACTOR_FRONT_RADIUS = 0.32
TRACTOR_REAR_RIM = 0.26
TRACTOR_FRONT_RIM = 0.20


def initialize_tractor_model():
    """Load the 3D tractor model and texture if available."""
    global _tractor_model, _tractor_texture, _use_3d_model
    
    # Try to load the OBJ model
    model_path = os.path.join("assets", "models", "tractor.obj")
    texture_path = os.path.join("assets", "models", "tractor.jpg")
    
    if os.path.exists(model_path):
        try:
            from farm_sim.render.model_loader import load_model
            _tractor_model = load_model(model_path, "tractor")
            if _tractor_model:
                print(f"Loaded 3D tractor model from {model_path}")
                _use_3d_model = True
        except Exception as e:
            print(f"Failed to load 3D model: {e}")
            _use_3d_model = False
    
    # Try to load the texture
    if os.path.exists(texture_path):
        try:
            from farm_sim.render.texture_loader import load_texture
            _tractor_texture = load_texture(texture_path, "tractor")
            if _tractor_texture:
                print(f"Loaded tractor texture from {texture_path}")
        except Exception as e:
            print(f"Failed to load texture: {e}")
            _tractor_texture = None


def draw_cube(w=1,h=1,d=1):
    hw,hh,hd=w/2,h/2,d/2
    glBegin(GL_QUADS)
    glNormal3f(0,1,0);  glVertex3f(-hw,hh,-hd); glVertex3f(hw,hh,-hd); glVertex3f(hw,hh,hd); glVertex3f(-hw,hh,hd)
    glNormal3f(0,-1,0); glVertex3f(-hw,-hh,hd); glVertex3f(hw,-hh,hd); glVertex3f(hw,-hh,-hd); glVertex3f(-hw,-hh,-hd)
    glNormal3f(0,0,-1); glVertex3f(-hw,-hh,-hd); glVertex3f(hw,-hh,-hd); glVertex3f(hw,hh,-hd); glVertex3f(-hw,hh,-hd)
    glNormal3f(0,0,1);  glVertex3f(-hw,-hh,hd); glVertex3f(-hw,hh,hd); glVertex3f(hw,hh,hd); glVertex3f(hw,-hh,hd)
    glNormal3f(-1,0,0); glVertex3f(-hw,-hh,-hd); glVertex3f(-hw,hh,-hd); glVertex3f(-hw,hh,hd); glVertex3f(-hw,-hh,hd)
    glNormal3f(1,0,0);  glVertex3f(hw,-hh,-hd); glVertex3f(hw,-hh,hd); glVertex3f(hw,hh,hd); glVertex3f(hw,hh,-hd)
    glEnd()

def _set_material_color(r: float, g: float, b: float, a: float = 1.0):
    glColor4f(r, g, b, a)
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (r, g, b, a))

def _effective_scale(obs: Obstacle) -> float:
    return obs.scale * SIZE_MULTIPLIERS.get(getattr(obs, "size", "medium"), 1.0)

def draw_cylinder(radius=0.2, height=0.4, slices=24):
    glBegin(GL_TRIANGLE_FAN)
    glNormal3f(0,-1,0); glVertex3f(0,-height/2,0)
    for i in range(slices+1):
        a = 2*math.pi*i/slices; glVertex3f(radius*math.cos(a), -height/2, radius*math.sin(a))
    glEnd()
    glBegin(GL_TRIANGLE_FAN)
    glNormal3f(0,1,0); glVertex3f(0,height/2,0)
    for i in range(slices+1):
        a = 2*math.pi*i/slices; glVertex3f(radius*math.cos(a), height/2, radius*math.sin(a))
    glEnd()
    glBegin(GL_QUAD_STRIP)
    for i in range(slices+1):
        a = 2*math.pi*i/slices; nx,nz=math.cos(a), math.sin(a)
        glNormal3f(nx,0,nz)
        glVertex3f(radius*nx, -height/2, radius*nz)
        glVertex3f(radius*nx,  height/2, radius*nz)
    glEnd()

def draw_wheel(tire_r=0.4, tire_w=0.25, rim_r=0.24, spin_deg=0.0):
    glPushMatrix()
    glRotatef(spin_deg, 1,0,0)   # roll around X
    glRotatef(90, 0,0,1)         # lie cylinder on X
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (0.06,0.06,0.06,1))
    draw_cylinder(radius=tire_r, height=tire_w, slices=28)
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (0.95,0.85,0.15,1))
    draw_cylinder(radius=rim_r, height=tire_w*0.9, slices=24)
    glPopMatrix()

def _draw_tree(obs: Obstacle, season: str = "Spring"):
    scale = _effective_scale(obs)
    trunk_h = 1.9 * scale
    trunk_w = 0.34 * scale
    canopy_bottom = trunk_h * 0.9
    canopy_h = 1.3 * scale
    canopy_w = 1.5 * scale
    glPushMatrix()
    glTranslatef(obs.x, 0.0, obs.z)
    glRotatef(obs.rotation, 0, 1, 0)
    
    # Trunk color (same for all seasons)
    _set_material_color(0.40, 0.25, 0.11)
    glPushMatrix()
    glTranslatef(0.0, trunk_h * 0.5, 0.0)
    draw_cube(trunk_w, trunk_h, trunk_w)
    glPopMatrix()
    
    # Canopy colors by season
    if season == "Spring":
        _set_material_color(0.15, 0.55, 0.20)  # Lighter green
    elif season == "Summer":
        _set_material_color(0.08, 0.60, 0.12)  # Richer, deeper green
    elif season == "Autumn":
        _set_material_color(0.80, 0.16, 0.0)  # Red-orange (RGB 204, 41, 0)
    elif season == "Winter":
        _set_material_color(0.95, 0.95, 0.97)  # Snow white
    else:
        _set_material_color(0.08, 0.48, 0.15)  # Default green
    
    glPushMatrix()
    glTranslatef(0.0, canopy_bottom + canopy_h * 0.4, 0.0)
    draw_cube(canopy_w * 0.8, canopy_h, canopy_w * 0.8)
    glPopMatrix()
    glPushMatrix()
    glTranslatef(0.0, canopy_bottom + canopy_h * 0.7, 0.0)
    draw_cube(canopy_w, canopy_h * 0.8, canopy_w)
    glPopMatrix()
    glPopMatrix()

def _draw_stone(obs: Obstacle):
    scale = _effective_scale(obs)
    base = 0.95 * scale
    height = 0.55 * scale

    # subtle decal on the soil so stones pop from top view
    lighting_enabled = glIsEnabled(GL_LIGHTING)
    if lighting_enabled:
        glDisable(GL_LIGHTING)
    glPushMatrix()
    glTranslatef(obs.x, 0.001, obs.z)
    glColor4f(0.32, 0.32, 0.32, 0.55)
    segments = 36
    radius = base * 0.9
    glBegin(GL_TRIANGLE_FAN)
    glVertex3f(0.0, 0.0, 0.0)
    for i in range(segments + 1):
        angle = 2.0 * math.pi * i / segments
        glVertex3f(math.cos(angle) * radius, 0.0, math.sin(angle) * radius)
    glEnd()
    glPopMatrix()
    if lighting_enabled:
        glEnable(GL_LIGHTING)

    glPushMatrix()
    glTranslatef(obs.x, height * 0.5, obs.z)
    glRotatef(obs.rotation, 0, 1, 0)
    _set_material_color(0.58, 0.57, 0.55)
    glScalef(1.2, 1.0, 0.9)
    draw_cube(base, height, base * 0.85)
    glPopMatrix()

def _draw_bush(obs: Obstacle, season: str = "Spring"):
    scale = _effective_scale(obs)
    width = 1.2 * scale
    height = 0.7 * scale
    glPushMatrix()
    glTranslatef(obs.x, height * 0.5, obs.z)
    glRotatef(obs.rotation, 0, 1, 0)
    
    # Bush colors by season
    if season == "Spring":
        outer_color = (0.18, 0.58, 0.25)  # Lighter green
        inner_color = (0.12, 0.48, 0.20)
    elif season == "Summer":
        outer_color = (0.10, 0.65, 0.15)  # Richer, deeper green
        inner_color = (0.08, 0.55, 0.12)
    elif season == "Autumn":
        outer_color = (0.14, 0.45, 0.12)  # Dark green with golden tone
        inner_color = (0.10, 0.38, 0.09)
    elif season == "Winter":
        outer_color = (0.15, 0.20, 0.12)  # Very dark green/brown
        inner_color = (0.10, 0.14, 0.08)  # Even darker green/brown
    else:
        outer_color = (0.12, 0.52, 0.20)  # Default
        inner_color = (0.07, 0.42, 0.16)
    
    _set_material_color(*outer_color)
    draw_cube(width, height, width * 0.85)
    _set_material_color(*inner_color)
    glTranslatef(0.0, height * 0.25, 0.0)
    draw_cube(width * 0.8, height * 0.8, width * 0.7)
    glPopMatrix()

def _draw_pond(obs: Obstacle):
    scale = _effective_scale(obs)
    radius_x = 2.3 * scale
    radius_z = 1.7 * scale
    glPushMatrix()
    glTranslatef(obs.x, 0.001, obs.z)
    glRotatef(obs.rotation, 0, 1, 0)
    segments = 42
    lighting_enabled = glIsEnabled(GL_LIGHTING)
    cull_enabled = glIsEnabled(GL_CULL_FACE)
    glPushAttrib(GL_POLYGON_BIT)
    if lighting_enabled:
        glDisable(GL_LIGHTING)
    if cull_enabled:
        glDisable(GL_CULL_FACE)
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

    glColor4f(0.10, 0.45, 0.85, 1.0)
    glBegin(GL_TRIANGLE_FAN)
    glVertex3f(0.0, 0.0, 0.0)
    for i in range(segments + 1):
        angle = 2.0 * math.pi * i / segments
        px = math.cos(angle) * radius_x
        pz = math.sin(angle) * radius_z
        glVertex3f(px, 0.0, pz)
    glEnd()

    glColor4f(0.02, 0.20, 0.42, 1.0)
    glLineWidth(2.5)
    glBegin(GL_LINE_LOOP)
    for i in range(segments):
        angle = 2.0 * math.pi * i / segments
        px = math.cos(angle) * radius_x
        pz = math.sin(angle) * radius_z
        glVertex3f(px, 0.0, pz)
    glEnd()

    if cull_enabled:
        glEnable(GL_CULL_FACE)
    if lighting_enabled:
        glEnable(GL_LIGHTING)
    glPopAttrib()

    glPopMatrix()

def draw_obstacles(obstacles: Sequence[Obstacle], season: str = "Spring"):
    for obs in obstacles:
        kind = obs.kind.lower()
        if kind == "tree":
            _draw_tree(obs, season=season)
        elif kind == "stone":
            _draw_stone(obs)
        elif kind == "bush":
            _draw_bush(obs, season=season)
        elif kind == "pond":
            _draw_pond(obs)

def draw_tractor_john_deere(t):
    """Draw the John Deere tractor using either 3D model or fallback to simple geometry."""
    global _tractor_model, _tractor_texture, _use_3d_model
    
    # Initialize model on first call
    if _tractor_model is None and not hasattr(draw_tractor_john_deere, '_init_attempted'):
        initialize_tractor_model()
        draw_tractor_john_deere._init_attempted = True
    
    glPushMatrix()
    glTranslatef(t.x, t.y, t.z)
    glRotatef(-math.degrees(t.yaw), 0, 1, 0)  # flipped to match world orientation

    # Use 3D model if available
    if _use_3d_model and _tractor_model:
        draw_tractor_3d_model(t)
    else:
        # Fallback to original cube-based rendering
        draw_tractor_simple(t)

    # Draw implements (same for both rendering modes)
    if getattr(t, "implement_enabled", False) and getattr(t, "attached_implement", None):
        glPushMatrix()
        glDisable(GL_LIGHTING)

        from farm_sim.entities.implements import ImplementType, draw_implement

        # Position behind tractor; adjust offsets only here
        if t.attached_implement == ImplementType.HARVESTER:
            glTranslatef(0.0, -0.05, 0.5)
        else:
            glTranslatef(0.0, -0.05, 3.6)

        # Delegate all implement-specific transforms to draw_implement
        draw_implement(t.attached_implement, t)
        glEnable(GL_LIGHTING)
        glPopMatrix()

    glPopMatrix()


def draw_tractor_3d_model(t):
    """Draw tractor using the loaded 3D model with texture."""
    global _tractor_model, _tractor_texture
    
    # Enable texturing if texture is available
    texture_enabled = False
    if _tractor_texture:
        glEnable(GL_TEXTURE_2D)
        from farm_sim.render.texture_loader import bind_texture
        bind_texture(_tractor_texture)
        texture_enabled = True
    
    # Set material properties for the model
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (1.0, 1.0, 1.0, 1.0))
    
    # Apply transformations for the model
    # Model dimensions: X: 75.81, Y: 83.39, Z: 135.29 (very large!)
    # Target size: ~2 units (to match simple tractor)
    glPushMatrix()
    
    # Lift the tractor up so wheels sit on ground instead of being buried
    glTranslatef(0.0, 0.4, 0.0)
    
    # Rotate to align with simulation coordinate system FIRST
    # Model's Z-axis should point forward (simulation -Z is forward)
    glRotatef(-90, 1, 0, 0)  # Rotate from Z-up to Y-up
    glRotatef(180, 0, 1, 0)  # Flip to face forward
    glRotatef(90, 1, 0, 0)  # Flip upright - front was pointing down
    glRotatef(180, 1, 0, 0)  # Additional 180 degree rotation around X-axis
    
    # Scale to match original tractor size
    # Original chassis: 2.2 units long, Model: 135.29 units long
    # Scale factor: 2.2 / 135.29 = 0.01626, increased by 50% for better visibility
    scale = 0.02  # 1.5x larger than original
    glScalef(scale, scale, scale)
    
    # Center the model at origin AFTER rotation and scaling
    glTranslatef(-0.5, -0.3, -97.9)  # Move model center to origin
    
    # Render the model
    _tractor_model.render()
    
    glPopMatrix()
    
    # Disable texturing
    if texture_enabled:
        from farm_sim.render.texture_loader import unbind_texture
        unbind_texture()
        glDisable(GL_TEXTURE_2D)
    
    # Don't draw separate wheels - the 3D model includes them


def draw_tractor_simple(t):
    """Draw tractor using simple cube-based geometry (fallback)."""
    JD_GREEN = (0.07, 0.45, 0.12, 1)
    BLACK    = (0.06, 0.06, 0.06, 1)

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, JD_GREEN)
    draw_cube(1.2, 0.5, 2.2)                                # chassis
    glPushMatrix(); glTranslatef(0, 0.35, 0.55); draw_cube(0.9, 0.35, 1.1); glPopMatrix()   # hood
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (0.25, 0.7, 0.95, 0.85))
    glPushMatrix(); glTranslatef(0, 0.55, -0.35); draw_cube(0.9, 0.7, 0.9); glPopMatrix()   # cab
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, BLACK)
    glPushMatrix(); glTranslatef(0, 0.2, 1.15); draw_cube(0.6, 0.4, 0.08); glPopMatrix()    # grille

    draw_tractor_wheels(t)


def draw_tractor_wheels(t):
    """Draw animated wheels for the tractor."""
    # --- Rear wheels (spin only) ---
    for sx in (-0.62, 0.62):
        glPushMatrix()
        glTranslatef(sx, -0.05, TRACTOR_AXLE_REAR_Z)
        draw_wheel(
            tire_r=TRACTOR_REAR_RADIUS,
            tire_w=0.28,
            rim_r=TRACTOR_REAR_RIM,
            spin_deg=t.rear_spin,
        )
        glPopMatrix()

    # --- Front wheels (steer + spin) ---
    steer_deg = -math.degrees(clamp(t.steer, -t.MAX_STEER, t.MAX_STEER))
    for sx in (-0.55, 0.55):
        glPushMatrix()
        glTranslatef(sx, -0.10, TRACTOR_AXLE_FRONT_Z)
        glRotatef(steer_deg, 0, 1, 0)
        draw_wheel(
            tire_r=TRACTOR_FRONT_RADIUS,
            tire_w=0.24,
            rim_r=TRACTOR_FRONT_RIM,
            spin_deg=t.front_spin,
        )
        glPopMatrix()


def draw_crop(c, now: float, season: str = "Spring", camera_pos=None):
    """Draw a crop with LOD system based on distance."""
    if c.harvested: 
        return
    
    from farm_sim.config import SEASON_EFFECTS
    effects = SEASON_EFFECTS.get(season, SEASON_EFFECTS["Spring"])
    
    g = c.growth(now)
    stem_h = 0.2 + 0.8*g
    
    # Calculate distance for LOD
    if camera_pos:
        dist_sq = (c.x - camera_pos[0])**2 + (c.z - camera_pos[2])**2
        # Distance culling - don't render beyond 100m
        if dist_sq > 10000:  # 100m squared
            return
    else:
        dist_sq = 0
    
    # Get crop colors
    stem_color = effects["crop_stem_color"]
    head_color = effects["crop_head_color"]
    
    # Adjust colors for crop state
    if getattr(c, 'watered', False):
        stem_color = (0.15, 0.85, 0.35)
        head_color = (1.0, 0.95, 0.20)
    elif getattr(c, 'sprayed', False):
        stem_color = (0.05, 0.45, 0.10)
        head_color = (head_color[0]*0.85, head_color[1]*0.85, head_color[2]*0.85)
    
    glPushMatrix()
    glTranslatef(c.x, 0.0, c.z)
    
    # Simplified line-based rendering (2 vertices instead of 48)
    glDisable(GL_LIGHTING)
    
    # Draw stem as line
    glColor3f(*stem_color)
    glLineWidth(3.0)
    glBegin(GL_LINES)
    glVertex3f(0, 0, 0)
    glVertex3f(0, stem_h, 0)
    glEnd()
    
    # Draw head as point
    glColor3f(*head_color)
    glPointSize(6.0)
    glBegin(GL_POINTS)
    glVertex3f(0, stem_h+0.07, 0)
    glEnd()
    
    glEnable(GL_LIGHTING)
    
    glPopMatrix()
