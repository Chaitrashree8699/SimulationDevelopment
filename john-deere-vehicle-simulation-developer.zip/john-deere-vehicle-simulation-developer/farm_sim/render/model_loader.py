"""
OBJ model loader for 3D models.
Supports loading Wavefront OBJ files with vertices, texture coordinates, normals, and faces.
"""
import os
from typing import List, Tuple, Optional
from OpenGL.GL import *


class OBJModel:
    """Represents a loaded 3D model from an OBJ file."""
    
    def __init__(self):
        self.vertices = []      # List of (x, y, z) tuples
        self.tex_coords = []    # List of (u, v) tuples
        self.normals = []       # List of (nx, ny, nz) tuples
        self.faces = []         # List of face data
        self.display_list = None
        
    def load_from_file(self, filepath: str) -> bool:
        """Load OBJ file and parse geometry data."""
        if not os.path.exists(filepath):
            print(f"Error: Model file not found: {filepath}")
            return False
            
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                        
                    parts = line.split()
                    if not parts:
                        continue
                        
                    # Parse vertex positions
                    if parts[0] == 'v':
                        x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
                        self.vertices.append((x, y, z))
                        
                    # Parse texture coordinates
                    elif parts[0] == 'vt':
                        u = float(parts[1])
                        v = float(parts[2]) if len(parts) > 2 else 0.0
                        self.tex_coords.append((u, v))
                        
                    # Parse normals
                    elif parts[0] == 'vn':
                        nx, ny, nz = float(parts[1]), float(parts[2]), float(parts[3])
                        self.normals.append((nx, ny, nz))
                        
                    # Parse faces
                    elif parts[0] == 'f':
                        face = []
                        for i in range(1, len(parts)):
                            # Face format can be: v, v/vt, v/vt/vn, or v//vn
                            indices = parts[i].split('/')
                            v_idx = int(indices[0]) - 1  # OBJ indices start at 1
                            
                            vt_idx = None
                            vn_idx = None
                            
                            if len(indices) > 1 and indices[1]:
                                vt_idx = int(indices[1]) - 1
                            if len(indices) > 2 and indices[2]:
                                vn_idx = int(indices[2]) - 1
                                
                            face.append((v_idx, vt_idx, vn_idx))
                        self.faces.append(face)
                        
            print(f"Loaded OBJ model: {len(self.vertices)} vertices, {len(self.faces)} faces")
            return True
            
        except Exception as e:
            print(f"Error loading OBJ file {filepath}: {e}")
            return False
            
    def compile_display_list(self):
        """Compile the model into an OpenGL display list for efficient rendering."""
        if self.display_list is not None:
            return
            
        self.display_list = glGenLists(1)
        glNewList(self.display_list, GL_COMPILE)
        
        for face in self.faces:
            # Determine primitive type based on face vertex count
            if len(face) == 3:
                glBegin(GL_TRIANGLES)
            elif len(face) == 4:
                glBegin(GL_QUADS)
            else:
                # Handle polygons with more than 4 vertices using triangle fan
                glBegin(GL_TRIANGLE_FAN)
                
            for v_idx, vt_idx, vn_idx in face:
                # Set normal if available
                if vn_idx is not None and vn_idx < len(self.normals):
                    glNormal3fv(self.normals[vn_idx])
                    
                # Set texture coordinate if available
                if vt_idx is not None and vt_idx < len(self.tex_coords):
                    glTexCoord2fv(self.tex_coords[vt_idx])
                    
                # Set vertex position
                if v_idx < len(self.vertices):
                    glVertex3fv(self.vertices[v_idx])
                    
            glEnd()
            
        glEndList()
        
    def render(self):
        """Render the model using the compiled display list."""
        if self.display_list is None:
            self.compile_display_list()
            
        if self.display_list is not None:
            glCallList(self.display_list)
            
    def cleanup(self):
        """Free OpenGL resources."""
        if self.display_list is not None:
            glDeleteLists(self.display_list, 1)
            self.display_list = None


# Global cache for loaded models
_model_cache = {}


def load_model(filepath: str, cache_key: Optional[str] = None) -> Optional[OBJModel]:
    """
    Load an OBJ model from file with caching support.
    
    Args:
        filepath: Path to the OBJ file
        cache_key: Optional key for caching (defaults to filepath)
        
    Returns:
        OBJModel instance if successful, None otherwise
    """
    if cache_key is None:
        cache_key = filepath
        
    # Check cache first
    if cache_key in _model_cache:
        return _model_cache[cache_key]
        
    # Load new model
    model = OBJModel()
    if model.load_from_file(filepath):
        _model_cache[cache_key] = model
        return model
    else:
        return None


def get_cached_model(cache_key: str) -> Optional[OBJModel]:
    """Get a previously loaded model from cache."""
    return _model_cache.get(cache_key)


def clear_model_cache():
    """Clear all cached models and free their resources."""
    for model in _model_cache.values():
        model.cleanup()
    _model_cache.clear()
