"""
Texture loader for OpenGL textures.
Supports loading image files (PNG, JPG, BMP, etc.) as OpenGL textures.
"""
import os
from typing import Optional, Dict
import pygame
from OpenGL.GL import *


# Global cache for loaded textures
_texture_cache: Dict[str, int] = {}


def load_texture(filepath: str, cache_key: Optional[str] = None) -> Optional[int]:
    """
    Load an image file as an OpenGL texture with caching support.
    
    Args:
        filepath: Path to the image file
        cache_key: Optional key for caching (defaults to filepath)
        
    Returns:
        OpenGL texture ID if successful, None otherwise
    """
    if cache_key is None:
        cache_key = filepath
        
    # Check cache first
    if cache_key in _texture_cache:
        return _texture_cache[cache_key]
        
    # Check if file exists
    if not os.path.exists(filepath):
        print(f"Error: Texture file not found: {filepath}")
        return None
        
    try:
        # Load image using pygame
        texture_surface = pygame.image.load(filepath)
        texture_data = pygame.image.tostring(texture_surface, "RGB", True)
        
        width = texture_surface.get_width()
        height = texture_surface.get_height()
        
        # Generate OpenGL texture
        texture_id = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture_id)
        
        # Set texture parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        
        # Upload texture data
        glTexImage2D(
            GL_TEXTURE_2D, 0, GL_RGB, width, height, 0,
            GL_RGB, GL_UNSIGNED_BYTE, texture_data
        )
        
        # Unbind texture
        glBindTexture(GL_TEXTURE_2D, 0)
        
        # Cache the texture
        _texture_cache[cache_key] = texture_id
        
        print(f"Loaded texture: {filepath} ({width}x{height}) -> ID {texture_id}")
        return texture_id
        
    except Exception as e:
        print(f"Error loading texture {filepath}: {e}")
        return None


def bind_texture(texture_id: int):
    """Bind a texture for rendering."""
    if texture_id is not None:
        glBindTexture(GL_TEXTURE_2D, texture_id)


def unbind_texture():
    """Unbind the current texture."""
    glBindTexture(GL_TEXTURE_2D, 0)


def get_cached_texture(cache_key: str) -> Optional[int]:
    """Get a previously loaded texture from cache."""
    return _texture_cache.get(cache_key)


def clear_texture_cache():
    """Clear all cached textures and free their resources."""
    for texture_id in _texture_cache.values():
        if glIsTexture(texture_id):
            glDeleteTextures([texture_id])
    _texture_cache.clear()


def delete_texture(texture_id: int):
    """Delete a specific texture."""
    if glIsTexture(texture_id):
        glDeleteTextures([texture_id])
        # Remove from cache if present
        keys_to_remove = [k for k, v in _texture_cache.items() if v == texture_id]
        for key in keys_to_remove:
            del _texture_cache[key]
