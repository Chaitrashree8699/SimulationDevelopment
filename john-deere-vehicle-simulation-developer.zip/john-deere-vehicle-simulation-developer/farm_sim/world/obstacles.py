from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Tuple

from farm_sim.util import clamp


SIZE_MULTIPLIERS = {
    "small": 0.7,
    "medium": 1.0,
    "large": 2,
}

_BASE_COLLISION_RADII = {
    "tree": 1.0,
    "bush": 0.8,
    "stone": 0.65,
    "pond": 1.8,
}


@dataclass(frozen=True)
class Obstacle:
    """Simple record describing a decorative or blocking obstacle."""
    kind: str
    x: float
    z: float
    scale: float
    size: str = "medium"
    rotation: float = 0.0

    def describe(self) -> str:
        """Compact string description for logging."""
        return (f"{self.kind}(size={self.size}, scale={self.scale:.2f}, "
                f"x={self.x:.2f}, z={self.z:.2f}, rot={self.rotation:.1f})")


# Normalized anchor points (-1..1 range) for large scenic features.
_FIELD_FEATURES: Sequence[Tuple[str, str, float, float, float, float]] = (
    ("tree", "large", 0.0, -0.40, 1.10, 20.0),
    ("tree", "medium", 0.74, -0.30, 1.00, -24.0),
    # ("tree", "small", -0.12, -0.08, 0.95, 6.0),  # centre line
    ("stone", "small", -0.58, 0.29, 0.65, 0.0),
    ("stone", "medium", 0.74, 0.30, 0.55, 0.0),
    ("bush", "large", -0.55, -0.26, 0.90, 0.0),
    ("bush", "medium", 0.25, 0.30, 0.82, 0.0),
    ("pond", "large", 0.70, -0.20, 0.50, -10.0),
)


def _clamped_position(nx: float, nz: float, half_w: float, half_h: float, margin: float) -> Tuple[float, float]:
    """Convert normalized coordinates into field space while respecting a margin."""
    return (
        clamp(nx * half_w, -half_w + margin, half_w - margin),
        clamp(nz * half_h, -half_h + margin, half_h - margin),
    )


def _sample_path_points(path: Iterable[Tuple[float, float]], sample_count: int) -> List[Tuple[float, float]]:
    pts = list(path)
    if not pts or sample_count <= 0:
        return []

    count = min(sample_count, max(1, len(pts) // 3))
    step = max(1, len(pts) // (count + 1))
    result: List[Tuple[float, float]] = []
    idx = step
    while len(result) < count and idx < len(pts):
        result.append(pts[idx])
        idx += step
    return result


def collision_radius(obs: Obstacle, padding: float = 0.0) -> float:
    size_scale = SIZE_MULTIPLIERS.get(getattr(obs, "size", "medium"), 1.0)
    base = _BASE_COLLISION_RADII.get(obs.kind.lower(), 0.9)
    # NOTE: base radius depends only on kind/size/scale, not on field dimensions.
    return max(0.2, base * obs.scale * size_scale + padding)


def generate_obstacles(field_w: float, field_h: float, path: Optional[Iterable[Tuple[float, float]]] = None) -> List[Obstacle]:
    """Create a deterministic set of obstacles for the field.

    Parameters
    ----------
    field_w, field_h:
        Field dimensions in metres.
    path:
        Optional tractor path. A subset of these points will be used to place
        blocking stones / bushes directly in the lane.
    """
    half_w = max(1.0, field_w * 0.5)
    half_h = max(1.0, field_h * 0.5)

    # Use a fixed global scale so obstacle size (and thus collision radius)
    # does not creep up as fields get larger.
    # If you want tiny variation with field size, keep the clamp band very tight.
    # Example: 0.95..1.05 instead of 0.6..1.35.
    scale_factor = 1.0  # <- decoupled from field size

    scenic_margin = clamp(min(half_w, half_h) * 0.10, 1.2, 7.5)
    allow_large = field_w >= 60.0 and field_h >= 60.0

    obstacles: List[Obstacle] = []
    for kind, size_label, nx, nz, scale, rotation in _FIELD_FEATURES:
        if not allow_large and size_label == "large":
            continue
        if kind == "pond":
            x = clamp(0.0, -half_w + scenic_margin, half_w - scenic_margin)
            z = clamp(0.0, -half_h + scenic_margin, half_h - scenic_margin)
        else:
            x, z = _clamped_position(nx, nz, half_w, half_h, scenic_margin)
        obstacles.append(
            Obstacle(
                kind=kind,
                x=x,
                z=z,
                scale=scale * scale_factor,
                size=size_label,
                rotation=rotation,
            )
        )

    # Create blocking obstacles that sit directly on the planned tractor route.
    if path:
        path_samples = _sample_path_points(path, sample_count=5)
        if path_samples:
            blockers_cycle = [
                ("stone", "small", 0.05, 0.0),
                ("bush", "medium", 0.65, -18.0),
                ("tree", "small", 0.80, 12.0),
                ("pond", "small", 0.50, 0.0),
                ("bush", "large", 0.72, 28.0),
            ]
            if not allow_large:
                blockers_cycle = [entry for entry in blockers_cycle if entry[1] != "large"]
            if not blockers_cycle:
                return obstacles
            for idx, (px, pz) in enumerate(path_samples):
                kind, size_label, rel_scale, rotation = blockers_cycle[idx % len(blockers_cycle)]
                place_x = clamp(px, -half_w + 0.6, half_w - 0.6)
                place_z = clamp(pz, -half_h + 0.6, half_h - 0.6)
                obstacles.append(
                    Obstacle(
                        kind=kind,
                        x=place_x,
                        z=place_z,
                        scale=rel_scale * scale_factor,
                        size=size_label,
                        rotation=rotation,
                    )
                )

    return obstacles
