from OpenGL.GL import *
from farm_sim.config import GRID_SIZE, SEASON_COLORS

def draw_ground(field_w, field_h, season="Spring"):
    """
    Draw rectangular field centered at (0,0),
    width = field_w along X, height = field_h along Z.
    Grass border + inner soil + plow lines.
    
    Parameters
    ----------
    field_w, field_h : float
        Field dimensions in meters.
    season : str
        Season name ("Spring", "Summer", "Autumn", "Winter")
        determines field colors.
    """
    # Get season colors, fallback to Spring if invalid
    colors = SEASON_COLORS.get(season, SEASON_COLORS["Spring"])
    
    was_cull = glIsEnabled(GL_CULL_FACE)
    if was_cull:
        glDisable(GL_CULL_FACE)

    hw = field_w * 0.5  # half-width in X
    hh = field_h * 0.5  # half-height in Z

    # --- base field (soil area) ---
    glDisable(GL_LIGHTING)
    soil_color = colors["soil"]
    glColor3f(*soil_color)
    glBegin(GL_QUADS)
    glVertex3f(-hw, 0.0, -hh)
    glVertex3f( hw, 0.0, -hh)
    glVertex3f( hw, 0.0,  hh)
    glVertex3f(-hw, 0.0,  hh)
    glEnd()



    # --- field boundary (1m wide grass border) ---
    grass_color = colors["grass"]
    glColor3f(*grass_color)
    # Top border
    glBegin(GL_QUADS)
    glVertex3f(-hw, 0.001, -hh)
    glVertex3f( hw, 0.001, -hh)
    glVertex3f( hw, 0.001, -hh + 1.0)
    glVertex3f(-hw, 0.001, -hh + 1.0)
    glEnd()
    # Bottom border
    glBegin(GL_QUADS)
    glVertex3f(-hw, 0.001,  hh - 1.0)
    glVertex3f( hw, 0.001,  hh - 1.0)
    glVertex3f( hw, 0.001,  hh)
    glVertex3f(-hw, 0.001,  hh)
    glEnd()
    # Left border
    glBegin(GL_QUADS)
    glVertex3f(-hw, 0.001, -hh + 1.0)
    glVertex3f(-hw + 1.0, 0.001, -hh + 1.0)
    glVertex3f(-hw + 1.0, 0.001,  hh - 1.0)
    glVertex3f(-hw, 0.001,  hh - 1.0)
    glEnd()
    # Right border
    glBegin(GL_QUADS)
    glVertex3f( hw - 1.0, 0.001, -hh + 1.0)
    glVertex3f( hw, 0.001, -hh + 1.0)
    glVertex3f( hw, 0.001,  hh - 1.0)
    glVertex3f( hw - 1.0, 0.001,  hh - 1.0)
    glEnd()

    glEnable(GL_LIGHTING)
    if was_cull:
        glEnable(GL_CULL_FACE)