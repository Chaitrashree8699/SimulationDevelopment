import pygame
from typing import List, Dict, Optional, Tuple
from farm_sim.gps_utils import create_field_from_gps
from farm_sim.config import ORG_ID
from operations_center.equipment_service import ensure_operations_center_tractors
from operations_center.fields_service import get_fields, get_field_boundaries

class FieldSelector:
    """UI for selecting John Deere fields"""
    
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.font = pygame.font.SysFont(None, 32)
        self.title_font = pygame.font.SysFont(None, 48)
        self.small_font = pygame.font.SysFont(None, 24)
        
        self.fields = []
        self.selected_index = 0
        self.scroll_offset = 0
        self.max_visible = 8
        
        self.api = None
        self.loading = False
        self.error_message = ""
        
    def fetch_fields(self) -> bool:
        """Fetch available fields from John Deere API"""
        self.loading = True
        
        try:
            raw_fields = get_fields(int(ORG_ID))
            
            # Convert to expected format and fetch area from boundaries
            self.fields = []
            for field in raw_fields:
                print(f"Processing field: {field}")
                
                field_id = field.get('id', '')
                if '/' in field_id:
                    field_id = field_id.split('/')[-1]
                
                # Try to get area from boundaries
                area_value = 0
                try:
                    _, area_ha = get_field_boundaries(field_id)
                    if area_ha > 0:
                        area_value = area_ha
                        print(f"Got area from boundaries: {area_ha} ha")
                except Exception:
                    # Fallback to field list area
                    area_info = field.get('area', {})
                    if area_info and 'value' in area_info:
                        area_value = area_info['value']
                
                print(f"Field ID: {field_id}, Name: {field.get('name')}, Area: {area_value}")
                
                self.fields.append({
                    'field_id': field_id,
                    'field_name': field.get('name', 'Unknown Field'),
                    'org_name': 'John Deere',
                    'area': area_value
                })
            
            self.loading = False
            
            if not self.fields:
                self.error_message = "No fields found"
                return False
            
            return True
        except Exception as e:
            self.loading = False
            self.error_message = f"Error fetching fields: {e}\nPlease provide a correct .env file"
            return False
    
    def handle_events(self, events) -> Optional[Dict]:
        """Handle input events, return selected field info or None"""
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return {"action": "cancel"}
                
                elif event.key == pygame.K_RETURN:
                    if self.fields and 0 <= self.selected_index < len(self.fields):
                        field = self.fields[self.selected_index]
                        return {"action": "select", "field": field}
                
                elif event.key == pygame.K_UP:
                    if self.selected_index > 0:
                        self.selected_index -= 1
                        if self.selected_index < self.scroll_offset:
                            self.scroll_offset = self.selected_index
                
                elif event.key == pygame.K_DOWN:
                    if self.selected_index < len(self.fields) - 1:
                        self.selected_index += 1
                        if self.selected_index >= self.scroll_offset + self.max_visible:
                            self.scroll_offset = self.selected_index - self.max_visible + 1
                
                elif event.key == pygame.K_r:
                    # Refresh fields
                    self.fetch_fields()
        
        return None
    
    def draw(self, screen):
        """Draw the field selection UI"""
        screen.fill((20, 40, 20))  # Dark green background
        
        # Title
        title = self.title_font.render("Select John Deere Field", True, (255, 255, 255))
        title_rect = title.get_rect(center=(self.width // 2, 60))
        screen.blit(title, title_rect)
        
        if self.loading:
            loading_text = self.font.render("Loading fields...", True, (255, 255, 100))
            loading_rect = loading_text.get_rect(center=(self.width // 2, self.height // 2))
            screen.blit(loading_text, loading_rect)
            return
        
        if self.error_message:
            # Split error message by newlines and render each line separately
            error_lines = self.error_message.split('\n')
            y_offset = self.height // 2 - (len(error_lines) * 20)
            
            for i, line in enumerate(error_lines):
                error_text = self.font.render(line, True, (255, 100, 100))
                error_rect = error_text.get_rect(center=(self.width // 2, y_offset + i * 35))
                screen.blit(error_text, error_rect)
            
            retry_text = self.small_font.render("Press ESC to cancel", True, (200, 200, 200))
            retry_rect = retry_text.get_rect(center=(self.width // 2, self.height // 2 + 80))
            screen.blit(retry_text, retry_rect)
            return
        
        if not self.fields:
            no_fields_text = self.font.render("No fields available", True, (255, 100, 100))
            no_fields_rect = no_fields_text.get_rect(center=(self.width // 2, self.height // 2))
            screen.blit(no_fields_text, no_fields_rect)
            return
        
        # Field list
        start_y = 120
        item_height = 60
        
        visible_fields = self.fields[self.scroll_offset:self.scroll_offset + self.max_visible]
        
        for i, field in enumerate(visible_fields):
            actual_index = self.scroll_offset + i
            is_selected = actual_index == self.selected_index
            
            # Background
            bg_color = (60, 120, 60) if is_selected else (40, 80, 40)
            item_rect = pygame.Rect(50, start_y + i * item_height, self.width - 100, item_height - 5)
            pygame.draw.rect(screen, bg_color, item_rect)
            pygame.draw.rect(screen, (100, 200, 100), item_rect, 2)
            
            # Field info
            field_name = field.get('field_name', 'Unknown Field')
            org_name = field.get('org_name', 'Unknown Org')
            area = field.get('area', 0)
            
            name_text = self.font.render(f"{field_name}", True, (255, 255, 255))
            org_text = self.small_font.render(f"Organization: {org_name}", True, (200, 200, 200))
            area_text = self.small_font.render(f"Area: {area:.1f} hectares", True, (200, 200, 200))
            
            screen.blit(name_text, (item_rect.x + 10, item_rect.y + 5))
            screen.blit(org_text, (item_rect.x + 10, item_rect.y + 25))
            screen.blit(area_text, (item_rect.x + 10, item_rect.y + 40))
        
        # Instructions
        instruction_text = "↑↓ Navigate  |  ENTER Select  |  R Refresh  |  ESC Cancel"
        text = self.small_font.render(instruction_text, True, (180, 180, 180))
        text_rect = text.get_rect(center=(self.width // 2, self.height - 30))
        screen.blit(text, text_rect)

def select_sample_gps_field() -> Optional[Tuple[float, float, object, List[Tuple[float, float]]]]:
    """Show sample GPS field selection UI"""
    pygame.init()
    width, height = 600, 400
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Sample GPS Fields")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 32)
    small_font = pygame.font.SysFont(None, 24)
    
    sample_fields = [
        {'name': 'Iowa Corn Field', 'id': 'sample_field_1', 'size': '15.2 ha'},
        {'name': 'Nebraska Soybean Field', 'id': 'sample_field_2', 'size': '22.8 ha'},
        {'name': 'Kansas Wheat Field', 'id': 'sample_field_3', 'size': '31.5 ha'}
    ]
    
    selected = 0
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                pygame.quit()
                return None
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % len(sample_fields)
                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(sample_fields)
                elif event.key == pygame.K_RETURN:
                    field_id = sample_fields[selected]['id']
                    from farm_sim.gps_utils import JohnDeereAPI
                    api = JohnDeereAPI("dummy_token")
                    boundaries = api.get_field_boundaries(field_id)
                    if boundaries:
                        field_w, field_h, converter = create_field_from_gps(boundaries)
                        pygame.quit()
                        return field_w, field_h, converter, boundaries
        
        screen.fill((20, 40, 20))
        
        title = font.render("Select Sample GPS Field", True, (255, 255, 255))
        screen.blit(title, ((width - title.get_width()) // 2, 50))
        
        for i, field in enumerate(sample_fields):
            color = (255, 255, 100) if i == selected else (200, 200, 200)
            text = font.render(f"{field['name']} ({field['size']})", True, color)
            screen.blit(text, (50, 120 + i * 60))
        
        instructions = small_font.render("↑↓ Navigate  |  ENTER Select  |  ESC Cancel", True, (180, 180, 180))
        screen.blit(instructions, ((width - instructions.get_width()) // 2, height - 40))
        
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()
    return None

def select_john_deere_field() -> Optional[Tuple[float, float, object, List[Tuple[float, float]]]]:
    """Show field selection UI and return field data"""
    pygame.init()
    width, height = 800, 600
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("John Deere Field Selection")
    clock = pygame.time.Clock()
    
    selector = FieldSelector(width, height)
    tractors_ensured = False

    # Try to fetch fields immediately
    if not selector.fetch_fields():
        print(f"Failed to fetch fields: {selector.error_message}")
    
    running = True
    while running:
        events = pygame.event.get()
        
        for event in events:
            if event.type == pygame.QUIT:
                running = False
        
        result = selector.handle_events(events)
        
        if result:
            if result["action"] == "cancel":
                pygame.quit()
                return None
            
            elif result["action"] == "select":
                field = result["field"]
                print(f"Selected field: {field['field_name']}")
                
                # Fetch field boundaries
                try:
                    print(f"Fetching boundaries for field ID: {field['field_id']}")
                    boundaries, area_ha = get_field_boundaries(field['field_id'])
                    print(f"Got boundaries: {len(boundaries) if boundaries else 0} points, area: {area_ha} ha")
                    if boundaries:
                        field_w, field_h, converter = create_field_from_gps(boundaries)
                        print(f"Field dimensions: {field_w:.1f}m x {field_h:.1f}m")
                        # Update field info with correct area
                        field['area'] = area_ha
                        pygame.quit()
                        return field_w, field_h, converter, boundaries
                    else:
                        # No boundaries available - check if area was fetched
                        area = field.get('area', 0)
                        print(f"Field area from API: {area}")
                        if area > 0:
                            # Convert hectares to square meters, assume square field
                            area_m2 = area * 10000
                            field_size = (area_m2 ** 0.5)  # Square root for square field
                            print(f"No boundaries found, creating {field_size:.1f}m x {field_size:.1f}m field from area")
                            pygame.quit()
                            return field_size, field_size, None, None
                        else:
                            # Fail - no boundaries and no area
                            selector.error_message = "Field has no boundaries or area data"
                            print("ERROR: Field has no boundaries or area data")
                            return None
                except Exception as e:
                    selector.error_message = f"Error fetching boundaries: {e}"
                    print(f"Boundary fetch error: {e}")
        if not tractors_ensured:
           ensure_operations_center_tractors(int(ORG_ID))
           tractors_ensured = True

        selector.draw(screen)
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()
    return None
