import sys, pygame, re
from typing import List, Tuple
from farm_sim.entities import all_tractor_specs
from farm_sim.config import ENABLE_SAMPLE_GPS_FIELDS

# ---------------------------------------
# Utilities
# ---------------------------------------
def wrap_text(font: pygame.font.Font, text: str, max_width: int) -> List[str]:
    """Soft-wrap a single paragraph into multiple lines within max_width."""
    if not text:
        return []
    words = text.split()
    lines, cur = [], ""
    for w in words:
        candidate = w if not cur else f"{cur} {w}"
        if font.size(candidate)[0] <= max_width:
            cur = candidate
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def clamp(val, lo, hi):
    return max(lo, min(hi, val))


# ---------------------------------------
# Menu
# ---------------------------------------
def start_menu(screen_w=1280, screen_h=720):
    pygame.init()
    screen = pygame.display.set_mode((screen_w, screen_h))
    pygame.display.set_caption("JD Tiny Farm — Field Dimensions")

    clock = pygame.time.Clock()

    # Fonts
    brand_font = pygame.font.SysFont(None, 66)
    font = pygame.font.SysFont(None, 44)
    medium = pygame.font.SysFont(None, 34)
    small = pygame.font.SysFont(None, 28)
    tiny = pygame.font.SysFont(None, 22)

    # ---------------------------------------
    # Gradient Background (JD theme)
    # ---------------------------------------
    def draw_gradient_background(surface):
        top_color = (6, 60, 18)
        bottom_color = (28, 130, 52)
        height = surface.get_height()
        for y in range(height):
            r = int(top_color[0] + (bottom_color[0] - top_color[0]) * (y / height))
            g = int(top_color[1] + (bottom_color[1] - top_color[1]) * (y / height))
            b = int(top_color[2] + (bottom_color[2] - top_color[2]) * (y / height))
            pygame.draw.line(surface, (r, g, b), (0, y), (surface.get_width(), y))

    # Colors
    COL_BG = (8, 68, 24)
    COL_BORDER = (255, 212, 0)
    COL_PANEL = (22, 95, 32, 235)
    COL_PANEL_BORDER = (200, 255, 140)
    COL_TEXT = (255, 220, 0)
    COL_TEXT_DIM = (230, 240, 200)
    COL_ACCENT = (255, 224, 60)
    COL_SHADOW = (0, 0, 0, 100)
    COL_INACTIVE = pygame.Color(180, 200, 160)
    COL_ACTIVE = pygame.Color(255, 240, 120)
    COL_ERR = pygame.Color("orange")

    # Data
    vehicle_specs = all_tractor_specs()
    selected_vehicle = 0
    dropdown_open = False
    
    # Tooltip state
    tooltip_visible = False
    tooltip_text = ""
    tooltip_pos = (0, 0)
    tooltip_timer = 0
    TOOLTIP_DELAY = 300

    # --- Implement options (first item = No Implement, used as default) ---
    implements = [
        (None,       "No Implement"),
        ("plow",      "Plower"),
        ("sower",     "Sower"),
        ("sprayer",   "Sprayer"),
        ("irrigation","Irrigator"),
        ("harvester", "Harvester"),
    ]
    selected_implement = 0  # default = "No Implement"
    implement_dropdown_open = False
    implement_hover = False
    implement_option_rects: List[Tuple[pygame.Rect, int]] = []

    seasons = ["Spring", "Summer", "Autumn", "Winter"]
    selected_season = 0
    season_dropdown_open = False

    field_maps = [
        {
            "key": "open_field",
            "name": "Open Field",
            "description": "Wide plot with tilled soil and no obstacles.",
            "obstacles": False
        },
        {
            "key": "training_course",
            "name": "Obstacle Course",
            "description": "Practice layout with trees, stones, bushes, and a pond on the lanes.",
            "obstacles": True
        },
        {
            "key": "john_deere_field",
            "name": "John Deere Field",
            "description": "Load real field boundaries from John Deere Operations Center.",
            "obstacles": False
        },
    ]

    if ENABLE_SAMPLE_GPS_FIELDS:
        field_maps.insert(2, {
            "key": "sample_gps_fields",
            "name": "Sample GPS Fields",
            "description": "Choose from Iowa, Nebraska, or Kansas sample fields.",
            "obstacles": False
        })

    selected_map = 0
    map_dropdown_open = False

    dropdown_animation = 0.0
    season_animation = 0.0
    map_animation = 0.0
    implement_animation = 0.0

    # Inputs
    input_w = ""
    input_h = ""
    active_w = False
    active_h = False

    # Geometry
    panel_w = clamp(int(screen_w * 0.80), 680, 920)
    panel_h = 520
    panel_rect = pygame.Rect((screen_w - panel_w) // 2, 140, panel_w, panel_h)

    inner_margin = 40
    box_gap = 28
    total_row_width = panel_rect.width - inner_margin * 2
    input_box_width = (total_row_width - box_gap) // 2

    dropdown_rect = pygame.Rect(
        panel_rect.x + inner_margin,
        panel_rect.y + 48,
        total_row_width,
        52
    )

    rect_y = dropdown_rect.bottom + 32
    rect_w = pygame.Rect(panel_rect.x + inner_margin, rect_y, input_box_width, 52)
    rect_h = pygame.Rect(rect_w.right + box_gap, rect_y, input_box_width, 52)

    # --- Implement dropdown geometry: full width, beneath inputs ---
    implement_rect = pygame.Rect(
        panel_rect.x + inner_margin,
        rect_h.bottom + 32,
        total_row_width,
        48
    )

    map_row_y = implement_rect.bottom + 32
    item_width = (total_row_width - box_gap) // 2
    map_rect = pygame.Rect(panel_rect.x + inner_margin, map_row_y, item_width, 50)
    season_rect = pygame.Rect(map_rect.right + box_gap, map_row_y, item_width, 50)

    button_width = 230
    button_height = 50
    button_x = panel_rect.x + (panel_rect.width - button_width) // 2
    button_y = min(season_rect.bottom + 48, panel_rect.bottom - inner_margin - button_height)
    button_rect = pygame.Rect(button_x, button_y, button_width, button_height)

    option_rects: List[Tuple[pygame.Rect, int]] = []
    season_option_rects: List[Tuple[pygame.Rect, int]] = []
    map_option_rects: List[Tuple[pygame.Rect, int]] = []

    option_height = 44
    season_option_height = 36

    # Cursor blink
    cursor_visible = True
    cursor_timer = 0
    cursor_blink_ms = 500

    # Validation
    err_w = ""
    err_h = ""
    err_area = ""

    # Help panel
    help_open = False
    help_tab = 0
    help_tabs = ["General", "Autopilot", "Time", "Tuning"]
    help_search = ""
    help_search_active = False
    help_scroll_offset = 0

    help_button_rect = pygame.Rect(screen_w - 70, screen_h - 70, 40, 40)

    help_panel_size = (500, 350)
    help_margin = 24
    help_panel_rect = pygame.Rect(
        screen_w - help_panel_size[0] - help_margin,
        screen_h - help_panel_size[1] - (help_margin + 40),
        help_panel_size[0],
        help_panel_size[1]
    )

    help_tab_rects: List[pygame.Rect] = []

    HELP_CONTENT = {
        "General": [
            ("K", "Pause / Resume Simulation"),
            ("ESC / Q", "Quit Simulation"),
            ("W", "Throttle / Accelerate Forward"),
            ("S", "Brake / Reverse"),
            ("A", "Steer Left"),
            ("D", "Steer Right"),
            ("SPACE", "Plant Crop"),
            ("E", "Harvest Nearby Crops"),
            ("C", "Cycle Camera Mode"),
            ("PAGE UP / DOWN", "Adjust Chase Camera Height"),
            ("N", "Cycle Noise Level (Off/Realistic/Strong)"),
            ("G", "Load GPS Field (dev/testing)"),
        ],
        "Autopilot": [
            ("P", "Toggle Autopilot"),
            ("V", "Show / Hide Autopilot Path"),
            ("U", "Teleport Vehicle Back to Start"),
            ("T", "Show / Hide Autopilot Trace"),
            ("F1", "Toggle Plow Furrows Visual"),
            ("F2", "Toggle Sowing Trail Visual"),
            ("F3", "Toggle Spraying Trail Visual"),
        ],
        "Time": [
            ("1", "Normal Simulation Time (1×)"),
            ("2", "Fast Simulation Time (2×)"),
            ("3", "Very Fast Simulation Time (5×)"),
        ],
        "Tuning": [
            ("= / +", "Increase AP Speed or Zoom In"),
            ("- / _", "Decrease AP Speed or Zoom Out"),
        ],
    }

    running = True
    # ---------------- validation helpers ----------------
    def is_valid_decimal(s):
        return bool(re.fullmatch(r"\d{0,6}(\.\d{0,2})?", s))

    def validate():
        nonlocal err_w, err_h, err_area
        err_w = err_h = err_area = ""

        # width
        if input_w:
            if not is_valid_decimal(input_w):
                err_w = "Max 2 decimals"
            else:
                try:
                    if float(input_w) <= 0:
                        err_w = "Width must be > 0"
                except ValueError:
                    err_w = "Invalid number"

        # length
        if input_h:
            if not is_valid_decimal(input_h):
                err_h = "Max 2 decimals"
            else:
                try:
                    if float(input_h) <= 0:
                        err_h = "Length must be > 0"
                except ValueError:
                    err_h = "Invalid number"

        # Area > 20 ha
        try:
            width_val = float(input_w)
            height_val = float(input_h)
            if width_val * height_val > 200000:
                err_area = "Field size exceeds 20 ha"

            # JD 8R 370 on obstacle fields needs >= 80m on both sides
            selected_spec = vehicle_specs[selected_vehicle] if vehicle_specs else None
            selected_map_info = field_maps[selected_map] if field_maps else None
            restricted_keys = {"jd_8r_370", "jd_9rx_640"}
            if (
                selected_spec
                and selected_spec.key in restricted_keys
                and selected_map_info
                and selected_map_info.get("obstacles")
            ):
                if width_val < 80 or height_val < 80:
                    err_area = "Only 80×80m+ fields selectable for this tractor on obstacle map"
        except:
            pass

        return not (err_w or err_h or err_area)

    # ---------------- draw base ----------------
    def draw_base():
        nonlocal cursor_visible, cursor_timer

        dt_ms = clock.get_time()
        cursor_timer += dt_ms
        if cursor_timer >= cursor_blink_ms:
            cursor_visible = not cursor_visible
            cursor_timer = 0

        draw_gradient_background(screen)
        pygame.draw.rect(screen, COL_BORDER, pygame.Rect(0, 0, screen_w, screen_h), 10)

        brand_text = brand_font.render("John Deere Simulation", True, (240, 220, 0))
        screen.blit(brand_text, ((screen_w - brand_text.get_width()) // 2, 44))

        title = font.render("Enter Field Dimensions (m)", True, (255, 255, 255))
        screen.blit(title,
                    (screen_w//2 - title.get_width()//2,
                     44 + brand_text.get_height() + 18))

        # Panel with shadow
        shadow = pygame.Surface((panel_rect.width, panel_rect.height), pygame.SRCALPHA)
        pygame.draw.rect(shadow, COL_SHADOW, shadow.get_rect(), border_radius=18)
        screen.blit(shadow, (panel_rect.x + 5, panel_rect.y + 5))

        panel_surface = pygame.Surface(panel_rect.size, pygame.SRCALPHA)
        panel_surface.fill(COL_PANEL)
        screen.blit(panel_surface, panel_rect.topleft)
        pygame.draw.rect(screen, COL_PANEL_BORDER, panel_rect, 2, border_radius=16)

        # Labels
        label_gap = 8
        def draw_label(text, target_rect):
            label_y = target_rect.y - small.get_height() - label_gap
            screen.blit(small.render(text, True, COL_TEXT), (target_rect.x + 2, label_y))

        draw_label("Vehicle Type", dropdown_rect)
        draw_label("Width", rect_w)
        draw_label("Length", rect_h)
        draw_label("Implement", implement_rect)
        draw_label("Field Map", map_rect)
        draw_label("Season", season_rect)

        # ---------------- input boxes ----------------
        def draw_input_box(rect, text, active, err_msg):
            fill = (232, 242, 232, 255) if active else (245, 248, 245, 255)
            box = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.rect(box, fill, box.get_rect(), border_radius=8)
            screen.blit(box, rect.topleft)

            pygame.draw.rect(screen, COL_ACTIVE if active else COL_INACTIVE,
                             rect, 2, border_radius=8)

            ts = None
            if text:
                ts = font.render(text, True, (38, 86, 42))
                screen.blit(ts, (rect.x+16, rect.y+10))
            elif not active:
                ph = "e.g., 80.0" if rect == rect_w else "e.g., 100.0"
                ps = small.render(ph, True, (150, 160, 150))
                screen.blit(ps, (rect.x+16, rect.y+14))

            # cursor
            if active and cursor_visible:
                if ts: cx = rect.x + 16 + ts.get_width() + 2
                else: cx = rect.x + 16
                pygame.draw.line(screen, (0,0,0), (cx, rect.y+10), (cx, rect.y+42), 2)

            if err_msg:
                es = small.render(err_msg, True, COL_ERR)
                screen.blit(es, (rect.x, rect.bottom+8))

        draw_input_box(rect_w, input_w, active_w, err_w)
        draw_input_box(rect_h, input_h, active_h, err_h)

        # Hover & dropdowns
        mx, my = pygame.mouse.get_pos()
        dropdown_hover = dropdown_rect.collidepoint((mx,my))
        map_hover = map_rect.collidepoint((mx,my))
        season_hover = season_rect.collidepoint((mx,my))
        implement_hover_local = implement_rect.collidepoint((mx,my))

        # ---------------- vehicle dropdown (collapsed) ----------------
        selected_spec = vehicle_specs[selected_vehicle]
        
        # Update tooltip
        nonlocal tooltip_visible, tooltip_text, tooltip_pos, tooltip_timer
        if dropdown_hover and not dropdown_open and selected_spec:
            tooltip_timer += dt_ms
            if tooltip_timer >= TOOLTIP_DELAY:
                tooltip_visible = True
                lines = []
                if selected_spec.description:
                    lines.append(selected_spec.description)
                    lines.append("")
                lines.extend([
                    f"Power: {selected_spec.horsepower} HP",
                    f"Working Width: {selected_spec.working_width}m",
                    f"Turn Radius: {selected_spec.min_turn_radius:.1f}m"
                ])
                tooltip_text = "\n".join(lines)
                tooltip_pos = (mx + 15, my - 10)
        else:
            tooltip_timer = 0
            tooltip_visible = False
        bgc = (250,255,250) if dropdown_hover else (245,248,245)
        pygame.draw.rect(screen, bgc, dropdown_rect, border_radius=8)
        pygame.draw.rect(screen,
                         COL_ACTIVE if dropdown_open else
                         (COL_ACCENT if dropdown_hover else COL_INACTIVE),
                         dropdown_rect, 2, border_radius=8)

        if selected_spec:
            ts = medium.render(selected_spec.name, True, (38,86,42))
            screen.blit(ts, (dropdown_rect.x+16,
                             dropdown_rect.y + (dropdown_rect.height - ts.get_height())//2))

        # Arrow
        ay = dropdown_rect.y + dropdown_rect.height//2
        pygame.draw.polygon(screen, COL_TEXT,
            [(dropdown_rect.right-24, ay+8),
             (dropdown_rect.right-36, ay-6),
             (dropdown_rect.right-12, ay-6)]
        )

        # ---------------- implement dropdown (collapsed) ----------------
        impl_key, impl_label = implements[selected_implement]
        bgc = (250,255,250) if implement_hover_local else (245,248,245)
        pygame.draw.rect(screen, bgc, implement_rect, border_radius=8)
        pygame.draw.rect(
            screen,
            COL_ACTIVE if implement_dropdown_open else
            (COL_ACCENT if implement_hover_local else COL_INACTIVE),
            implement_rect, 2, border_radius=8
        )

        if impl_label:
            ts = medium.render(impl_label, True, (38,86,42))
            screen.blit(
                ts,
                (implement_rect.x+16,
                 implement_rect.y + (implement_rect.height - ts.get_height())//2)
            )

        ay = implement_rect.y + implement_rect.height//2
        pygame.draw.polygon(
            screen, COL_TEXT,
            [
                (implement_rect.right-24, ay+8),
                (implement_rect.right-36, ay-6),
                (implement_rect.right-12, ay-6),
            ]
        )

        # ---------------- map dropdown (collapsed) ----------------
        smap = field_maps[selected_map]
        bgc = (250,255,250) if map_hover else (245,248,245)
        pygame.draw.rect(screen, bgc, map_rect, border_radius=8)
        pygame.draw.rect(screen,
                         COL_ACTIVE if map_dropdown_open else
                         (COL_ACCENT if map_hover else COL_INACTIVE),
                         map_rect, 2, border_radius=8)

        ts = medium.render(smap["name"], True, (38,86,42))
        screen.blit(ts, (map_rect.x+16, map_rect.y + (map_rect.height-ts.get_height())//2))

        ay = map_rect.y + map_rect.height//2
        pygame.draw.polygon(screen, COL_TEXT,
            [(map_rect.right-24, ay+8),
             (map_rect.right-36, ay-6),
             (map_rect.right-12, ay-6)]
        )

        # ---------------- season dropdown (collapsed) ----------------
        bgc = (250,255,250) if season_hover else (245,248,245)
        pygame.draw.rect(screen, bgc, season_rect, border_radius=8)
        pygame.draw.rect(screen,
                         COL_ACTIVE if season_dropdown_open else
                         (COL_ACCENT if season_hover else COL_INACTIVE),
                         season_rect, 2, border_radius=8)

        ts = medium.render(seasons[selected_season], True, (38,86,42))
        screen.blit(ts, (season_rect.x+16,
                         season_rect.y + (season_rect.height-ts.get_height())//2))

        ay = season_rect.y + season_rect.height//2
        pygame.draw.polygon(screen, COL_TEXT,
            [(season_rect.right-24, ay+8),
             (season_rect.right-36, ay-6),
             (season_rect.right-12, ay-6)]
        )

        # Area error
        if err_area:
            ea = small.render(err_area, True, COL_ERR)
            screen.blit(ea, (panel_rect.centerx - ea.get_width()//2, button_rect.y-32))

        # ---------------- Enter button ----------------
        hovered = button_rect.collidepoint((mx,my))
        base_green = (40,90,45)
        hover_green = (60,140,70)

        btn_color = hover_green if hovered else base_green
        pygame.draw.rect(screen, btn_color, button_rect, border_radius=24)
        pygame.draw.rect(screen, COL_ACCENT, button_rect, 3, border_radius=24)

        btn_text = small.render("Enter", True, (255,255,210))
        screen.blit(btn_text,
            (button_rect.centerx - btn_text.get_width()//2,
             button_rect.centery - btn_text.get_height()//2))

        # footer
        hint = tiny.render(
            "Set size, pick vehicle, choose map • Enter = start • ESC = quit • ? = help",
            True, (240,240,240)
        )
        screen.blit(hint, (screen_w//2 - hint.get_width()//2, panel_rect.bottom+15))

        # ---------------- help button ----------------
        hovered_help = help_button_rect.collidepoint((mx,my))
        fillc = hover_green if hovered_help else base_green

        pygame.draw.circle(screen, fillc, help_button_rect.center, help_button_rect.width//2)
        pygame.draw.circle(screen, COL_ACCENT, help_button_rect.center,
                           help_button_rect.width//2, 3)

        qmark = small.render("?", True, (255,255,255))
        screen.blit(qmark,
            (help_button_rect.centerx - qmark.get_width()//2,
             help_button_rect.centery - qmark.get_height()//2))
        
        # Draw tooltip
        if tooltip_visible and tooltip_text:
            all_lines = []
            for line in tooltip_text.split('\n'):
                if line.strip():
                    all_lines.extend(wrap_text(small, line, 280))
                else:
                    all_lines.append("")
            
            line_height = small.get_height() + 2
            tooltip_width = min(300, max(small.size(line)[0] if line else 0 for line in all_lines)) + 16
            tooltip_height = len(all_lines) * line_height + 12
            
            tx, ty = tooltip_pos
            if tx + tooltip_width > screen_w: tx = screen_w - tooltip_width - 5
            if ty + tooltip_height > screen_h: ty = screen_h - tooltip_height - 5
            if tx < 5: tx = 5
            if ty < 5: ty = 5
            
            tooltip_rect = pygame.Rect(tx, ty, tooltip_width, tooltip_height)
            
            # Shadow
            shadow_surf = pygame.Surface((tooltip_width, tooltip_height), pygame.SRCALPHA)
            pygame.draw.rect(shadow_surf, (0, 0, 0, 100), shadow_surf.get_rect(), border_radius=8)
            screen.blit(shadow_surf, (tx + 2, ty + 2))
            
            # Background
            pygame.draw.rect(screen, (255, 255, 240), tooltip_rect, border_radius=8)
            pygame.draw.rect(screen, (200, 200, 150), tooltip_rect, 2, border_radius=8)
            
            # Text
            text_y = ty + 6
            for line in all_lines:
                if line:
                    text_surf = small.render(line, True, (60, 60, 60))
                    screen.blit(text_surf, (tx + 8, text_y))
                text_y += line_height
    # ---------------- draw overlays (dropdowns + help) ----------------
    def draw_overlays():
        nonlocal option_rects, season_option_rects, map_option_rects, help_tab_rects
        nonlocal dropdown_open, season_dropdown_open, map_dropdown_open
        nonlocal help_scroll_offset

        # --- NEW: implement_option_rects ---
        nonlocal implement_option_rects
        option_rects = []
        season_option_rects = []
        map_option_rects = []
        implement_option_rects = []
        help_tab_rects = []

        mouse_pos = pygame.mouse.get_pos()

        # Dim screen when any dropdown is open
        if dropdown_open or season_dropdown_open or map_dropdown_open or implement_dropdown_open:
            overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 60))
            screen.blit(overlay, (0, 0))

        # ---------------- VEHICLE DROPDOWN ----------------
        if dropdown_open:
            items = vehicle_specs
            panel_top = dropdown_rect.bottom + 6
            panel_h = option_height * len(items)

            if panel_top + panel_h > screen_h - 16:
                panel_top = max(16, dropdown_rect.top - panel_h - 6)

            options_panel_rect = pygame.Rect(
                dropdown_rect.x, panel_top,
                dropdown_rect.width, panel_h
            )

            pygame.draw.rect(screen, (245,248,245), options_panel_rect, border_radius=10)
            pygame.draw.rect(screen, (200,220,200), options_panel_rect, 2, border_radius=10)

            for idx, spec in enumerate(items):
                item_rect = pygame.Rect(
                    options_panel_rect.x,
                    options_panel_rect.y + idx * option_height,
                    options_panel_rect.width,
                    option_height
                )
                option_rects.append((item_rect, idx))

                is_selected = (idx == selected_vehicle)
                is_hovered = item_rect.collidepoint(mouse_pos)

                if is_selected:
                    bg = (218,235,218)
                elif is_hovered:
                    bg = (210,238,210)
                else:
                    bg = (235,245,235)

                pygame.draw.rect(screen, bg, item_rect)
                pygame.draw.rect(screen, (200,220,200), item_rect, 1)

                label = small.render(spec.name, True,
                    (32,70,36) if is_selected else (40,90,45)
                )
                screen.blit(label,
                    (item_rect.x+12,
                     item_rect.y + (option_height - label.get_height())//2)
                )

        # ---------------- SEASON DROPDOWN ----------------
        elif season_dropdown_open:
            items = seasons
            panel_top = season_rect.bottom + 6
            panel_h = season_option_height * len(items)

            if panel_top + panel_h > screen_h - 16:
                panel_top = max(16, season_rect.top - panel_h - 6)

            options_panel_rect = pygame.Rect(
                season_rect.x, panel_top,
                season_rect.width, panel_h
            )

            pygame.draw.rect(screen, (245,248,245), options_panel_rect, border_radius=10)
            pygame.draw.rect(screen, (200,220,200), options_panel_rect, 2, border_radius=10)

            for idx, label_txt in enumerate(items):
                item_rect = pygame.Rect(
                    options_panel_rect.x,
                    options_panel_rect.y + idx * season_option_height,
                    options_panel_rect.width,
                    season_option_height
                )

                season_option_rects.append((item_rect, idx))
                is_selected = (idx == selected_season)
                is_hovered = item_rect.collidepoint(mouse_pos)

                if is_selected:
                    bg = (218,235,218)
                elif is_hovered:
                    bg = (210,238,210)
                else:
                    bg = (235,245,235)

                pygame.draw.rect(screen, bg, item_rect)
                pygame.draw.rect(screen, (200,220,200), item_rect, 1)

                label = small.render(label_txt, True,
                    (32,70,36) if is_selected else (40,90,45)
                )
                screen.blit(label,
                    (item_rect.x+12,
                     item_rect.y + (season_option_height - label.get_height())//2)
                )

        # ---------------- MAP DROPDOWN ----------------
        elif map_dropdown_open:
            panel_top = map_rect.bottom + 6

             # compute dynamic height (use first item as reference)
            first_map = field_maps[0]
            first_desc_lines = wrap_text(tiny, first_map["description"], map_rect.width - 24)
            map_option_height = 50 + len(first_desc_lines) * (tiny.get_height() + 4)
            
            panel_h = map_option_height * len(field_maps)

            if panel_top + panel_h > screen_h - 16:
                panel_top = max(16, map_rect.top - panel_h - 6)

            options_rect = pygame.Rect(map_rect.x, panel_top, map_rect.width, panel_h)

            pygame.draw.rect(screen, (235,245,235), options_rect, border_radius=12)
            pygame.draw.rect(screen, (60,120,60), options_rect, 3, border_radius=12)

            for idx, fmap in enumerate(field_maps):
                item_rect = pygame.Rect(
                    options_rect.x,
                    options_rect.y + idx * map_option_height,
                    options_rect.width,
                    map_option_height
                )

                map_option_rects.append((item_rect, idx))
                is_selected = idx == selected_map
                is_hovered = item_rect.collidepoint(mouse_pos)

                if is_selected:
                    bg = (218,235,218)
                elif is_hovered:
                    bg = (210,238,210)
                else:
                    bg = (235,245,235)

                pygame.draw.rect(screen, bg, item_rect)
                pygame.draw.rect(screen, (200,220,200), item_rect, 1)

                # ---- TOP-ANCHORED CLEAN LAYOUT ----
                # Name
                name_y = item_rect.y + 6
                name = small.render(fmap["name"], True, (38,86,42))
                screen.blit(name, (item_rect.x + 12, name_y))

                # Description (two lines max)
                desc_lines = wrap_text(tiny, fmap["description"], item_rect.width - 24)

                desc_y_start = item_rect.y + 32   # <-- FIX 2: vertical spacing

                for i, line in enumerate(desc_lines[:2]):
                    ds = tiny.render(line, True, (80, 100, 80))
                    screen.blit(ds, (item_rect.x + 12, desc_y_start + i * (ds.get_height() + 4)))


        # ---------------- IMPLEMENT DROPDOWN ----------------
        elif implement_dropdown_open:
            items = implements
            panel_top = implement_rect.bottom + 6
            panel_h = option_height * len(items)

            if panel_top + panel_h > screen_h - 16:
                panel_top = max(16, implement_rect.top - panel_h - 6)

            options_panel_rect = pygame.Rect(
                implement_rect.x, panel_top,
                implement_rect.width, panel_h
            )

            pygame.draw.rect(screen, (245,248,245), options_panel_rect, border_radius=10)
            pygame.draw.rect(screen, (200,220,200), options_panel_rect, 2, border_radius=10)

            for idx, (_, label_txt) in enumerate(items):
                item_rect = pygame.Rect(
                    options_panel_rect.x,
                    options_panel_rect.y + idx * option_height,
                    options_panel_rect.width,
                    option_height
                )
                implement_option_rects.append((item_rect, idx))

                is_selected = (idx == selected_implement)
                is_hovered = item_rect.collidepoint(mouse_pos)

                if is_selected:
                    bg = (218,235,218)
                elif is_hovered:
                    bg = (210,238,210)
                else:
                    bg = (235,245,235)

                pygame.draw.rect(screen, bg, item_rect)
                pygame.draw.rect(screen, (200,220,200), item_rect, 1)

                label_surf = small.render(label_txt, True,
                    (32,70,36) if is_selected else (40,90,45)
                )
                screen.blit(
                    label_surf,
                    (item_rect.x+12,
                     item_rect.y + (option_height - label_surf.get_height())//2)
                )

        # ---------------- HELP PANEL ----------------
        if help_open:
            dropdown_open = False
            map_dropdown_open = False
            season_dropdown_open = False

            # panel base
            p = pygame.Surface(help_panel_rect.size, pygame.SRCALPHA)
            p.fill((30,100,35,230))
            screen.blit(p, help_panel_rect.topleft)
            pygame.draw.rect(screen, COL_ACCENT, help_panel_rect, 3, border_radius=12)

            # tabs
            tabs_y = help_panel_rect.y + 12
            x = help_panel_rect.x + 24

            for i, tname in enumerate(help_tabs):
                active = (i == help_tab)
                col = COL_TEXT if active else COL_TEXT_DIM
                label = small.render(tname, True, col)

                rect = pygame.Rect(x, tabs_y, label.get_width()+10, label.get_height())
                help_tab_rects.append(rect)
                screen.blit(label, (rect.x, rect.y))

                if active:
                    pygame.draw.line(screen, COL_TEXT,
                                     (rect.x, rect.bottom+2),
                                     (rect.right-8, rect.bottom+2), 2)

                x += rect.width + 22

            # divider
            pygame.draw.line(screen, COL_TEXT,
                             (help_panel_rect.x+16, tabs_y+36),
                             (help_panel_rect.right-16, tabs_y+36), 2)

            # search box
            search_y = tabs_y + 46
            search_rect = pygame.Rect(help_panel_rect.x+24, search_y,
                                      help_panel_rect.width-48, 24)

            search_bg = (245,248,245) if help_search_active else (235,245,235)
            pygame.draw.rect(screen, search_bg, search_rect, border_radius=4)
            pygame.draw.rect(screen,
                             COL_ACCENT if help_search_active else COL_TEXT_DIM,
                             search_rect, 1, border_radius=4)

            # search text
            if help_search:
                t = tiny.render(help_search, True, (38,86,42))
                screen.blit(t, (search_rect.x+6, search_rect.y+3))
                if help_search_active and cursor_visible:
                    cx = search_rect.x+6+t.get_width()+2
                    pygame.draw.line(screen, (0,0,0),
                                     (cx, search_rect.y+2),
                                     (cx, search_rect.bottom-2), 1)
            else:
                placeholder = tiny.render("Search commands...", True, (150,160,150))
                screen.blit(placeholder, (search_rect.x+6, search_rect.y+3))
                if help_search_active and cursor_visible:
                    cx = search_rect.x+6
                    pygame.draw.line(screen, (0,0,0),
                                     (cx, search_rect.y+2),
                                     (cx, search_rect.bottom-2), 1)

            # ----- content selection -----
            if help_search:
                content = []
                s = help_search.lower()
                for tabname, items in HELP_CONTENT.items():
                    for k,v in items:
                        if s in k.lower() or s in v.lower():
                            content.append((k,v))
            else:
                content = HELP_CONTENT[help_tabs[help_tab]]

            # ----- scrollable region -----
            content_clip_rect = pygame.Rect(
                help_panel_rect.x + 20,
                search_y + 36,
                help_panel_rect.width - 40,
                help_panel_rect.height - (search_y - help_panel_rect.y) - 60
            )

            # ---- compute scroll bounds ----
            content_height = 0
            line_gap = 8
            text_font = tiny
            key_column_width = 140
            padding_x = 40
            max_text_width = help_panel_rect.width - key_column_width - padding_x*2

            for (k, v) in content:
                kh = text_font.size(k)[1]
                wrapped = wrap_text(text_font, v, max_text_width)
                vh = sum(text_font.size("— "+line)[1] + 2 for line in wrapped)
                content_height += max(kh, vh) + line_gap

            visible_height = content_clip_rect.height
            max_scroll = max(0, content_height - visible_height)

            # clamp scroll
            help_scroll_offset = max(0, min(help_scroll_offset, max_scroll))

            # ---- draw clipped content ----
            screen.set_clip(content_clip_rect)

            y = content_clip_rect.y - help_scroll_offset

            for (k, v) in content:
                key_surface = text_font.render(k, True, COL_ACCENT)
                screen.blit(key_surface, (help_panel_rect.x + padding_x, y))

                wrapped = wrap_text(text_font, v, max_text_width)
                ly = y
                for line in wrapped:
                    val_surface = text_font.render("— " + line, True, COL_TEXT_DIM)
                    screen.blit(
                        val_surface,
                        (help_panel_rect.x + padding_x + key_column_width, ly)
                    )
                    ly += val_surface.get_height() + 2

                y = max(ly, y + key_surface.get_height()) + line_gap

            screen.set_clip(None)
    # ---------------- Main Loop ----------------
    while running:
        dt = clock.tick(60) / 1000.0

        # Smooth dropdown animations (kept for future use)
        target_dropdown = 1.0 if dropdown_open else 0.0
        target_season = 1.0 if season_dropdown_open else 0.0
        target_map = 1.0 if map_dropdown_open else 0.0
        target_implement = 1.0 if implement_dropdown_open else 0.0
        anim_speed = 8.0

        dropdown_animation += (target_dropdown - dropdown_animation) * anim_speed * dt
        season_animation += (target_season - season_animation) * anim_speed * dt
        map_animation += (target_map - map_animation) * anim_speed * dt
        implement_animation += (target_implement - implement_animation) * anim_speed * dt

        # -------------- EVENT HANDLING --------------
        for e in pygame.event.get():

            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit(0)

            # -------------------------------------------------
            # KEY PRESSES
            # -------------------------------------------------
            elif e.type == pygame.KEYDOWN:

                # ESC closes dropdowns/help or quits
                if e.key == pygame.K_ESCAPE:
                    if dropdown_open:
                        dropdown_open = False
                    elif season_dropdown_open:
                        season_dropdown_open = False
                    elif map_dropdown_open:
                        map_dropdown_open = False
                    elif implement_dropdown_open:
                        implement_dropdown_open = False
                    elif help_open:
                        help_open = False
                    else:
                        pygame.quit()
                        sys.exit(0)

                # ENTER confirms form
                elif e.key == pygame.K_RETURN:
                    if dropdown_open:
                        dropdown_open = False
                    elif season_dropdown_open:
                        season_dropdown_open = False
                    elif map_dropdown_open:
                        map_dropdown_open = False
                    elif implement_dropdown_open:
                        implement_dropdown_open = False
                    elif not help_open and validate():
                        running = False

                # HELP TAB SWITCHING
                elif help_open and e.key in (pygame.K_LEFT, pygame.K_RIGHT):
                    help_search_active = False
                    help_scroll_offset = 0
                    if e.key == pygame.K_RIGHT:
                        help_tab = (help_tab + 1) % len(help_tabs)
                    else:
                        help_tab = (help_tab - 1) % len(help_tabs)

                # VEHICLE NAVIGATION (UP / DOWN)
                elif e.key == pygame.K_DOWN:
                    if vehicle_specs and not (active_w or active_h or map_dropdown_open or help_open):
                        selected_vehicle = (selected_vehicle + 1) % len(vehicle_specs)
                        dropdown_open = False

                elif e.key == pygame.K_UP:
                    if vehicle_specs and not (active_w or active_h or map_dropdown_open or help_open):
                        selected_vehicle = (selected_vehicle - 1) % len(vehicle_specs)
                        dropdown_open = False

                # MAP NAVIGATION (LEFT / RIGHT)
                elif e.key == pygame.K_RIGHT:
                    if not help_open and field_maps and not (active_w or active_h or dropdown_open):
                        selected_map = (selected_map + 1) % len(field_maps)
                        map_dropdown_open = False

                elif e.key == pygame.K_LEFT:
                    if not help_open and field_maps and not (active_w or active_h or dropdown_open):
                        selected_map = (selected_map - 1) % len(field_maps)
                        map_dropdown_open = False

                # BACKSPACE for text fields
                elif e.key == pygame.K_BACKSPACE:
                    if help_open and help_search_active and help_search:
                        help_search = help_search[:-1]
                    elif not help_open and active_w and input_w:
                        input_w = input_w[:-1]
                    elif not help_open and active_h and input_h:
                        input_h = input_h[:-1]

                # Typing in HELP SEARCH
                elif help_open and help_search_active:
                    ch = e.unicode
                    if ch and ch.isprintable() and len(help_search) < 30:
                        help_search += ch

                # Typing in INPUT BOXES
                elif not help_open:
                    ch = e.unicode
                    if ch and (ch.isdigit() or ch == '.'):
                        if active_w:
                            test = input_w + ch
                            if is_valid_decimal(test):
                                input_w = test
                        elif active_h:
                            test = input_h + ch
                            if is_valid_decimal(test):
                                input_h = test

            # -------------------------------------------------
            # MOUSE WHEEL — scroll help panel
            # -------------------------------------------------
            elif e.type == pygame.MOUSEMOTION:
                tooltip_timer = 0
                tooltip_visible = False
                
            elif e.type == pygame.MOUSEWHEEL:
                if help_open:
                    help_scroll_offset -= e.y * 20   # simple scroll (bounds applied inside draw_overlays)

            # -------------------------------------------------
            # MOUSE CLICKS
            # -------------------------------------------------
            elif e.type == pygame.MOUSEBUTTONDOWN:
                mx, my = e.pos

                # Toggle help button
                if help_button_rect.collidepoint((mx, my)):
                    help_open = not help_open
                    help_search_active = False
                    dropdown_open = False
                    map_dropdown_open = False
                    season_dropdown_open = False
                    active_w = active_h = False
                    continue

                if help_open:
                    # Search box click
                    search_rect = pygame.Rect(
                        help_panel_rect.x + 24,
                        help_panel_rect.y + 58,
                        help_panel_rect.width - 48,
                        24
                    )
                    if search_rect.collidepoint((mx, my)):
                        help_search_active = True
                        continue

                    # Tab clicks
                    clicked_tab = False
                    for i, r in enumerate(help_tab_rects):
                        if r.collidepoint((mx, my)):
                            help_tab = i
                            help_scroll_offset = 0
                            help_search_active = False
                            clicked_tab = True
                            break
                    if clicked_tab:
                        continue

                    # Clicking outside = close help
                    if not help_panel_rect.collidepoint((mx, my)):
                        help_open = False
                        help_search_active = False
                        continue

                    # Click inside help → ignore
                    continue

                # VEHICLE DROPDOWN OPTIONS
                if dropdown_open:
                    clicked = False
                    for rect_opt, idx in option_rects:
                        if rect_opt.collidepoint(e.pos):
                            selected_vehicle = idx
                            clicked = True
                            break
                    dropdown_open = False
                    active_w = active_h = False
                    if clicked:
                        continue

                # MAP DROPDOWN OPTIONS
                if map_dropdown_open:
                    clicked = False
                    for rect_map, idx in map_option_rects:
                        if rect_map.collidepoint(e.pos):
                            selected_map = idx
                            clicked = True
                            break
                    map_dropdown_open = False
                    active_w = active_h = False
                    if clicked:
                        continue

                # SEASON DROPDOWN OPTIONS
                if season_dropdown_open:
                    clicked = False
                    for rect_season, idx in season_option_rects:
                        if rect_season.collidepoint(e.pos):
                            selected_season = idx
                            clicked = True
                            break
                    season_dropdown_open = False
                    active_w = active_h = False
                    if clicked:
                        continue

                # IMPLEMENT DROPDOWN OPTIONS
                if implement_dropdown_open:
                    clicked = False
                    for rect_impl, idx in implement_option_rects:
                        if rect_impl.collidepoint(e.pos):
                            selected_implement = idx
                            clicked = True
                            break
                    implement_dropdown_open = False
                    active_w = active_h = False
                    if clicked:
                        continue

                # INPUT FIELDS
                if rect_w.collidepoint(e.pos):
                    active_w, active_h = True, False
                    dropdown_open = False
                    season_dropdown_open = False
                    map_dropdown_open = False
                    implement_dropdown_open = False

                elif rect_h.collidepoint(e.pos):
                    active_w, active_h = False, True
                    dropdown_open = False
                    season_dropdown_open = False
                    map_dropdown_open = False
                    implement_dropdown_open = False

                # DROPDOWN TOGGLES
                elif dropdown_rect.collidepoint(e.pos):
                    dropdown_open = not dropdown_open
                    implement_dropdown_open = False
                    active_w = active_h = False
                    map_dropdown_open = False
                    season_dropdown_open = False

                elif season_rect.collidepoint(e.pos):
                    season_dropdown_open = not season_dropdown_open
                    dropdown_open = False
                    map_dropdown_open = False
                    implement_dropdown_open = False
                    active_w = active_h = False

                elif map_rect.collidepoint(e.pos):
                    map_dropdown_open = not map_dropdown_open
                    dropdown_open = False
                    season_dropdown_open = False
                    implement_dropdown_open = False
                    active_w = active_h = False

                elif implement_rect.collidepoint(e.pos):
                    implement_dropdown_open = not implement_dropdown_open
                    dropdown_open = False
                    season_dropdown_open = False
                    map_dropdown_open = False
                    active_w = active_h = False

                # ENTER BUTTON
                elif button_rect.collidepoint(e.pos):
                    if validate():
                        running = False
                        dropdown_open = season_dropdown_open = map_dropdown_open = implement_dropdown_open = False

                else:
                    active_w = active_h = False
                    dropdown_open = season_dropdown_open = map_dropdown_open = implement_dropdown_open = False
                    tooltip_visible = False
                    tooltip_timer = 0

        # ------------ UPDATE + DRAW ------------
        validate()
        draw_base()
        draw_overlays()
        pygame.display.flip()

    # --------------- RETURN FINAL SELECTIONS ---------------
    selected_key = vehicle_specs[selected_vehicle].key if vehicle_specs else None
    heavy_impl_keys = {"jd_8r_370", "jd_9rx_640"}

    raw_w = (input_w or "").strip()
    raw_h = (input_h or "").strip()
    use_large_default = bool(
        selected_key in heavy_impl_keys and not raw_w and not raw_h
    )
    default_dim = 80.0 if use_large_default else 40.0

    try:
        field_w = float(raw_w) if raw_w else default_dim
    except:
        field_w = default_dim

    try:
        field_h = float(raw_h) if raw_h else default_dim
    except:
        field_h = default_dim

    pygame.display.quit()

    selected_map_info = field_maps[selected_map]
    # Respect the "No Implement" selection by returning None instead of forcing a default
    implement_key = implements[selected_implement][0]

    return (
        field_w,
        field_h,
        selected_key,
        selected_map_info["key"],
        selected_map_info["name"],
        selected_map_info["obstacles"],
        seasons[selected_season],
        implement_key,
    )
