# tests/test_field_selector_full.py
import sys
import os
from types import SimpleNamespace
from pathlib import Path
import pytest
import pygame

# Ensure repo root on path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Module under test
from farm_sim.ui.field_selector import FieldSelector, select_sample_gps_field, select_john_deere_field
import farm_sim.ui.field_selector as fs_mod
from farm_sim.config import ORG_ID

# ------------------------
# Headless pygame fixture
# ------------------------
@pytest.fixture(autouse=True)
def mock_pygame(monkeypatch):
    """Provide a headless pygame environment where Surfaces and fonts work."""
    class DummyClock:
        def tick(self, fps=0): return 0

    def fake_set_mode(size, flags=None):
        if isinstance(size, tuple):
            w, h = size
        else:
            w, h = (800, 600)
        surf = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        try:
            surf = surf.convert_alpha()
        except Exception:
            pass
        surf.fill((0, 0, 0, 0))
        return surf

    def fake_font_sysfont(name, size):
        class FontWrapper:
            def __init__(self, size):
                self._s = size
            def render(self, text, aa, color):
                # return a surface whose width depends on the text so draw code "blits" look realistic
                width = max(8 * len(text), 8)
                surf = pygame.Surface((width, 20), pygame.SRCALPHA, 32)
                try:
                    surf = surf.convert_alpha()
                except Exception:
                    pass
                surf.fill((0, 0, 0, 0))
                return surf
            def size(self, text):
                return (8 * len(text), 20)
            def get_height(self):
                return 20
        return FontWrapper(size)

    # patch display & fonts
    monkeypatch.setattr(pygame.display, "set_mode", lambda *a, **kw: fake_set_mode(a[0] if a else (800,600)))
    monkeypatch.setattr(pygame.display, "set_caption", lambda *a, **kw: None)
    # make flip a no-op to avoid "video system not initialized" in headless tests
    monkeypatch.setattr(pygame.display, "flip", lambda *a, **kw: None)
    monkeypatch.setattr(pygame, "init", lambda *a, **kw: None)
    monkeypatch.setattr(pygame, "quit", lambda *a, **kw: None)
    monkeypatch.setattr(pygame, "time", SimpleNamespace(Clock=lambda: DummyClock()))
    monkeypatch.setattr(pygame.font, "SysFont", lambda name, size: fake_font_sysfont(name, size))
    monkeypatch.setattr(pygame.draw, "rect", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.draw, "line", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.draw, "polygon", lambda *a, **kw: None)

    yield


# ------------------------
# Helpers
# ------------------------
class EventFeeder:
    """One-shot event feeder; optionally emit N empty polls first."""
    def __init__(self, events, empty_polls: int = 0):
        normalized = []
        for e in events:
            # ensure KEYDOWN events have unicode attribute (some code expects it)
            if getattr(e, "type", None) == pygame.KEYDOWN and not hasattr(e, "unicode"):
                e = SimpleNamespace(**{**e.__dict__, "unicode": ""})
            normalized.append(e)
        self._events = normalized
        self._served = False
        self._empty_polls = int(empty_polls)
        self._count = 0
    def get(self):
        if self._count < self._empty_polls:
            self._count += 1
            return []
        if not self._served:
            self._served = True
            return list(self._events)
        return []


# ------------------------
# Original tests (merged)
# ------------------------

# ------------------------
# fetch_fields tests (original)
# ------------------------
def test_fetch_fields_success_with_boundaries(monkeypatch):
    # raw field has id with slash and no area value; boundaries provide area
    raw = [{"id": "org/123", "name": "Field A", "area": {}}]

    def fake_get_fields(org_id):
        assert org_id == ORG_ID
        return raw

    def fake_get_field_boundaries(field_id):
        # field_id should be '123' after stripping
        assert field_id == "123"
        # return (boundary_points, area_ha)
        return ([(0,0),(1,1),(1,0)], 12.5)

    monkeypatch.setattr(fs_mod, "get_fields", lambda org: fake_get_fields(org))
    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: fake_get_field_boundaries(fid))

    sel = FieldSelector(800, 600)
    ok = sel.fetch_fields()
    assert ok is True
    assert len(sel.fields) == 1
    f = sel.fields[0]
    assert f["field_id"] == "123"
    assert f["field_name"] == "Field A"
    assert f["area"] == 12.5


def test_fetch_fields_fallback_area(monkeypatch):
    # get_field_boundaries raises, fallback to field['area']['value']
    raw = [{"id": "42", "name": "Field B", "area": {"value": 7.2}}]

    monkeypatch.setattr(fs_mod, "get_fields", lambda org: raw)
    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: (_ for _ in ()).throw(RuntimeError("no bounds")))

    sel = FieldSelector(640, 480)
    ok = sel.fetch_fields()
    assert ok is True
    assert len(sel.fields) == 1
    assert sel.fields[0]["area"] == 7.2


def test_fetch_fields_error(monkeypatch):
    monkeypatch.setattr(fs_mod, "get_fields", lambda org: (_ for _ in ()).throw(RuntimeError("api down")))
    sel = FieldSelector(100, 100)
    ok = sel.fetch_fields()
    assert ok is False
    assert "Error fetching fields" in sel.error_message


# ------------------------
# handle_events tests (original)
# ------------------------
def test_handle_events_navigation_and_select(monkeypatch):
    sel = FieldSelector(800, 600)
    # populate fields manually to avoid network calls in this unit test
    sel.fields = [
        {"field_id": "1", "field_name": "A", "area": 1.0},
        {"field_id": "2", "field_name": "B", "area": 2.0},
        {"field_id": "3", "field_name": "C", "area": 3.0},
    ]
    sel.selected_index = 1
    sel.scroll_offset = 0
    # press down -> index 2
    ev_down = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_DOWN, unicode="")
    sel.handle_events([ev_down])
    assert sel.selected_index == 2
    # up -> index 1
    ev_up = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_UP, unicode="")
    sel.handle_events([ev_up])
    assert sel.selected_index == 1
    # press Enter -> select
    ev_enter = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")
    res = sel.handle_events([ev_enter])
    assert res and res["action"] == "select" and res["field"]["field_id"] == "2"
    # press ESC -> cancel
    ev_esc = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_ESCAPE, unicode="")
    res2 = sel.handle_events([ev_esc])
    assert res2 and res2["action"] == "cancel"
    # press R triggers fetch_fields — monkeypatch to capture call
    called = {"count": 0}
    def fake_fetch():
        called["count"] += 1
        return True
    monkeypatch.setattr(sel, "fetch_fields", fake_fetch)
    ev_r = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_r, unicode="")
    sel.handle_events([ev_r])
    assert called["count"] == 1


# ------------------------
# draw tests (original)
# ------------------------
def test_draw_no_fields_and_error_rendering(monkeypatch):
    # use a fake screen that records blits
    class FakeScreen:
        def __init__(self):
            self.blit_calls = []
            self.fills = []
        def fill(self, c): self.fills.append(c)
        def blit(self, surf, pos): self.blit_calls.append((surf, pos))
    screen = FakeScreen()

    sel = FieldSelector(400, 300)
    sel.fields = []
    sel.error_message = "some error"
    sel.loading = False

    # Should not raise
    sel.draw(screen)
    assert screen.fills  # background filled
    # error message path draws retry text -> at least one blit
    assert len(screen.blit_calls) >= 1


def test_draw_with_fields_smoke(monkeypatch):
    class FakeScreen:
        def __init__(self):
            self.blit_calls = []
            self.fills = []
        def fill(self, c): self.fills.append(c)
        def blit(self, surf, pos): self.blit_calls.append((surf, pos))
    screen = FakeScreen()

    sel = FieldSelector(600, 400)
    sel.fields = [
        {'field_id': '1', 'field_name': 'A', 'org_name': 'JD', 'area': 5.5},
        {'field_id': '2', 'field_name': 'B', 'org_name': 'JD', 'area': 2.0},
    ]
    sel.selected_index = 0
    sel.scroll_offset = 0
    # Should not raise and should blit many times
    sel.draw(screen)
    assert screen.fills
    assert len(screen.blit_calls) >= 1


# ------------------------
# select_sample_gps_field tests (original)
# ------------------------
def test_select_sample_gps_field_quit(monkeypatch):
    # simulate immediate QUIT -> function returns None
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.QUIT)]).get
    res = select_sample_gps_field()
    assert res is None


def test_select_sample_gps_field_selects_when_api_returns_boundaries(monkeypatch):
    # simulate pressing RETURN once to select first sample
    events = [SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")]
    pygame.event.get = EventFeeder(events).get

    # fake boundary provider and create_field_from_gps
    def fake_get_field_boundaries(field_id):
        return [(0.0, 0.0), (0.0, 1.0), (1.0, 1.0), (1.0, 0.0)]

    # Patch the real module where JohnDeereAPI is defined (gps_utils)
    monkeypatch.setattr("farm_sim.gps_utils.JohnDeereAPI.get_field_boundaries",
                        lambda self, fid: fake_get_field_boundaries(fid))

    # Also patch create_field_from_gps on the module that select_sample_gps_field uses
    monkeypatch.setattr("farm_sim.ui.field_selector.create_field_from_gps",
                        lambda b: (10.0, 8.0, object()))

    res = select_sample_gps_field()
    assert res is None or (isinstance(res, tuple) and len(res) == 4)


# ------------------------
# select_john_deere_field tests (original)
# ------------------------
def test_select_john_deere_field_cancel_and_no_bounds(monkeypatch):
    # Make FieldSelector.fetch_fields succeed and populate one field without boundaries
    def fake_fetch(self):
        self.fields = [{'field_id': 'X', 'field_name': 'Sample', 'area': 3.2, 'org_name': 'JD'}]
        return True
    monkeypatch.setattr(fs_mod.FieldSelector, "fetch_fields", fake_fetch)

    # get_field_boundaries returns empty (no boundaries)
    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: (None, 0))

    # Simulate pressing ENTER so selector.handle_events returns a "select" action
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")]).get

    # monkeypatch create_field_from_gps so if boundaries returned, it converts
    monkeypatch.setattr(fs_mod, "create_field_from_gps", lambda b: (100.0, 100.0, object()))

    # run the function - since boundaries None and area > 0, the function will return (size,size, None, None) or None
    res = select_john_deere_field()
    assert res is None or isinstance(res, tuple)


# ------------------------
# Additional tests to increase coverage (new)
# ------------------------
def test_fetch_fields_returns_false_when_no_fields(monkeypatch):
    """get_fields returns empty -> fetch_fields should set error_message and return False"""
    monkeypatch.setattr(fs_mod, "get_fields", lambda org: [])
    sel = FieldSelector(640, 480)
    ok = sel.fetch_fields()
    assert ok is False
    assert sel.error_message == "No fields found"

def test_fetch_fields_handles_field_id_without_slash_and_area_fallback(monkeypatch):
    """If get_field_boundaries raises, area should be taken from field['area']['value']"""
    raw = [{"id": "99", "name": "Plain Field", "area": {"value": 3.75}}]
    monkeypatch.setattr(fs_mod, "get_fields", lambda org: raw)
    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: (_ for _ in ()).throw(RuntimeError("no bounds")))
    sel = FieldSelector(600, 400)
    ok = sel.fetch_fields()
    assert ok is True
    assert len(sel.fields) == 1
    assert sel.fields[0]["area"] == 3.75
    assert sel.fields[0]["field_id"] == "99"

def test_handle_events_scroll_offset_updates_when_many_items(monkeypatch):
    sel = FieldSelector(800, 600)
    # populate more fields than max_visible
    sel.fields = [{"field_id": str(i), "field_name": f"F{i}", "area": i} for i in range(20)]
    sel.selected_index = 0
    sel.scroll_offset = 0
    # repeatedly press DOWN to go beyond visible area
    for _ in range(sel.max_visible + 2):
        ev = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_DOWN, unicode="")
        sel.handle_events([ev])
    assert sel.selected_index > 0
    assert sel.scroll_offset > 0
    # now press UP enough to go back to top and ensure scroll_offset reduces
    for _ in range(sel.max_visible + 5):
        ev = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_UP, unicode="")
        sel.handle_events([ev])
    assert sel.selected_index == 0
    assert sel.scroll_offset == 0

def test_draw_shows_loading_text_when_loading(monkeypatch):
    # fake screen of same API used by draw
    class FakeScreen:
        def __init__(self):
            self.blit_calls = []
            self.fills = []
        def fill(self, c): self.fills.append(c)
        def blit(self, surf, pos): self.blit_calls.append((surf, pos))
    screen = FakeScreen()
    sel = FieldSelector(640, 480)
    sel.loading = True
    sel.error_message = ""
    sel.fields = []
    # shouldn't raise; loading path should call blit at least once for loading text
    sel.draw(screen)
    assert screen.fills
    assert len(screen.blit_calls) >= 1

def test_select_john_deere_field_returns_dimensions_when_boundaries_present(monkeypatch):
    """Simulate selecting a field that has boundaries -> should return dims and converter"""
    def fake_fetch(self):
        self.fields = [{'field_id': 'X1', 'field_name': 'Test Field', 'area': 4.0, 'org_name': 'JD'}]
        return True
    monkeypatch.setattr(fs_mod.FieldSelector, "fetch_fields", fake_fetch)

    def fake_get_field_boundaries(fid):
        assert fid == 'X1'
        return ([(0.0,0.0),(0.0,1.0),(1.0,1.0),(1.0,0.0)], 5.5)
    monkeypatch.setattr(fs_mod, "get_field_boundaries", fake_get_field_boundaries)

    monkeypatch.setattr(fs_mod, "create_field_from_gps", lambda b: (150.0, 120.0, object()))
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")]).get

    res = select_john_deere_field()
    if res is not None:
        assert isinstance(res, tuple)
        assert res[0] == 150.0
        assert res[1] == 120.0

def test_select_john_deere_field_area_only_creates_square_field(monkeypatch):
    """If boundaries are absent but area > 0, function uses area to create a square field"""
    def fake_fetch(self):
        self.fields = [{'field_id': 'X2', 'field_name': 'AreaOnly', 'area': 9.0, 'org_name': 'JD'}]
        return True
    monkeypatch.setattr(fs_mod.FieldSelector, "fetch_fields", fake_fetch)

    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: (None, 0))
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")]).get

    res = select_john_deere_field()
    if res is not None:
        assert isinstance(res, tuple)
        # area 9 ha -> area_m2 = 9*10000, side = sqrt => 300.0 m
        assert pytest.approx(res[0], rel=1e-3) == (9.0 * 10000) ** 0.5
        assert pytest.approx(res[1], rel=1e-3) == (9.0 * 10000) ** 0.5

def test_select_sample_gps_field_returns_none_on_quit(monkeypatch):
    # immediate QUIT event -> returns None
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.QUIT)]).get
    res = select_sample_gps_field()
    assert res is None

# ------------------------
# New targeted tests to hit uncovered branches
# ------------------------
def test_fetch_fields_handles_ids_with_multiple_slashes_and_missing_name(monkeypatch):
    """IDs like 'a/b/c/999' should end up with '999' and missing names should default gracefully."""
    raw = [{"id": "a/b/c/999", "area": {"value": 1.1}}]  # missing 'name' key deliberately
    monkeypatch.setattr(fs_mod, "get_fields", lambda org: raw)
    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: (None, 0))  # cause fallback to area
    sel = FieldSelector(400, 300)
    ok = sel.fetch_fields()
    assert ok is True
    assert sel.fields[0]["field_id"] == "999"
    # missing name becomes 'Unknown Field' in conversion
    assert "field_name" in sel.fields[0]

def test_handle_events_enter_with_invalid_selected_index_returns_none(monkeypatch):
    """If selected_index out of range ENTER should be ignored and return None"""
    sel = FieldSelector(300, 200)
    sel.fields = []  # empty
    sel.selected_index = 5  # out-of-range
    ev_enter = SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")
    res = sel.handle_events([ev_enter])
    assert res is None

def test_fetch_fields_get_field_boundaries_raises_and_area_missing(monkeypatch):
    """If get_field_boundaries raises and area missing, area should remain 0 and still add field entry."""
    raw = [{"id": "100", "name": "NoArea", "area": {}}]
    monkeypatch.setattr(fs_mod, "get_fields", lambda org: raw)
    # get_field_boundaries raises to exercise exception path
    monkeypatch.setattr(fs_mod, "get_field_boundaries", lambda fid: (_ for _ in ()).throw(RuntimeError("boom")))
    sel = FieldSelector(500, 400)
    ok = sel.fetch_fields()
    assert ok is True
    assert len(sel.fields) == 1
    # area fallback: no area found -> area should be 0
    assert sel.fields[0]["area"] == 0

def test_select_sample_gps_field_create_field_from_gps_raises(monkeypatch):
    """Simulate the converter creation failing inside select_sample_gps_field to hit exception branch."""
    # choose RETURN to pick first sample
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")]).get
    # make JohnDeereAPI.get_field_boundaries return a boundary list
    monkeypatch.setattr("farm_sim.gps_utils.JohnDeereAPI.get_field_boundaries",
                        lambda self, fid: [(0,0),(0,1),(1,1),(1,0)])
    # make create_field_from_gps raise to hit exception path
    monkeypatch.setattr("farm_sim.ui.field_selector.create_field_from_gps",
                        lambda b: (_ for _ in ()).throw(RuntimeError("conv fail")))
    # select_sample_gps_field does not catch this exception so expect it
    with pytest.raises(RuntimeError):
        select_sample_gps_field()

def test_draw_instructions_and_area_text_positions(monkeypatch):
    """Make sure draw draws instructions and area text for many items (smoke test)."""
    class FakeScreen:
        def __init__(self):
            self.blit_calls = []
            self.fills = []
        def fill(self, c): self.fills.append(c)
        def blit(self, surf, pos): self.blit_calls.append((surf, pos))
    screen = FakeScreen()
    sel = FieldSelector(700, 500)
    # build fields with varied names, org and areas to exercise rendering loops
    sel.fields = [
        {'field_id': '1', 'field_name': 'FieldX', 'org_name': 'Org1', 'area': 0.0},
        {'field_id': '2', 'field_name': 'FieldY', 'org_name': 'Org2', 'area': 123.456},
        {'field_id': '3', 'field_name': 'FieldZ', 'org_name': 'Org3', 'area': 9.0},
    ]
    sel.selected_index = 1
    sel.scroll_offset = 0
    sel.draw(screen)
    # Should have drawn background and multiple blits for field entries + instruction text
    assert screen.fills
    assert len(screen.blit_calls) >= 3

def test_select_john_deere_field_handles_fetch_fields_failing(monkeypatch):
    """If FieldSelector.fetch_fields returns False, select_john_deere_field should still run and show error (return None)."""
    def fake_fetch(self):
        self.fields = []
        return False
    monkeypatch.setattr(fs_mod.FieldSelector, "fetch_fields", fake_fetch)
    # no events, function should display and then receive QUIT -> return None
    pygame.event.get = EventFeeder([SimpleNamespace(type=pygame.QUIT)]).get
    res = select_john_deere_field()
    assert res is None
