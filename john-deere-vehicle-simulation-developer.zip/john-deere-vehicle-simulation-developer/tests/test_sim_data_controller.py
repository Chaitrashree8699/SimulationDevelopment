# tests/test_sim_data_controller.py
import os
import tempfile
from pathlib import Path
import pytest

# ✅ Correct import for your actual module
from operations_center.sim_data_controller import push_simulation
from farm_sim.config import ORG_ID


# --- Fixtures / helpers -----------------------------------------------------
@pytest.fixture
def tmp_file(tmp_path):
    """Create a small temporary file for upload simulation."""
    p = tmp_path / "payload.bin"
    p.write_bytes(b"payload-data" )
    return str(p)


# --- Tests ------------------------------------------------------------------
def test_push_simulation_success(monkeypatch, tmp_file, capsys):
    created_id = "file-12345"
    calls = {"create": None, "upload": None, "get": None}

    def fake_create(org_id, file_name):
        assert file_name == os.path.basename(tmp_file)
        calls["create"] = (org_id, file_name)
        return created_id

    def fake_upload(file_id, path):
        assert file_id == created_id
        assert path == tmp_file
        calls["upload"] = (file_id, path)

    def fake_get(file_id):
        assert file_id == created_id
        calls["get"] = (file_id,)
        return {"id": file_id, "status": "available", "type": "simulation"}

    monkeypatch.setattr("operations_center.sim_data_controller.create_file", fake_create)
    monkeypatch.setattr("operations_center.sim_data_controller.upload_file", fake_upload)
    monkeypatch.setattr("operations_center.sim_data_controller.get_file", fake_get)

    result = push_simulation(ORG_ID, tmp_file)
    assert result == created_id
    assert calls["create"] == (ORG_ID, os.path.basename(tmp_file))
    assert calls["upload"] == (created_id, tmp_file)
    assert calls["get"] == (created_id,)

    captured = capsys.readouterr()
    assert "File status=available, type=simulation" in captured.out


def test_push_simulation_create_raises(monkeypatch, tmp_file):
    def bad_create(org_id, file_name):
        raise RuntimeError("create failed")

    monkeypatch.setattr("operations_center.sim_data_controller.create_file", bad_create)
    monkeypatch.setattr("operations_center.sim_data_controller.upload_file",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("upload called")))
    monkeypatch.setattr("operations_center.sim_data_controller.get_file",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("get called")))

    with pytest.raises(RuntimeError) as exc:
        push_simulation(ORG_ID, tmp_file)
    assert "create failed" in str(exc.value)


def test_push_simulation_upload_raises(monkeypatch, tmp_file):
    created_id = "file-xyz"

    def fake_create(org_id, file_name):
        return created_id

    def bad_upload(file_id, path):
        raise RuntimeError("upload failed")

    monkeypatch.setattr("operations_center.sim_data_controller.create_file", fake_create)
    monkeypatch.setattr("operations_center.sim_data_controller.upload_file", bad_upload)
    monkeypatch.setattr("operations_center.sim_data_controller.get_file",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("get called")))

    with pytest.raises(RuntimeError) as exc:
        push_simulation(ORG_ID, tmp_file)
    assert "upload failed" in str(exc.value)


def test_push_simulation_get_missing_fields(monkeypatch, tmp_file, capsys):
    created_id = "file-777"

    def fake_create(org_id, file_name):
        return created_id

    def fake_upload(file_id, path):
        return None

    def fake_get(file_id):
        return {"id": file_id, "other": "value"}  # missing 'status'/'type'

    monkeypatch.setattr("operations_center.sim_data_controller.create_file", fake_create)
    monkeypatch.setattr("operations_center.sim_data_controller.upload_file", fake_upload)
    monkeypatch.setattr("operations_center.sim_data_controller.get_file", fake_get)

    result = push_simulation(ORG_ID, tmp_file)
    assert result == created_id

    out = capsys.readouterr().out
    assert "File status=None, type=None" in out
