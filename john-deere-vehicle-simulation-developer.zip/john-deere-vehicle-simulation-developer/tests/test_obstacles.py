import pytest
from types import SimpleNamespace
from farm_sim.world import obstacles


# -----------------------------
# Utility / helper tests
# -----------------------------
def test_clamped_position_basic(monkeypatch):
    """Ensure clamped position stays within margin bounds."""
    called = {}

    def fake_clamp(val, lo, hi):
        called.setdefault("calls", []).append((val, lo, hi))
        return max(lo, min(hi, val))

    monkeypatch.setattr(obstacles, "clamp", fake_clamp)
    x, z = obstacles._clamped_position(0.5, -0.5, 10, 10, 2)
    assert -10 < x < 10
    assert -10 < z < 10
    assert len(called["calls"]) == 2


def test_sample_path_points_various_cases():
    """Test path sampling edge cases and normal behavior."""
    # Empty path
    assert obstacles._sample_path_points([], 5) == []
    # Zero samples
    assert obstacles._sample_path_points([(1, 2), (3, 4)], 0) == []

    # Normal path with multiple points
    pts = [(i, i * 2) for i in range(15)]
    result = obstacles._sample_path_points(pts, 4)
    assert all(isinstance(p, tuple) for p in result)
    assert 1 <= len(result) <= 5


# -----------------------------
# Main function: generate_obstacles
# -----------------------------
def test_generate_obstacles_no_path(monkeypatch):
    """Generate scenic obstacles only, no path."""
    obs = obstacles.generate_obstacles(200, 150)
    assert all(isinstance(o, obstacles.Obstacle) for o in obs)
    assert any(o.kind == "tree" for o in obs)
    assert len(obs) == len(obstacles._FIELD_FEATURES)  # only scenic


def test_generate_obstacles_with_path(monkeypatch):
    """Generate with path to include dynamic blockers."""
    path = [(i, i * 1.2) for i in range(20)]
    obs = obstacles.generate_obstacles(100, 80, path)
    # scenic + path-based obstacles
    assert len(obs) > len(obstacles._FIELD_FEATURES)
    assert any(o.kind in {"stone", "bush", "tree", "pond"} for o in obs)


def test_generate_obstacles_small_field(monkeypatch):
    """Clamp lower bound logic for small field sizes."""
    obs = obstacles.generate_obstacles(1, 1)
    assert all(o.scale > 0 for o in obs)
    assert all(-1 <= o.x <= 1 for o in obs)
    assert all(-1 <= o.z <= 1 for o in obs)


def test_generate_obstacles_blockers_repeatable(monkeypatch):
    """Ensure blocking obstacles cycle correctly."""
    path = [(i, 0.1 * i) for i in range(30)]
    obs1 = obstacles.generate_obstacles(120, 120, path)
    obs2 = obstacles.generate_obstacles(120, 120, path)
    # deterministic, same length and sequence
    kinds1 = [o.kind for o in obs1]
    kinds2 = [o.kind for o in obs2]
    assert kinds1 == kinds2
    assert any(o.size in {"small", "medium", "large"} for o in obs1)


def test_generate_obstacles_limits(monkeypatch):
    """Test clamp and scaling edge limits."""
    # Force clamp to always return middle value
    monkeypatch.setattr(obstacles, "clamp", lambda v, lo, hi: (lo + hi) / 2)
    obs = obstacles.generate_obstacles(9999, 9999)
    # Check extreme scaling applied
    assert all(0.5 < o.scale < 3.0 for o in obs)
    # Ensure positions are within safe region
    assert all(-5000 < o.x < 5000 for o in obs)


def test_generate_obstacles_path_empty(monkeypatch):
    """Ensure function handles empty path gracefully."""
    obs = obstacles.generate_obstacles(50, 50, [])
    assert len(obs) == len(obstacles._FIELD_FEATURES)
    # no additional blockers
    kinds = {o.kind for o in obs}
    assert "stone" in kinds or "bush" in kinds or "tree" in kinds


def test_generate_obstacles_with_short_path(monkeypatch):
    """Short path still generates blockers (sampled subset)."""
    path = [(0, 0), (1, 1), (2, 2)]
    obs = obstacles.generate_obstacles(60, 60, path)
    assert len(obs) > len(obstacles._FIELD_FEATURES)
    assert any(o.kind == "bush" for o in obs)


def test_pond_stays_near_center():
    obs = obstacles.generate_obstacles(100, 80)
    ponds = [o for o in obs if o.kind == "pond"]
    assert ponds
    pond = ponds[0]
    assert abs(pond.x) < 5.0
    assert abs(pond.z) < 5.0


def test_large_obstacles_only_on_big_fields():
    small_field_obs = obstacles.generate_obstacles(55, 70)
    assert all(o.size != "large" for o in small_field_obs)

    large_field_obs = obstacles.generate_obstacles(65, 65)
    assert any(o.size == "large" for o in large_field_obs)
