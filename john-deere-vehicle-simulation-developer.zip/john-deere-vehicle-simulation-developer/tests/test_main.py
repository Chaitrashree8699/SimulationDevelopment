import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the parent directory to the path to import main
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestMain(unittest.TestCase):
    
    @patch('farm_sim.core.game.Game')
    @patch('farm_sim.ui.menu.start_menu')
    def test_main_imports(self, mock_start_menu, mock_game):
        """Test main module imports and basic structure"""
        # Mock menu to return configuration
        mock_start_menu.return_value = (50, 50, 'tractor', 'open_field', 'Open Field', False)
        
        # Mock game
        mock_game_instance = MagicMock()
        mock_game.return_value = mock_game_instance
        
        # Import main module (this will execute the imports but not __main__)
        import main
        
        # Verify imports work
        self.assertTrue(hasattr(main, 'Game'))
        self.assertTrue(hasattr(main, 'start_menu'))
        self.assertTrue(hasattr(main, 'WINDOW_SIZE'))

if __name__ == '__main__':
    unittest.main()