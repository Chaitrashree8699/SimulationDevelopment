# tests/test_fields_service.py
import json
from types import SimpleNamespace

import pytest
import requests   # used for exceptions in FakeResponse

import importlib
from farm_sim.config import ORG_ID
fs_mod = importlib.import_module("operations_center.fields_service")


# --- Helpers ---------------------------------------------------------------
class FakeResponse:
    """
    Minimal fake of requests.Response used by tests.
    Implements .status_code, .text, .headers, .json() and raise_for_status().
    """
    def __init__(self, status=200, payload=None, text=""):
        self.status_code = status
        self._payload = payload or {}
        self.text = text
        self.headers = {"content-type": "application/json"}

    def json(self):
        return self._payload

    def raise_for_status(self):
        if 400 <= int(self.status_code):
            # mimic requests' HTTPError
            raise requests.HTTPError(f"{self.status_code} Error: {self.text}", response=self)
        return None


class DummyRequests:
    """
    Simple requests.get stub that uses a mapping from URL (str) to FakeResponse.
    If a URL isn't present, returns a 404 FakeResponse by default.
    """
    def __init__(self, mapping):
        # mapping: {url_substring_or_full_url: FakeResponse}
        self.mapping = mapping

    def get(self, url, headers=None, timeout=None):
        # choose response by exact match first, then substring match
        if url in self.mapping:
            return self.mapping[url]
        for k, v in self.mapping.items():
            if k and k in url:
                return v
        return FakeResponse(404, {}, text="not found")


# --- Fixtures --------------------------------------------------------------
@pytest.fixture(autouse=True)
def fake_auth_header(monkeypatch):
    """Make auth_header deterministic and avoid using real tokens."""
    monkeypatch.setattr(fs_mod, "auth_header", lambda: {"Authorization": "Bearer test-token"})
    yield


# --- Tests for get_fields -------------------------------------------------
def test_get_fields_populates_area_from_detail(monkeypatch):
    """
    When the fields list is returned and the detail endpoint provides an 'area' with 'value',
    the function should attach that area to the field dict.
    """
    org_id = 12345
    list_url_sub = f"/organizations/{org_id}/fields"
    fields_payload = {"values": [{"id": f"/platform/fields/42", "name": "Field A"}]}
    detail_payload = {"area": {"value": 12.34}}

    mapping = {
        fs_mod.BASE_URL + list_url_sub: FakeResponse(200, fields_payload),
        fs_mod.BASE_URL + "/fields/42": FakeResponse(200, detail_payload)
    }
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    out = fs_mod.get_fields(org_id)
    assert isinstance(out, list)
    assert len(out) == 1
    fld = out[0]
    # area should have been attached from detail response
    assert "area" in fld
    assert fld["area"]["value"] == pytest.approx(12.34)


def test_get_fields_ignores_detail_failures(monkeypatch):
    """If fetching field detail fails (non-200), get_fields should continue and skip area."""
    org_id = 9
    list_payload = {"values": [{"id": "/platform/fields/7", "name": "Field B"}]}

    mapping = {
        fs_mod.BASE_URL + f"/organizations/{org_id}/fields": FakeResponse(200, list_payload),
        # detail endpoint returns 500
        fs_mod.BASE_URL + "/fields/7": FakeResponse(500, {}, text="server error")
    }
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    out = fs_mod.get_fields(org_id)
    assert isinstance(out, list) and len(out) == 1
    fld = out[0]
    # area should not be present when detail fetch fails
    assert "area" not in fld


def test_get_fields_handles_empty_list(monkeypatch):
    """If API returns empty list, simply return the empty list (no exception)."""
    org_id = 777
    mapping = {
        fs_mod.BASE_URL + f"/organizations/{org_id}/fields": FakeResponse(200, {"values": []})
    }
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    out = fs_mod.get_fields(org_id)
    assert isinstance(out, list)
    assert out == []


# --- Tests for get_field_boundaries --------------------------------------
def test_get_field_boundaries_multipolygon_with_area(monkeypatch):
    """
    Provide a John Deere-style multipolygon boundary (with rings -> points)
    and an 'area' with valueAsDouble. Expect converted (lat, lon) tuples and area.
    """
    field_id = "field-multi-1"
    url_sub = f"/organizations/{ORG_ID}/fields/{field_id}/boundaries"

    boundary_payload = {
        "values": [
            {
                "area": {"valueAsDouble": 5.5},
                "multipolygons": [
                    {"rings": [
                        {"points": [
                            {"lat": 10.0, "lon": 20.0},
                            {"lat": 10.1, "lon": 20.1},
                            {"lat": 10.0, "lon": 20.2},
                        ]}
                    ]}
                ]
            }
        ]
    }
    mapping = {
        fs_mod.BASE_URL + url_sub: FakeResponse(200, boundary_payload)
    }
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    pts, area = fs_mod.get_field_boundaries(field_id)
    assert isinstance(pts, list) and len(pts) == 3
    assert pts[0] == (10.0, 20.0)
    assert area == pytest.approx(5.5)


def test_get_field_boundaries_geojson_fallback(monkeypatch):
    """
    Provide GeoJSON-like geometry in 'geometry' key; function should extract coords and convert.
    Uses coordinates in [lon, lat] pairs (first ring).
    """
    field_id = "geo-1"
    url_sub = f"/organizations/{ORG_ID}/fields/{field_id}/boundaries"
    # geojson style: coordinates: [ [ [lon, lat], [lon, lat], ... ] ]
    geo_payload = {
        "values": [
            {
                "geometry": {
                    "coordinates": [[
                        [30.0, 40.0],
                        [30.1, 40.1],
                        [30.2, 40.2]
                    ]]
                }
            }
        ]
    }
    mapping = {
        fs_mod.BASE_URL + url_sub: FakeResponse(200, geo_payload)
    }
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    pts, area = fs_mod.get_field_boundaries(field_id)
    assert isinstance(pts, list) and len(pts) == 3
    # Note: function converts (lon,lat) -> (lat,lon) while returning
    assert pts[0] == (40.0, 30.0)
    assert area == 0  # no area provided in this payload


def test_get_field_boundaries_handles_non_200(monkeypatch):
    """If the boundaries endpoint returns non-200, function must return empty list and zero area without raising."""
    field_id = "missing"
    url_sub = f"/organizations/{ORG_ID}/fields/{field_id}/boundaries"
    mapping = {
        fs_mod.BASE_URL + url_sub: FakeResponse(404, {}, text="not found")
    }
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    pts, area = fs_mod.get_field_boundaries(field_id)
    assert pts == []
    assert area == 0


def test_get_field_boundaries_no_geometry(monkeypatch):
    """
    If the payload contains values but neither multipolygons nor geometry, the function returns [],0.
    """
    field_id = "no-geom"
    url_sub = f"/organizations/{ORG_ID}/fields/{field_id}/boundaries"
    payload = {"values": [{"some": "data"}]}
    mapping = {fs_mod.BASE_URL + url_sub: FakeResponse(200, payload)}
    monkeypatch.setattr(fs_mod, "requests", DummyRequests(mapping))

    pts, area = fs_mod.get_field_boundaries(field_id)
    assert pts == []
    assert area == 0
