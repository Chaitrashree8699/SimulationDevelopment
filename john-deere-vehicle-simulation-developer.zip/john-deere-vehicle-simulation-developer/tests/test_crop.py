# tests/test_crop_growth.py
import pytest
from farm_sim.entities.crop import Crop
from farm_sim.config import CROP_GROW_SECONDS
from farm_sim.util import clamp

def test_defaults():
    c = Crop(x=1.0, z=2.0, planted_time=100.0)
    assert c.harvested is False
    assert c.sprayed is False
    assert c.x == 1.0
    assert c.z == 2.0

def test_growth_at_planted_time_is_zero():
    t0 = 100.0
    c = Crop(x=0, z=0, planted_time=t0)
    g = c.growth(t0)
    assert isinstance(g, float)
    assert g == pytest.approx(0.0)

def test_growth_halfway():
    t0 = 100.0
    half = t0 + CROP_GROW_SECONDS / 2.0
    c = Crop(x=0, z=0, planted_time=t0)
    g = c.growth(half)
    expected = clamp((half - t0) / CROP_GROW_SECONDS, 0.0, 1.0)
    assert g == pytest.approx(expected)
    assert 0.0 < g < 1.0

def test_growth_after_full_time_clamped_to_one():
    t0 = 100.0
    after = t0 + CROP_GROW_SECONDS * 2.0
    c = Crop(x=0, z=0, planted_time=t0)
    g = c.growth(after)
    assert g == pytest.approx(1.0)

def test_growth_before_planted_time_clamped_to_zero():
    t0 = 100.0
    before = t0 - 10.0
    c = Crop(x=0, z=0, planted_time=t0)
    g = c.growth(before)
    assert g == pytest.approx(0.0)

@pytest.mark.parametrize("delta", [0.0, CROP_GROW_SECONDS/4, CROP_GROW_SECONDS, CROP_GROW_SECONDS + 10])
def test_growth_bounds_and_type(delta):
    t0 = 50.0
    now = t0 + delta
    c = Crop(x=0, z=0, planted_time=t0)
    g = c.growth(now)
    assert isinstance(g, float)
    assert 0.0 <= g <= 1.0
