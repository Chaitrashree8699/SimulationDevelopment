import pytest
import farm_sim.render.camera as cam_mod
from farm_sim.render.camera import DriverCamera, CamMode


@pytest.fixture(autouse=True)
def mock_opengl(monkeypatch):
    """Mock all OpenGL functions so tests run without a real GL context."""
    dummy = lambda *a, **kw: None
    for name in [
        "glMatrixMode", "glLoadIdentity", "glOrtho",
        "gluPerspective", "gluLookAt"
    ]:
        monkeypatch.setattr(cam_mod, name, dummy)
    return dummy


def test_default_initialization():
    """Verify default camera values are set correctly."""
    cam = DriverCamera()
    assert cam.mode == CamMode.HOOD
    assert cam.height_chase == pytest.approx(3.0)
    assert cam.dist_chase == pytest.approx(5.2)
    assert cam.look_ahead == pytest.approx(3.6)
    assert cam.fov_base == pytest.approx(60.0)
    assert cam.top_zoom == pytest.approx(18.0)


def test_initialization_with_different_modes():
    """Test camera initialization with different modes."""
    cam_chase = DriverCamera(mode=CamMode.CHASE)
    assert cam_chase.mode == CamMode.CHASE
    
    cam_top = DriverCamera(mode=CamMode.TOP)
    assert cam_top.mode == CamMode.TOP


def test_cycle_mode_wraps_around():
    """Cycle mode should wrap around correctly after TOP."""
    cam = DriverCamera(mode=CamMode.HOOD)
    cam.cycle_mode()
    assert cam.mode == CamMode.CHASE
    cam.cycle_mode()
    assert cam.mode == CamMode.TOP
    cam.cycle_mode()
    assert cam.mode == CamMode.HOOD


@pytest.mark.parametrize("mode", [CamMode.TOP, CamMode.HOOD, CamMode.CHASE])
def test_set_projection_calls(monkeypatch, mode):
    """Ensure the correct OpenGL projection function is called based on mode."""
    called = {}

    def fake_glOrtho(*args, **kwargs):
        called["glOrtho"] = True

    def fake_gluPerspective(*args, **kwargs):
        called["gluPerspective"] = True

    monkeypatch.setattr(cam_mod, "glMatrixMode", lambda *a, **kw: None)
    monkeypatch.setattr(cam_mod, "glLoadIdentity", lambda *a, **kw: None)
    monkeypatch.setattr(cam_mod, "glOrtho", fake_glOrtho)
    monkeypatch.setattr(cam_mod, "gluPerspective", fake_gluPerspective)

    cam = DriverCamera(mode=mode)
    cam._set_projection(width=800, height=600, fov=60.0)

    if mode == CamMode.TOP:
        assert "glOrtho" in called and "gluPerspective" not in called
    else:
        assert "gluPerspective" in called and "glOrtho" not in called


def test_apply_sets_projection_and_lookat(monkeypatch):
    """Check that apply() triggers correct projection and view setup."""
    called = {"_set_projection": False, "gluLookAt": False}

    # NOTE: include 'self' because this will be bound as a method
    def fake_set_projection(self, w, h, fov):
        called["_set_projection"] = True
        assert 30 < fov < 70  # sanity range check

    def fake_gluLookAt(*args):
        called["gluLookAt"] = True

    monkeypatch.setattr(cam_mod, "glMatrixMode", lambda *a, **kw: None)
    monkeypatch.setattr(cam_mod, "glLoadIdentity", lambda *a, **kw: None)
    monkeypatch.setattr(cam_mod, "gluLookAt", fake_gluLookAt)
    monkeypatch.setattr(DriverCamera, "_set_projection", fake_set_projection)

    # mock tractor-like object
    class DummyT:
        x, z, speed = 1.0, 2.0, 5.0
        def forward_vec(self): return (0.6, 0.8)

    cam = DriverCamera(mode=CamMode.CHASE)
    cam.apply(DummyT(), width=800, height=600)

    assert called["_set_projection"] is True
    assert called["gluLookAt"] is True


def test_apply_top_mode(monkeypatch):
    """TOP mode should still call gluLookAt but with top-down parameters."""
    called = {"gluLookAt": False}
    monkeypatch.setattr(cam_mod, "glMatrixMode", lambda *a, **kw: None)
    monkeypatch.setattr(cam_mod, "glLoadIdentity", lambda *a, **kw: None)

    def fake_gluLookAt(*args):
        called["gluLookAt"] = True
        # Expect cam_y to be ~50, look_y = 0
        assert abs(args[1] - 50.0) < 1e-6
        assert abs(args[4] - 0.0) < 1e-6

    monkeypatch.setattr(cam_mod, "gluLookAt", fake_gluLookAt)
    monkeypatch.setattr(DriverCamera, "_set_projection", lambda *a, **kw: None)

    class DummyT:
        x, z, speed = 0.0, 0.0, 0.0
        def forward_vec(self): return (0.0, 1.0)

    cam = DriverCamera(mode=CamMode.TOP)
    cam.apply(DummyT(), width=640, height=480)

    assert called["gluLookAt"] is True
