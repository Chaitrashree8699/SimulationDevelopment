import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the parent directory to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from operations_center import auth

class TestAuth(unittest.TestCase):
    
    @patch('operations_center.auth.requests.post')
    @patch('operations_center.auth._load')
    def test_get_access_token_success(self, mock_load, mock_post):
        """Test successful token retrieval"""
        mock_load.return_value = None
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'access_token': 'test_token', 'expires_in': 3600}
        mock_post.return_value = mock_response
        
        with patch('operations_center.auth.FLOW', 'client_credentials'):
            token = auth.get_access_token()
            self.assertEqual(token, 'test_token')
    
    def test_auth_header(self):
        """Test auth header generation"""
        with patch('operations_center.auth.get_access_token', return_value='test_token'):
            header = auth.auth_header()
            self.assertEqual(header, {'Authorization': 'Bearer test_token'})
    
    def test_normalize_scopes(self):
        """Test scope normalization"""
        result = auth._normalize_scopes('scope1,scope2 scope3')
        self.assertEqual(result, 'scope1 scope2 scope3')
    
    def test_ensure_offline_access(self):
        """Test offline access scope addition"""
        result = auth._ensure_offline_access('scope1 scope2')
        self.assertIn('offline_access', result)
        
        # Test when offline_access already exists
        result2 = auth._ensure_offline_access('scope1 offline_access scope2')
        self.assertEqual(result2.count('offline_access'), 1)
    
    def test_basic_auth(self):
        """Test basic auth header generation"""
        with patch('operations_center.auth.APP_ID', 'test_id'), \
             patch('operations_center.auth.SECRET_KEY', 'test_secret'):
            result = auth._basic_auth()
            self.assertTrue(result.startswith('Basic '))

if __name__ == '__main__':
    unittest.main()