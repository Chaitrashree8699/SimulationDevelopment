# tests/test_implements.py
import math
from types import SimpleNamespace

import pytest

import farm_sim.entities.implements as impl_mod


# --- OpenGL stub fixture -----------------------------------------------------


@pytest.fixture(autouse=True)
def stub_opengl(monkeypatch):
    """
    Stub the OpenGL calls used by implements.py so tests can run headless
    without a real GL context.
    """

    def make_stub(name):
        def _inner(*a, **kw):
            # We don't assert on GL calls any more; just make them no-ops.
            return None
        return _inner

    gl_fns = [
        "glPushMatrix",
        "glPopMatrix",
        "glTranslatef",
        "glColor3f",
        "glBegin",
        "glEnd",
        "glVertex3f",
        "glRotatef",
        "glPointSize",
    ]

    for fn in gl_fns:
        # Only patch if the symbol exists in the module
        if hasattr(impl_mod, fn):
            monkeypatch.setattr(impl_mod, fn, make_stub(fn))


# --- Spy fixture for draw_cube / draw_cylinder -------------------------------


@pytest.fixture
def draw_spies(monkeypatch):
    """
    Replace draw_cube and draw_cylinder with spies that only record calls.
    """
    calls = []

    def spy_cube(*args, **kwargs):
        calls.append(("cube", args, kwargs))

    def spy_cylinder(*args, **kwargs):
        calls.append(("cyl", args, kwargs))

    monkeypatch.setattr(impl_mod, "draw_cube", spy_cube)
    monkeypatch.setattr(impl_mod, "draw_cylinder", spy_cylinder)

    return calls


# --- Enum sanity -------------------------------------------------------------


def test_implementtype_enum_values():
    assert impl_mod.ImplementType.NONE.value == 0
    assert impl_mod.ImplementType.PLOW.value == 1
    assert impl_mod.ImplementType.SOWER.value == 2
    assert impl_mod.ImplementType.SPRAYER.value == 3
    assert impl_mod.ImplementType.IRRIGATION.value == 4
    assert impl_mod.ImplementType.HARVESTER.value == 5


# --- Helper ------------------------------------------------------------------


def _cylinders_with_radius(calls, radius, tol=1e-6):
    """
    Filter draw_cylinder calls by (approximate) radius.
    calls: list from draw_spies
    """
    out = []
    for kind, args, kwargs in calls:
        if kind != "cyl":
            continue
        r = float(args[0])
        if math.isclose(r, radius, rel_tol=0, abs_tol=tol):
            out.append((args, kwargs))
    return out


# --- draw_plow ---------------------------------------------------------------


def test_draw_plow_emits_expected_blades(draw_spies):
    calls = draw_spies
    width = 6.0
    impl_mod.draw_plow(offset_z=-1.8, width=width, depth=0.35)

    # Coulter discs use draw_cylinder(0.1, 0.015, 12) once per blade
    coulters = _cylinders_with_radius(calls, 0.1)
    expected_blades = max(3, int(width / 1.5))  # same formula as in draw_plow
    assert len(coulters) == expected_blades

    # There should also be at least one cube (main frame and supports)
    cube_calls = [c for c in calls if c[0] == "cube"]
    assert len(cube_calls) >= 1


def test_draw_plow_respects_width_parameter(draw_spies):
    calls = draw_spies

    # Narrow plow
    impl_mod.draw_plow(width=3.0)
    coulters_narrow = _cylinders_with_radius(calls, 0.1)
    blades_narrow = max(3, int(3.0 / 1.5))
    assert len(coulters_narrow) == blades_narrow

    calls.clear()

    # Wide plow
    impl_mod.draw_plow(width=9.0)
    coulters_wide = _cylinders_with_radius(calls, 0.1)
    blades_wide = max(3, int(9.0 / 1.5))
    assert len(coulters_wide) == blades_wide

    # Wider width -> at least as many blades
    assert blades_wide >= blades_narrow


# --- draw_sower --------------------------------------------------------------


def test_draw_sower_rows_and_discs(draw_spies):
    calls = draw_spies
    width = 6.0
    impl_mod.draw_sower(offset_z=-1.8, width=width)

    # In draw_sower:
    # rows = max(4, int(width / 1.2))
    expected_rows = max(4, int(width / 1.2))

    # Seed tubes: draw_cylinder(0.02, 0.2, 6)
    tubes = _cylinders_with_radius(calls, 0.02)
    # Opener discs: draw_cylinder(0.08, 0.015, 12)
    discs = _cylinders_with_radius(calls, 0.08)

    assert len(tubes) == expected_rows
    assert len(discs) == expected_rows


def test_draw_sower_rows_scale_with_width(draw_spies):
    calls = draw_spies

    impl_mod.draw_sower(width=6.0)
    rows_6 = max(4, int(6.0 / 1.2))
    discs_6 = _cylinders_with_radius(calls, 0.08)
    assert len(discs_6) == rows_6

    calls.clear()

    impl_mod.draw_sower(width=9.0)
    rows_9 = max(4, int(9.0 / 1.2))
    discs_9 = _cylinders_with_radius(calls, 0.08)
    assert len(discs_9) == rows_9

    assert rows_9 >= rows_6


# --- draw_sprayer ------------------------------------------------------------


def test_draw_sprayer_emits_expected_nozzles(draw_spies):
    calls = draw_spies
    width = 6.0
    impl_mod.draw_sprayer(offset_z=-1.8, width=width)

    # Nozzle bodies: draw_cylinder(0.03, 0.08, 6)
    nozzles = _cylinders_with_radius(calls, 0.03)
    expected_nozzles = max(6, int(width * 1.5))
    assert len(nozzles) == expected_nozzles

    # There should also be at least one cube (tank, boom etc.)
    cube_calls = [c for c in calls if c[0] == "cube"]
    assert len(cube_calls) >= 1


# --- draw_irrigation ---------------------------------------------------------


def test_draw_irrigation_sprinkler_count(draw_spies):
    calls = draw_spies
    width = 6.0
    impl_mod.draw_irrigation(offset_z=-1.8, width=width)

    # Sprinkler heads: draw_cylinder(0.04, 0.1, 8)
    sprinklers = _cylinders_with_radius(calls, 0.04)
    expected_nozzles = max(8, int(width * 2.0))
    assert len(sprinklers) == expected_nozzles

    # Pipe joints also use cylinders, but with a different radius (0.08),
    # so we don't confuse them with sprinklers.


# --- draw_harvester ----------------------------------------------------------


def test_draw_harvester_reel_and_cutter(draw_spies):
    calls = draw_spies
    width = 6.0
    impl_mod.draw_harvester(offset_z=-1.8, width=width)

    # There should be exactly one reel cylinder: draw_cylinder(0.08, header_width * 0.7, 12)
    reels = _cylinders_with_radius(calls, 0.08)
    assert len(reels) == 1

    # There should be several cubes: header frame, grain pan, arms, tines, cutterbar, sections
    cube_calls = [c for c in calls if c[0] == "cube"]
    assert len(cube_calls) >= 5


# --- draw_implement dispatch -------------------------------------------------


def test_draw_implement_dispatches_to_correct_drawer(monkeypatch):
    # Replace per-implement draw functions with spies to capture the width argument
    seen = {}

    def spy_plow(*, width=0.0, **kw):
        seen["plow"] = width

    def spy_sower(*, width=0.0, **kw):
        seen["sower"] = width

    def spy_sprayer(*, width=0.0, **kw):
        seen["sprayer"] = width

    def spy_irrigation(*, width=0.0, **kw):
        seen["irrigation"] = width

    def spy_harvester(*, width=0.0, **kw):
        seen["harvester"] = width

    monkeypatch.setattr(impl_mod, "draw_plow", spy_plow)
    monkeypatch.setattr(impl_mod, "draw_sower", spy_sower)
    monkeypatch.setattr(impl_mod, "draw_sprayer", spy_sprayer)
    monkeypatch.setattr(impl_mod, "draw_irrigation", spy_irrigation)
    monkeypatch.setattr(impl_mod, "draw_harvester", spy_harvester)

    # Case 1: tractor provided -> should use tractor.spec.working_width
    tractor = SimpleNamespace(spec=SimpleNamespace(working_width=8.0))

    impl_mod.draw_implement(impl_mod.ImplementType.PLOW, tractor=tractor)
    impl_mod.draw_implement(impl_mod.ImplementType.SOWER, tractor=tractor)
    impl_mod.draw_implement(impl_mod.ImplementType.SPRAYER, tractor=tractor)
    impl_mod.draw_implement(impl_mod.ImplementType.IRRIGATION, tractor=tractor)
    impl_mod.draw_implement(impl_mod.ImplementType.HARVESTER, tractor=tractor)

    assert seen.get("plow") == pytest.approx(8.0)
    assert seen.get("sower") == pytest.approx(8.0)
    assert seen.get("sprayer") == pytest.approx(8.0)
    assert seen.get("irrigation") == pytest.approx(8.0)
    assert seen.get("harvester") == pytest.approx(8.0)

    # Case 2: no tractor -> default width 6.0 used
    seen.clear()
    impl_mod.draw_implement(impl_mod.ImplementType.PLOW, tractor=None)
    impl_mod.draw_implement(impl_mod.ImplementType.SOWER, tractor=None)
    impl_mod.draw_implement(impl_mod.ImplementType.SPRAYER, tractor=None)
    impl_mod.draw_implement(impl_mod.ImplementType.IRRIGATION, tractor=None)
    impl_mod.draw_implement(impl_mod.ImplementType.HARVESTER, tractor=None)

    assert seen.get("plow") == pytest.approx(6.0)
    assert seen.get("sower") == pytest.approx(6.0)
    assert seen.get("sprayer") == pytest.approx(6.0)
    assert seen.get("irrigation") == pytest.approx(6.0)
    assert seen.get("harvester") == pytest.approx(6.0)
