# tests/test_autopilot_all_extended.py
import sys
import os
import math
import pytest
from unittest.mock import MagicMock, patch
from pathlib import Path

# ensure repo root on sys.path (helpful if running tests from elsewhere)
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from farm_sim.core.autopilot import AutoPilot

# ----------------------------------------------------------
# DummyObstacle used for obstacle tests — provides fields
# expected by farm_sim.world.obstacles.collision_radius
# ----------------------------------------------------------
class DummyObstacle:
    def __init__(self, x, z, kind="rock", scale=1.0, size="medium"):
        self.x = x
        self.z = z
        self.kind = kind
        # collision_radius expects obs.scale and obs.size (via getattr)
        self.scale = scale
        self.size = size

# --------------------------------------------------------------------------
# GLOBAL OPENGL PATCH (prevents GL errors in CI)
# --------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def mock_opengl(monkeypatch):
    for func in ["glDisable", "glEnable", "glLineWidth", "glColor3f", "glBegin", "glEnd", "glVertex3f"]:
        monkeypatch.setattr(f"farm_sim.core.autopilot.{func}", lambda *a, **kw: None)
    monkeypatch.setattr("farm_sim.core.autopilot.GL_LINE_STRIP", 0)
    monkeypatch.setattr("farm_sim.core.autopilot.GL_LIGHTING", 0)


# --------------------------------------------------------------------------
# FIXTURE
# --------------------------------------------------------------------------
@pytest.fixture
def auto():
    """Create an AutoPilot instance with default params."""
    return AutoPilot(field_w=50, field_h=30)


# -------------------------
# ORIGINAL / BASIC BEHAVIOR
# -------------------------
def test_init_defaults(auto):
    assert not auto.enabled
    assert auto.show_path
    assert isinstance(auto.path, list)
    assert auto.lane_spacing > 0
    assert auto.turn_inset > 0


def test_semi_arc_shape(auto):
    pts = auto._semi_arc(-1, 1, 0)
    xs, zs = zip(*pts)
    assert len(pts) > 5
    assert math.isclose(xs[0], -1, abs_tol=1e-3)
    assert math.isclose(xs[-1], 1, abs_tol=1e-3)
    assert max(zs) != min(zs)


def test_push_skips_duplicates(auto):
    auto.path = [(1, 1)]
    auto._push(1, 1)
    assert len(auto.path) == 1
    auto._push(1.1, 1.0)
    assert len(auto.path) == 2


def test_build_path_generates_points(auto):
    auto.build_path()
    assert len(auto.path) > 10
    xs, zs = zip(*auto.path)
    assert min(xs) >= -auto.field_w / 2
    assert max(xs) <= auto.field_w / 2


def test_build_path_snake_pattern(auto):
    auto.build_path()
    directions = []
    for i in range(1, len(auto.path)):
        dx = auto.path[i][0] - auto.path[i - 1][0]
        dz = auto.path[i][1] - auto.path[i - 1][1]
        if abs(dx) < 1e-6:
            directions.append("up" if dz > 0 else "down")
    assert "up" in directions and "down" in directions


def test_build_path_handles_small_field():
    a = AutoPilot(4, 4, lane_spacing=3, turn_inset=1)
    a.build_path()
    assert len(a.path) > 2
    assert all(isinstance(p, tuple) for p in a.path)


def test_build_path_respects_turn_inset(auto):
    auto.build_path()
    _, zs = zip(*auto.path)
    assert min(zs) >= -(auto.field_h / 2)
    assert max(zs) <= (auto.field_h / 2)


def test_semi_arc_zero_span(auto):
    pts = auto._semi_arc(1, 1, 0)
    assert all(x == 1 for x, _ in pts)


def test_build_path_with_negative_dimensions():
    a = AutoPilot(-50, -30, lane_spacing=3, turn_inset=2)
    a.build_path()
    assert isinstance(a.path, list)
    assert len(a.path) == 0


def test_build_path_with_very_small_turn_inset():
    a = AutoPilot(10, 10, lane_spacing=3, turn_inset=0.1)
    a.build_path()
    assert isinstance(a.path, list)


# -------------------------
# TOGGLE / TELEPORT / PICK
# -------------------------
def test_toggle_builds_path_when_enabled(auto):
    auto.toggle()
    assert auto.enabled
    assert len(auto.path) > 0


def test_toggle_disables_autopilot(auto):
    auto.toggle()
    auto.toggle()
    assert not auto.enabled


def test_toggle_rebuilds_after_path_cleared(auto):
    auto.build_path()
    auto.enabled = False
    auto.path.clear()
    auto.toggle()
    assert auto.enabled
    assert len(auto.path) > 0


def test_toggle_multiple_times_keeps_consistency(auto):
    states = []
    for _ in range(5):
        auto.toggle()
        states.append(auto.enabled)
    assert states.count(True) > 0 and states.count(False) > 0


def test_toggle_does_not_rebuild_if_path_exists(auto):
    auto.build_path()
    old_path = list(auto.path)
    auto.toggle()
    auto.toggle()
    assert auto.path == old_path


def test_teleport_to_start_sets_position_and_yaw(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.WHEELBASE = 2.5
    auto.teleport_to_start(tractor)
    assert hasattr(tractor, "x") and hasattr(tractor, "yaw")


def test_teleport_to_start_handles_empty_path(auto):
    auto.path = []
    tractor = MagicMock()
    tractor.WHEELBASE = 2.0
    auto.teleport_to_start(tractor)
    assert hasattr(tractor, "x")


def test_teleport_to_start_short_path(auto):
    auto.path = [(0, 0)]
    tractor = MagicMock()
    tractor.WHEELBASE = 2.0
    auto.teleport_to_start(tractor)
    assert hasattr(tractor, "x")


def test_teleport_builds_path_if_empty(auto):
    auto.path = []
    tractor = MagicMock()
    tractor.WHEELBASE = 2.5
    auto.teleport_to_start(tractor)
    assert len(auto.path) > 0


def test_pick_target_index_advances(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    auto.lookahead = 0.1
    idx_after = auto._pick_target_index(tractor)
    assert idx_after >= 0


def test_pick_target_index_near_end(auto):
    auto.build_path()
    auto.idx = len(auto.path) - 2
    tractor = MagicMock(x=auto.path[-2][0], z=auto.path[-2][1])
    idx = auto._pick_target_index(tractor)
    assert idx >= len(auto.path) - 2


def test_pick_target_index_on_empty_path(auto):
    auto.path = []
    tractor = MagicMock(x=0, z=0)
    result = auto._pick_target_index(tractor)
    assert result == 0


def test_pick_target_index_far_away(auto):
    auto.build_path()
    tractor = MagicMock(x=9999, z=9999)
    idx = auto._pick_target_index(tractor)
    assert idx == 0


# -------------------------
# CONTROL SYSTEM TESTS
# -------------------------
def test_control_returns_expected_values(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 0.6
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    t, b, s = auto.control(tractor, 0.1)
    assert isinstance(t, bool) and isinstance(s, float)


def test_control_with_bias_shifts_target(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 2.0
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    _, _, s1 = auto.control(tractor, 0.1, steer_bias=0.0)
    _, _, s2 = auto.control(tractor, 0.1, steer_bias=0.3)
    assert abs(s1 - s2) > 1e-5


def test_control_clamps_steering_with_high_bias(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 0.4
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    _, _, s = auto.control(tractor, 0.1, steer_bias=10)
    assert abs(s) <= tractor.MAX_STEER


def test_control_returns_false_when_no_path(auto):
    tractor = MagicMock()
    t, b, s = auto.control(tractor, 0.1)
    assert (t, b, s) == (False, False, 0.0)


def test_control_returns_false_when_reached_end(auto):
    auto.build_path()
    auto.reached_end = True
    tractor = MagicMock()
    result = auto.control(tractor, 0.1)
    assert result == (False, False, 0.0)


def test_control_marks_reached_end_close_distance(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 0.6
    tractor.forward_vec.return_value = (0, -1)
    tractor.x, tractor.z = auto.path[-1][0] + 0.01, auto.path[-1][1] + 0.01
    tractor.yaw = 0.0
    tractor.v = 0.0
    auto.idx = len(auto.path) - 1
    auto.control(tractor, 0.1)
    assert auto.reached_end


def test_control_handles_negative_bias(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 2.0
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    _, _, sp = auto.control(tractor, 0.1, steer_bias=+0.5)
    _, _, sn = auto.control(tractor, 0.1, steer_bias=-0.5)
    assert math.copysign(1, sp) != math.copysign(1, sn)


def test_control_handles_no_lookahead(auto):
    auto.build_path()
    auto.lookahead = 0.0
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 1.0
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    _, _, s = auto.control(tractor, 0.1)
    assert isinstance(s, float)


def test_control_handles_nan_values(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = float("nan"), float("inf")
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 1.0
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    result = auto.control(tractor, 0.1)
    assert isinstance(result, tuple)


def test_control_with_zero_wheelbase(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 0.0
    tractor.MAX_STEER = 1.0
    tractor.v = 0.0
    tractor.forward_vec.return_value = (0, -1)
    _, _, s = auto.control(tractor, 0.1)
    assert isinstance(s, float)


def test_control_returns_defaults_when_path_empty(auto):
    auto.path = []
    auto.reached_end = False
    tractor = MagicMock()
    result = auto.control(tractor, 0.1)
    assert result == (False, False, 0.0)


# -------------------------
# DRAW TESTS
# -------------------------
def test_draw_invokes_opengl_calls(auto):
    auto.show_path = True
    auto.path = [(0, 0), (1, 1)]
    with patch("farm_sim.core.autopilot.glBegin") as g2, \
         patch("farm_sim.core.autopilot.glVertex3f") as g3, \
         patch("farm_sim.core.autopilot.glEnd"):
        auto.draw()
        assert g3.call_count == len(auto.path)


def test_draw_returns_when_show_path_false(auto):
    auto.show_path = False
    auto.path = [(0, 0), (1, 1)]
    with patch("farm_sim.core.autopilot.glBegin") as g2:
        auto.draw()
        g2.assert_not_called()


def test_draw_returns_when_no_path(auto):
    auto.show_path = True
    auto.path = []
    with patch("farm_sim.core.autopilot.glBegin") as g2:
        auto.draw()
        g2.assert_not_called()


def test_draw_handles_long_path(auto):
    auto.show_path = True
    auto.path = [(i, i * 0.5) for i in range(100)]
    with patch("farm_sim.core.autopilot.glBegin") as g2, \
         patch("farm_sim.core.autopilot.glVertex3f") as g3, \
         patch("farm_sim.core.autopilot.glEnd"):
        auto.draw()
        assert g3.call_count == len(auto.path)


def test_draw_when_path_has_none_entries_raises(auto):
    auto.show_path = True
    auto.path = [(0, 0), None, (1, 1), ("bad", object())]
    with patch("farm_sim.core.autopilot.glVertex3f") as gv, \
         patch("farm_sim.core.autopilot.glBegin"), \
         patch("farm_sim.core.autopilot.glEnd"):
        with pytest.raises(TypeError):
            auto.draw()


# -------------------------
# ADDITIONAL EDGE / OBSTACLE TESTS
# -------------------------
def test_distance_sq_to_segment_zero_length():
    a = AutoPilot(10, 10)
    d2, t = a._distance_sq_to_segment((0, 0), (1, 1), (1, 1))
    assert isinstance(d2, (int, float)) and isinstance(t, (int, float))
    assert d2 >= 0.0
    assert t == 0.0


def test_project_to_circle_center_case(auto):
    centre = (0.0, 0.0)
    point = (0.0, 0.0)
    radius = 2.0
    p = auto._project_to_circle(point, centre, radius)
    assert isinstance(p, tuple) and len(p) == 2


def test_arc_around_min_span_and_direction():
    a = AutoPilot(20, 20)
    centre = (0.0, 0.0)
    entry = (1.0, 0.0)
    exit = (math.cos(0.01), math.sin(0.01))
    arc_pos = a._arc_around(centre, entry, exit, radius=1.0, direction=1)
    arc_neg = a._arc_around(centre, entry, exit, radius=1.0, direction=-1)
    assert isinstance(arc_pos, list) and isinstance(arc_neg, list)
    assert len(arc_pos) >= 6 and len(arc_neg) >= 6


def test_preferred_side_prefers_one_side(auto):
    entry = (0.0, 0.0)
    exit = (1.0, 0.0)
    side_vec = (0.2, 0.0)
    preferred = auto._preferred_side(entry, exit, side_vec)
    assert isinstance(preferred, tuple) and len(preferred) == 2


def test_ensure_path_within_bounds_duplicates_removed():
    a = AutoPilot(10, 10)
    raw = [(-100.0, -100.0), (-100.0, -100.0), (0.0, 0.0), (0.0, 0.0), (5.0, 5.0)]
    clamped = a._ensure_path_within_bounds(raw)
    assert isinstance(clamped, list)
    assert len(clamped) <= len(raw)


def test_reroute_segment_depth_limit(auto):
    start = (0.0, 0.0)
    end = (10.0, 0.0)
    out = auto._reroute_segment(start, end, obstacles=(), depth=auto.MAX_DETOUR_DEPTH + 1)
    assert out == [end]


def test_first_blocker_and_avoid_obstacles_simple():
    a = AutoPilot(30, 30)
    start = (0.0, 0.0)
    end = (10.0, 0.0)
    obs = DummyObstacle(5.0, 0.0, kind="rock", scale=1.0, size="medium")
    blk = a._first_blocker(start, end, (obs,))
    assert (blk is None) or (isinstance(blk, tuple) and len(blk) == 3)


def test_construct_detour_and_routing_pipeline():
    a = AutoPilot(50, 50)
    start = (0.0, 0.0)
    end = (10.0, 0.0)
    obs = DummyObstacle(5.0, 0.0, kind="pond", scale=1.0, size="medium")
    pts = a._construct_detour(start, end, obs, t_hit=0.5, clearance=1.0)
    assert isinstance(pts, list)
    if pts:
        assert all(isinstance(p, tuple) and len(p) == 2 for p in pts)


def test_avoid_obstacles_integration_small():
    a = AutoPilot(20, 20)
    raw = [(0.0, 0.0), (10.0, 0.0)]
    obs = DummyObstacle(5.0, 0.0, kind="rock", scale=1.0, size="medium")
    carved = a._avoid_obstacles(raw, (obs,))
    assert isinstance(carved, list)
    assert carved and carved[0] == raw[0]


def test_distance_sq_tuple_and_helpers():
    a = AutoPilot(10, 10)
    assert a._distance_sq_tuple((0, 0), (3, 4)) == 25.0
    d2, t = a._distance_sq_to_segment((1, 1), (0, 0), (0, 0))
    assert isinstance(d2, (int, float)) and isinstance(t, (int, float))


# -------------------------
# EXTRA CONTROL / EDGE CASES
# -------------------------
def test_control_with_nonstandard_forward_vec(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[0]
    tractor.yaw = math.pi / 2
    tractor.WHEELBASE = 1.2
    tractor.MAX_STEER = 0.3
    tractor.v = 1.0
    tractor.forward_vec.return_value = (1, 0)
    t, b, s = auto.control(tractor, dt=0.05)
    assert isinstance(t, bool)
    assert isinstance(b, bool)
    assert isinstance(s, float)


def test_control_high_speed_and_idx_adjust(auto):
    auto.build_path()
    tractor = MagicMock()
    tractor.x, tractor.z = auto.path[-2]
    tractor.yaw = 0.0
    tractor.WHEELBASE = 2.5
    tractor.MAX_STEER = 0.8
    tractor.v = 10.0
    tractor.forward_vec.return_value = (0, -1)
    res = auto.control(tractor, dt=0.2)
    assert isinstance(res, tuple)
    assert 0 <= auto.idx < max(1, len(auto.path))


def test_draw_with_many_segments_calls_vertex_many_times(auto):
    auto.show_path = True
    auto.path = [(i, i * 0.2) for i in range(200)]
    with patch("farm_sim.core.autopilot.glVertex3f") as gv, \
         patch("farm_sim.core.autopilot.glBegin"), \
         patch("farm_sim.core.autopilot.glEnd"):
        auto.draw()
        assert gv.call_count == len(auto.path)
