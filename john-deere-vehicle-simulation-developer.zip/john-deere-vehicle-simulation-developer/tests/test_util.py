import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from farm_sim.util import clamp, lerp

class TestUtil(unittest.TestCase):
    
    def test_clamp(self):
        """Test clamp function"""
        self.assertEqual(clamp(5, 0, 10), 5)
        self.assertEqual(clamp(-5, 0, 10), 0)
        self.assertEqual(clamp(15, 0, 10), 10)
        self.assertEqual(clamp(0, 0, 10), 0)
        self.assertEqual(clamp(10, 0, 10), 10)
    
    def test_lerp(self):
        """Test lerp function"""
        self.assertEqual(lerp(0, 10, 0.5), 5.0)
        self.assertEqual(lerp(0, 10, 0), 0)
        self.assertEqual(lerp(0, 10, 1), 10)
        self.assertEqual(lerp(5, 15, 0.5), 10.0)

if __name__ == '__main__':
    unittest.main()