# tests/run_file_service_tests.py
import sys
from pathlib import Path
import importlib
import traceback

# ensure repo root is on sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# import module under test
try:
    fs_mod = importlib.import_module("operations_center.file_service")
except Exception:
    print("ERROR: could not import operations_center.file_service")
    traceback.print_exc()
    sys.exit(2)

from farm_sim.config import ORG_ID

# --- FakeResponse and DummyRequests (same behavior as pytest tests) ---
class FakeResponse:
    def __init__(self, status_code=200, json_obj=None, headers=None, text=""):
        self.status_code = status_code
        self._json = json_obj if json_obj is not None else {}
        self.headers = headers or {}
        self.text = text

    def json(self):
        return self._json

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}: {self.text or self._json}")

class DummyRequests:
    def __init__(self, mapping_or_responder):
        self._map = mapping_or_responder

    def _resolve(self, url, **kwargs):
        if callable(self._map):
            return self._map(url, **kwargs)
        if url in self._map:
            return self._map[url]
        base = url.split("?", 1)[0]
        if base in self._map:
            return self._map[base]
        raise AssertionError(f"No fake mapping for URL: {url}")

    def get(self, url, headers=None, timeout=None):
        return self._resolve(url, method="GET", headers=headers, timeout=timeout)

    def post(self, url, headers=None, json=None, data=None, timeout=None):
        return self._resolve(url, method="POST", headers=headers, json=json, data=data, timeout=timeout)

    def put(self, url, headers=None, data=None, timeout=None):
        return self._resolve(url, method="PUT", headers=headers, data=data, timeout=timeout)

# helper to set deterministic auth header on module
def patch_auth_header():
    setattr(fs_mod, "auth_header", lambda: {"Authorization": "Bearer test-token"})

# tiny test runner
def run_test(name, fn):
    try:
        fn()
    except AssertionError as e:
        print(f"[FAIL] {name}: AssertionError: {e}")
        return False
    except Exception as e:
        print(f"[ERROR] {name}: Exception:")
        traceback.print_exc()
        return False
    else:
        print(f"[ OK ] {name}")
        return True

# --- Tests (translated from pytest) ---

def test_create_file_success():
    patch_auth_header()
    created_id = "file-abc-123"
    location = f"https://sandboxapi.deere.com/platform/files/{created_id}"
    fake_resp = FakeResponse(201, json_obj={"id": created_id}, headers={"Location": location})
    expected_url = fs_mod.BASE_URL + f"/organizations/{ORG_ID}/files"
    setattr(fs_mod, "requests", DummyRequests({expected_url: fake_resp}))
    file_name = "telemetry.json"
    fid = fs_mod.create_file(ORG_ID, file_name)
    assert fid == created_id, f"expected {created_id}, got {fid}"

def test_create_file_raises_on_error():
    patch_auth_header()
    fake_resp = FakeResponse(400, json_obj={"error": "bad"}, text="bad request")
    expected_url = fs_mod.BASE_URL + f"/organizations/{ORG_ID}/files"
    setattr(fs_mod, "requests", DummyRequests({expected_url: fake_resp}))
    try:
        fs_mod.create_file(ORG_ID, "name")
    except RuntimeError:
        return
    raise AssertionError("create_file did not raise on 400")

def test_upload_file_success(tmp_path=None):
    import tempfile
    tf = None
    if tmp_path is None:
        tf = tempfile.NamedTemporaryFile(delete=False)
        tf.write(b"hello world")
        tf.flush()
        tf_path = tf.name
        tf.close()
    else:
        p = tmp_path / "payload.bin"
        p.write_bytes(b"hello world")
        tf_path = str(p)

    patch_auth_header()
    file_id = "upload-xyz"
    expected_url = fs_mod.BASE_URL + f"/files/{file_id}"

    def responder(url, method=None, headers=None, data=None, timeout=None, **kw):
        assert url == expected_url
        assert "Authorization" in headers
        if hasattr(data, "read"):
            pos = None
            try:
                pos = data.tell()
            except Exception:
                pos = None
            read_bytes = data.read()
            assert read_bytes == b"hello world"
            try:
                if pos is not None:
                    data.seek(pos)
            except Exception:
                pass
        return FakeResponse(200, json_obj={"status": "ok"})

    setattr(fs_mod, "requests", DummyRequests(responder))
    fs_mod.upload_file(file_id, tf_path)

    if tf is not None:
        try:
            import os
            os.unlink(tf_path)
        except Exception:
            pass

def test_upload_file_raises_on_put_error():
    import tempfile, os
    tf = tempfile.NamedTemporaryFile(delete=False)
    tf.write(b"data")
    tf.flush()
    tf_path = tf.name
    tf.close()

    patch_auth_header()
    file_id = "upload-bad"
    expected_url = fs_mod.BASE_URL + f"/files/{file_id}"

    def responder(url, method=None, headers=None, data=None, timeout=None, **kw):
        return FakeResponse(500, text="server error")

    setattr(fs_mod, "requests", DummyRequests(responder))
    try:
        fs_mod.upload_file(file_id, tf_path)
    except RuntimeError:
        os.unlink(tf_path)
        return
    finally:
        if os.path.exists(tf_path):
            os.unlink(tf_path)
    raise AssertionError("upload_file did not raise on 500")

def test_get_file_success():
    patch_auth_header()
    file_id = "meta-1"
    expected_url = fs_mod.BASE_URL + f"/files/{file_id}"
    payload = {"id": file_id, "status": "available"}
    setattr(fs_mod, "requests", DummyRequests({expected_url: FakeResponse(200, json_obj=payload)}))
    out = fs_mod.get_file(file_id)
    assert out == payload

def test_get_file_handles_non_200():
    patch_auth_header()
    file_id = "meta-404"
    expected_url = fs_mod.BASE_URL + f"/files/{file_id}"
    setattr(fs_mod, "requests", DummyRequests({expected_url: FakeResponse(404, text="not found")}))
    try:
        fs_mod.get_file(file_id)
    except RuntimeError:
        return
    raise AssertionError("get_file did not raise on 404")

# -- run all tests -------------------------------------------------------------
tests = [
    test_create_file_success,
    test_create_file_raises_on_error,
    test_upload_file_success,
    test_upload_file_raises_on_put_error,
    test_get_file_success,
    test_get_file_handles_non_200,
]

def main():
    ok = True
    for t in tests:
        name = t.__name__
        if name == "test_upload_file_success":
            import tempfile, pathlib
            tmpdir = Path(tempfile.mkdtemp())
            result = run_test(name, lambda: t(tmpdir))
        else:
            result = run_test(name, t)
        ok = ok and result
    if not ok:
        print("\nSOME TESTS FAILED")
        sys.exit(1)
    print("\nALL TESTS PASSED")
    sys.exit(0)

if __name__ == "__main__":
    main()
