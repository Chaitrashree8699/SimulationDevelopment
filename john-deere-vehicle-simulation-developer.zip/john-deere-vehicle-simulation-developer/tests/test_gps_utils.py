# tests/test_gps_utils_full.py
import json
import os
from types import SimpleNamespace
import pytest

import farm_sim.gps_utils as gps_mod
from farm_sim.config import ORG_ID

# -------------------------------------------------------------------
# Fake HTTP helper (longest-key matching to avoid short-key collisions)
# -------------------------------------------------------------------
class FakeResponse:
    def __init__(self, status_code=200, data=None, text=""):
        self.status_code = status_code
        self._data = data or {}
        self.text = text
        self.headers = {"content-type": "application/json"}

    def json(self):
        return self._data

class DummyRequestsModule:
    """Fake requests.get that matches the most specific (longest) key first."""
    def __init__(self, responses=None):
        self._responses = responses or {}

    def get(self, url, headers=None):
        best_key = None
        best_len = -1
        for k in self._responses.keys():
            if k in url and len(k) > best_len:
                best_key = k
                best_len = len(k)
        if best_key is not None:
            return self._responses[best_key]
        return FakeResponse(status_code=404, data={}, text="not found")

ORG_PATH = f"/platform/organizations/{ORG_ID}"
ORG_ID_STR = str(ORG_ID)


# -------------------------------------------------------------------
# CoordinateConverter tests
# -------------------------------------------------------------------
def test_coordinate_converter_basic_roundtrip():
    c = gps_mod.CoordinateConverter(42.03, -93.63)
    lat, lon = 42.0310, -93.6300
    x, z = c.gps_to_local(lat, lon)
    lat2, lon2 = c.local_to_gps(x, z)
    assert pytest.approx(lat, rel=1e-6) == lat2
    assert pytest.approx(lon, rel=1e-6) == lon2

def test_coordinate_converter_different_center():
    c = gps_mod.CoordinateConverter(0.0, 0.0)
    lat, lon = 0.001, 0.002
    x, z = c.gps_to_local(lat, lon)
    assert isinstance(x, float) and isinstance(z, float)
    lat2, lon2 = c.local_to_gps(x, z)
    assert pytest.approx(lat, rel=1e-6) == lat2
    assert pytest.approx(lon, rel=1e-6) == lon2

def test_gps_boundary_to_local_list_conversion():
    pts = gps_mod.SAMPLE_GPS_BOUNDARY
    c = gps_mod.CoordinateConverter(42.03115, -93.63085)
    local = c.gps_boundary_to_local(pts)
    assert isinstance(local, list)
    assert len(local) == len(pts)
    assert all(isinstance(p, tuple) and len(p) == 2 for p in local)


# -------------------------------------------------------------------
# create_field_from_gps tests
# -------------------------------------------------------------------
def test_create_field_from_gps_empty_returns_defaults():
    w, h, conv = gps_mod.create_field_from_gps([])
    assert isinstance(w, float) and isinstance(h, float)
    assert conv is None

def test_create_field_from_gps_computes_dimensions():
    bz = gps_mod.SAMPLE_GPS_BOUNDARY
    w, h, conv = gps_mod.create_field_from_gps(bz)
    assert w > 0.0 and h > 0.0
    assert isinstance(conv, gps_mod.CoordinateConverter)


# -------------------------------------------------------------------
# Basic module-level sanity test (keeps parity with earlier helper)
# -------------------------------------------------------------------
def test_gps_utils_smoke():
    # Simple smoke test that the module helper runs without crashing
    assert gps_mod.test_gps_utils() in (True, False)


# -------------------------------------------------------------------
# JohnDeereAPI unit tests (mocked)
# -------------------------------------------------------------------
def test_get_organizations_success_and_fields_success(monkeypatch):
    orgs_payload = {"values": [{"id": ORG_PATH, "name": "Personal"}]}
    fields_payload = {"values": [
        {"id": "/platform/fields/42", "name": "Field Alpha", "area": {"value": 3.3}}
    ]}
    fake = DummyRequestsModule({
        f"{ORG_PATH}/fields": FakeResponse(200, fields_payload),
        "/platform/organizations": FakeResponse(200, orgs_payload),
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    orgs = api.get_organizations()
    assert isinstance(orgs, list) and len(orgs) == 1

    fields = api.get_fields(ORG_ID_STR)
    assert isinstance(fields, list) and len(fields) == 1
    assert fields[0]["name"] == "Field Alpha"

    all_fields = api.list_available_fields()
    assert isinstance(all_fields, list)
    assert any("Field Alpha" in (f.get("field_name") or "") or str(f.get("field_id","")).endswith("42") for f in all_fields)


def test_get_organizations_non200_returns_none(monkeypatch):
    fake = DummyRequestsModule({
        "/platform/organizations": FakeResponse(500, {"error": "oops"}, text="oops")
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    assert api.get_organizations() is None


def test_get_fields_non200_returns_none(monkeypatch):
    fake = DummyRequestsModule({
        "/platform/organizations/999/fields": FakeResponse(403, {"error": "forbidden"}, text="forbidden")
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    assert api.get_fields("999") is None


def test_get_field_boundaries_sample_ids_return_list(monkeypatch):
    # sample ids are implemented in module and should return lists regardless of requests availability
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    api = gps_mod.JohnDeereAPI("token")
    for sid in ("sample_field_1", "sample_field_2", "sample_field_3"):
        b = api.get_field_boundaries(sid)
        assert isinstance(b, list) and len(b) >= 4


def test_get_field_boundaries_http_geojson_parsing(monkeypatch):
    geojson = {
        "values": [
            {
                "geometry": {
                    "coordinates": [
                        [
                            [-93.6300, 42.0300],
                            [-93.6310, 42.0305],
                            [-93.6305, 42.0310],
                            [-93.6300, 42.0300],
                        ]
                    ]
                }
            }
        ]
    }
    fake = DummyRequestsModule({
        "/platform/fields/myfield/boundaries": FakeResponse(200, geojson)
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    out = api.get_field_boundaries("myfield")
    assert isinstance(out, list)
    assert all(isinstance(pt, tuple) and len(pt) == 2 for pt in out)


def test_get_field_boundaries_http_non200_returns_none(monkeypatch):
    fake = DummyRequestsModule({
        "/platform/fields/none/boundaries": FakeResponse(404, {}, text="not found")
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    assert api.get_field_boundaries("none") is None


# -------------------------------------------------------------------
# list_available_fields fallback behavior and combinations
# -------------------------------------------------------------------
def test_list_available_fields_returns_sample_when_no_fields_for_org(monkeypatch):
    orgs_payload = {"values": [{"id": ORG_PATH, "name": "Personal"}]}
    fake = DummyRequestsModule({
        "/platform/organizations": FakeResponse(200, orgs_payload),
        f"{ORG_PATH}/fields": FakeResponse(200, {"values": []})
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    out = api.list_available_fields()
    assert isinstance(out, list)
    assert any(sf for sf in out if str(sf.get("field_id", "")).startswith("sample_field"))


def test_list_available_fields_returns_empty_when_no_orgs(monkeypatch):
    # If get_organizations returns empty array -> list_available_fields returns [] in current impl
    fake = DummyRequestsModule({"platform/organizations": FakeResponse(200, {"values": []})})
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    api = gps_mod.JohnDeereAPI("token")
    monkeypatch.setattr(api, "get_organizations", lambda: [])
    out = api.list_available_fields()
    assert out == []


# -------------------------------------------------------------------
# "helper" API printing wrappers to exercise code paths
# -------------------------------------------------------------------
def test_test_organizations_api_and_return(monkeypatch):
    # Fake a normal org+fields response; the function prints and returns the organizations list
    orgs_payload = {"values": [{"id": ORG_PATH, "name": "Personal", "type": "personal"}]}
    fields_payload = {"values": [
        {"id": "/platform/fields/1", "name": "F1", "area": {"value": 11.1}},
        {"id": "/platform/fields/2", "name": "F2", "area": {"value": 22.2}}
    ]}
    fake = DummyRequestsModule({
        f"{ORG_PATH}/fields": FakeResponse(200, fields_payload),
        "/platform/organizations": FakeResponse(200, orgs_payload),
    })
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", True)
    monkeypatch.setattr(gps_mod, "requests", fake)

    out = gps_mod.test_organizations_api("token")
    assert isinstance(out, (list, type(None)))


def test_test_john_deere_api_wrapper(monkeypatch):
    monkeypatch.setattr(gps_mod, "test_organizations_api", lambda token: ["mock"])
    out = gps_mod.test_john_deere_api("dummy")
    assert out == ["mock"]


# -------------------------------------------------------------------
# load_credentials file handling
# -------------------------------------------------------------------
def test_load_credentials_reads_file(tmp_path):
    cfg = {"access_token": "abc-123"}
    p = tmp_path / "jd_credentials.json"
    p.write_text(json.dumps(cfg))
    cwd = os.getcwd()
    try:
        os.chdir(tmp_path)
        got = gps_mod.load_credentials()
        assert got == cfg
    finally:
        os.chdir(cwd)


# -------------------------------------------------------------------
# When requests missing: safe behavior tests
# -------------------------------------------------------------------
def test_api_behavior_when_requests_missing(monkeypatch):
    monkeypatch.setattr(gps_mod, "HAS_REQUESTS", False)
    api = gps_mod.JohnDeereAPI("token")
    # Should not raise; returns None for REST calls
    assert api.get_organizations() is None
    assert api.get_fields("x") is None
    # Behavior: when HAS_REQUESTS is False the module may return None for network-bound functions.
    # Accept either None (no requests available) or list (if implementation provides samples even with HAS_REQUESTS False).
    out = api.get_field_boundaries("sample_field_1")
    assert out is None or isinstance(out, list)


# -------------------------------------------------------------------
# Extra combinational sanity checks
# -------------------------------------------------------------------
def test_coordinate_converter_and_field_creation_roundtrip():
    # make a synthetic square GPS polygon, then create field and convert back
    poly = [
        (42.0, -93.0),
        (42.001, -93.0),
        (42.001, -92.999),
        (42.0, -92.999),
        (42.0, -93.0)
    ]
    w, h, conv = gps_mod.create_field_from_gps(poly)
    assert w > 0 and h > 0
    local = conv.gps_boundary_to_local(poly)
    assert isinstance(local, list)
