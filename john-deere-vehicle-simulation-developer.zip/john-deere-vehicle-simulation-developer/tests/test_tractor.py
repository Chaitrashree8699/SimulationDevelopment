import math
import types
import sys
import pytest

import farm_sim.entities.tractor as tractor_mod
from farm_sim.entities.tractor import (
    Tractor, TractorSpec, TRACTOR_SPECS, TRACTOR_SPEC_BY_KEY,
    resolve_spec, get_tractor_spec, all_tractor_specs
)


def test_specs_mapping_and_default():
    assert isinstance(TRACTOR_SPECS, list) and len(TRACTOR_SPECS) >= 1
    assert isinstance(TRACTOR_SPEC_BY_KEY, dict)
    for spec in TRACTOR_SPECS:
        assert spec.key in TRACTOR_SPEC_BY_KEY
        assert TRACTOR_SPEC_BY_KEY[spec.key] is spec

    default_key = tractor_mod.DEFAULT_TRACTOR_KEY
    assert default_key in TRACTOR_SPEC_BY_KEY
    assert isinstance(TRACTOR_SPEC_BY_KEY[default_key], TractorSpec)


def test_resolve_spec_variants():
    key = TRACTOR_SPECS[0].key
    s = resolve_spec(key)
    assert isinstance(s, TractorSpec)
    assert s.key == key

    inst = TRACTOR_SPECS[1]
    s2 = resolve_spec(inst)
    assert s2 is inst

    s3 = resolve_spec(None)
    assert isinstance(s3, TractorSpec)
    assert s3.key == tractor_mod.DEFAULT_TRACTOR_KEY

    assert get_tractor_spec(None).key == tractor_mod.DEFAULT_TRACTOR_KEY
    all_specs = all_tractor_specs()
    assert isinstance(all_specs, list)
    assert len(all_specs) == len(TRACTOR_SPECS)


def test_tractor_spec_min_turn_radius_infinite_for_tiny_steer():
    tiny_spec = TractorSpec(key="t", name="tiny", max_steer_deg=1e-5)
    assert math.isinf(tiny_spec.min_turn_radius)


@pytest.mark.parametrize("yaw", [0.0, math.pi/2, math.pi, -math.pi/4])
def test_forward_vec_matches_yaw_math(yaw):
    t = Tractor()
    t.yaw = yaw
    fx, fz = t.forward_vec()
    assert fx == pytest.approx(math.sin(yaw), rel=1e-7, abs=1e-9)
    assert fz == pytest.approx(-math.cos(yaw), rel=1e-7, abs=1e-9)


def _inject_fake_pygame(monkeypatch):
    fake = types.ModuleType("pygame")
    fake.K_w = 101
    fake.K_s = 102
    fake.K_a = 103
    fake.K_d = 104
    fake.locals = {}
    monkeypatch.setitem(sys.modules, "pygame", fake)
    return fake


def test_update_throttle_increases_velocity(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = 0.0
    keys = {fake.K_w: True, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    t.update(dt=0.1, keys=keys, _field_limit_unused=None)
    assert t.v > 0.0


def test_update_brake_decreases_velocity(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = 5.0
    keys = {fake.K_w: False, fake.K_s: True, fake.K_a: False, fake.K_d: False}
    t.update(dt=0.1, keys=keys, _field_limit_unused=None)
    assert t.v < 5.0


def test_steering_input_and_self_centering(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.steer = 0.0

    keys_left = {fake.K_w: False, fake.K_s: False, fake.K_a: True, fake.K_d: False}
    t.update(dt=0.05, keys=keys_left, _field_limit_unused=None)
    assert t.steer < 0.0

    t.steer = 0.5
    keys_none = {fake.K_w: False, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    t.update(dt=0.1, keys=keys_none, _field_limit_unused=None)
    assert abs(t.steer) < 0.5


def test_steer_clamping_respects_max(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    spec = TractorSpec(key="s", name="s", max_steer_deg=1.0, steer_rate_deg=1000.0)
    monkeypatch.setitem(tractor_mod.TRACTOR_SPEC_BY_KEY, "tmp_test", spec)
    t = Tractor(spec="tmp_test")
    fake_keys = {fake.K_w: False, fake.K_s: False, fake.K_a: True, fake.K_d: False}
    t.update(dt=0.5, keys=fake_keys, _field_limit_unused=None)
    assert abs(t.steer) <= t.MAX_STEER + 1e-9


def test_wheel_spin_updates_and_speed_property(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = 2.0
    initial_rear = t.rear_spin
    initial_front = t.front_spin

    keys_none = {fake.K_w: False, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    dt = 0.05
    t.update(dt=dt, keys=keys_none, _field_limit_unused=None)

    expected_rear_inc = (t.v / max(t.REAR_R, 1e-3)) * (180.0 / math.pi) * dt
    expected_front_inc = (t.v / max(t.FRONT_R, 1e-3)) * (180.0 / math.pi) * dt

    delta_rear = (t.rear_spin - initial_rear) % 360.0
    delta_front = (t.front_spin - initial_front) % 360.0
    assert delta_rear == pytest.approx(expected_rear_inc, rel=1e-1, abs=2.0)
    assert delta_front == pytest.approx(expected_front_inc, rel=1e-1, abs=2.0)
    assert t.speed == pytest.approx(t.v)


def test_truck_attributes_types_and_ranges():
    t = Tractor()
    for attr in ("WHEELBASE", "REAR_R", "FRONT_R", "MAX_ACCEL", "MAX_BRAKE", "DRAG_K", "ROLL_K", "MAX_REV"):
        val = getattr(t, attr)
        assert isinstance(val, float)

    assert 1.0 < t.WHEELBASE < 4.0
    assert 0.05 < t.REAR_R < 1.0
    assert 0.05 < t.FRONT_R < 1.0
    assert -20.0 < t.MAX_REV < 0.0


# ---------------- Additional focused tests ----------------

def test_max_rev_clamp_after_update(monkeypatch):
    """Use modest negative velocity so clamp triggers without drag flip."""
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = t.MAX_REV - 1.0  # slightly below MAX_REV
    keys = {fake.K_w: False, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    t.update(dt=0.01, keys=keys, _field_limit_unused=None)
    assert t.v == pytest.approx(t.MAX_REV)


def test_negative_velocity_roll_sign_and_brake_branch(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = -2.0
    keys = {fake.K_w: False, fake.K_s: True, fake.K_a: False, fake.K_d: False}
    yaw_before = t.yaw
    t.update(dt=0.05, keys=keys, _field_limit_unused=None)
    assert t.v <= 0.0
    assert isinstance(t.yaw, float)


def test_yaw_update_with_steer_and_velocity(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = 3.0
    t.steer = 0.2
    yaw_before = t.yaw
    keys = {fake.K_w: False, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    t.update(dt=0.1, keys=keys, _field_limit_unused=None)
    assert t.yaw != pytest.approx(yaw_before)


def test_steer_self_center_crosses_zero(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.steer = 0.01
    keys = {fake.K_w: False, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    t.update(dt=1.0, keys=keys, _field_limit_unused=None)
    assert t.steer == pytest.approx(0.0)


def test_wheel_spin_wraparound_increases_mod_360(monkeypatch):
    fake = _inject_fake_pygame(monkeypatch)
    t = Tractor()
    t.v = 200.0
    initial_rear = t.rear_spin
    initial_front = t.front_spin
    keys_none = {fake.K_w: False, fake.K_s: False, fake.K_a: False, fake.K_d: False}
    t.update(dt=0.2, keys=keys_none, _field_limit_unused=None)
    delta_rear = (t.rear_spin - initial_rear) % 360.0
    delta_front = (t.front_spin - initial_front) % 360.0
    assert delta_rear > 0.0
    assert delta_front > 0.0
