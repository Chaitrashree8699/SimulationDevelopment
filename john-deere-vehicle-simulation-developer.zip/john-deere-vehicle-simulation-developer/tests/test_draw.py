# tests/test_draw.py
import pytest
import farm_sim.render.draw as draw_mod
from types import SimpleNamespace

@pytest.fixture(autouse=True)
def mock_opengl(monkeypatch):
    """
    Stub OpenGL calls so tests never open a context.
    Each stub records its name into a shared list and returns harmless defaults.
    Uses raising=False so attributes are created if missing.
    """
    called = []

    def fake(name, ret=None):
        def _inner(*a, **kw):
            called.append(name)
            return ret
        return _inner

    # GL functions to stub (add more if other GLError traces appear)
    gl_fns = [
        "glBegin", "glEnd", "glNormal3f", "glVertex3f", "glRotatef",
        "glTranslatef", "glPushMatrix", "glPopMatrix", "glMaterialfv",
        "glColor4f", "glLineWidth", "glScalef", "glEnable", "glDisable",
        "glIsEnabled", "glPushAttrib", "glPopAttrib",
        "glVertexPointer", "glDrawArrays", "glTexCoord2f", "glBindTexture",
        "glTexParameteri", "glTexImage2D", "glDeleteTextures",
        "glPolygonMode",  # stub polygon mode (used by pond drawer)
    ]

    for fn in gl_fns:
        if fn == "glIsEnabled":
            monkeypatch.setattr(draw_mod, fn, fake(fn, ret=False), raising=False)
        else:
            monkeypatch.setattr(draw_mod, fn, fake(fn, ret=None), raising=False)

    # Provide safe fallback GL constants (create them on module if missing)
    gl_constants = {
        "GL_LIGHTING": 0x0B50,
        "GL_TRIANGLES": 0x0004,
        "GL_QUADS": 0x0007,
        "GL_LINES": 0x0001,
        "GL_POLYGON_BIT": 0x0002,
        "GL_POLYGON": 0x0009,
        "GL_TEXTURE_2D": 0x0DE1,
        "GL_RGBA": 0x1908,
        "GL_UNSIGNED_BYTE": 0x1401,
        "GL_LINEAR": 0x2601,
        "GL_TEXTURE_MIN_FILTER": 0x2801,
        "GL_TEXTURE_MAG_FILTER": 0x2800,
        "GL_FRONT_AND_BACK": 0x0408,
        "GL_FILL": 0x1B02,
    }
    for const_name, const_val in gl_constants.items():
        if not hasattr(draw_mod, const_name):
            setattr(draw_mod, const_name, const_val)

    # deterministic math for predictable loops
    monkeypatch.setattr(draw_mod.math, "cos", lambda x: 1.0, raising=False)
    monkeypatch.setattr(draw_mod.math, "sin", lambda x: 0.0, raising=False)
    monkeypatch.setattr(draw_mod, "clamp", lambda v, lo, hi: max(lo, min(v, hi)), raising=False)

    return called


# ---------- Core primitive tests ----------

def test_draw_cube_invokes_expected_sequence(monkeypatch):
    called = []
    monkeypatch.setattr(draw_mod, "glBegin", lambda m=None: called.append("begin"), raising=False)
    monkeypatch.setattr(draw_mod, "glEnd", lambda: called.append("end"), raising=False)
    monkeypatch.setattr(draw_mod, "glVertex3f", lambda *a: called.append("vertex"), raising=False)
    monkeypatch.setattr(draw_mod, "glNormal3f", lambda *a: called.append("normal"), raising=False)

    draw_mod.draw_cube(1, 1, 1)
    assert "begin" in called
    assert "end" in called
    assert called.count("vertex") > 0
    assert called.count("normal") > 0


def test_draw_cylinder_has_three_sections(monkeypatch):
    called = []
    monkeypatch.setattr(draw_mod, "glBegin", lambda m=None: called.append("begin"), raising=False)
    monkeypatch.setattr(draw_mod, "glEnd", lambda: called.append("end"), raising=False)
    monkeypatch.setattr(draw_mod, "glVertex3f", lambda *a: None, raising=False)
    monkeypatch.setattr(draw_mod, "glNormal3f", lambda *a: None, raising=False)

    draw_mod.draw_cylinder(1, 2, 8)
    assert called.count("begin") == 3
    assert called.count("end") == 3


def test_set_material_color_invokes_gl_calls(monkeypatch):
    called = {}
    monkeypatch.setattr(draw_mod, "glColor4f", lambda *a, **kw: called.__setitem__("color", True), raising=False)
    monkeypatch.setattr(draw_mod, "glMaterialfv", lambda *a, **kw: called.__setitem__("material", True), raising=False)
    draw_mod._set_material_color(0.1, 0.2, 0.3, 0.4)
    assert "color" in called and "material" in called


# ---------- Wheel and Tractor tests ----------

def test_draw_wheel_push_pop_and_cylinders(monkeypatch):
    counts = {"push": 0, "pop": 0, "cyl": 0}
    monkeypatch.setattr(draw_mod, "glPushMatrix", lambda: counts.__setitem__("push", counts["push"] + 1), raising=False)
    monkeypatch.setattr(draw_mod, "glPopMatrix", lambda: counts.__setitem__("pop", counts["pop"] + 1), raising=False)
    monkeypatch.setattr(draw_mod, "draw_cylinder", lambda **kw: counts.__setitem__("cyl", counts["cyl"] + 1), raising=False)
    monkeypatch.setattr(draw_mod, "glMaterialfv", lambda *a, **kw: None, raising=False)
    monkeypatch.setattr(draw_mod, "glRotatef", lambda *a, **kw: None, raising=False)
    draw_mod.draw_wheel()
    assert counts["push"] == 1
    assert counts["pop"] == 1
    assert counts["cyl"] == 2


def test_draw_tractor_invokes_expected_components(monkeypatch):
    counts = {"cube": 0, "wheel": 0}
    monkeypatch.setattr(draw_mod, "glPushMatrix", lambda: None, raising=False)
    monkeypatch.setattr(draw_mod, "glPopMatrix", lambda: None, raising=False)
    monkeypatch.setattr(draw_mod, "glTranslatef", lambda *a: None, raising=False)
    monkeypatch.setattr(draw_mod, "glRotatef", lambda *a: None, raising=False)
    monkeypatch.setattr(draw_mod, "glMaterialfv", lambda *a, **kw: None, raising=False)
    monkeypatch.setattr(draw_mod, "draw_cube", lambda *a, **kw: counts.__setitem__("cube", counts["cube"] + 1), raising=False)
    monkeypatch.setattr(draw_mod, "draw_wheel", lambda **kw: counts.__setitem__("wheel", counts["wheel"] + 1), raising=False)

    tractor = SimpleNamespace(
        x=0, y=0, z=0, yaw=0, steer=0,
        front_spin=0.0, rear_spin=0.0,
        REAR_R=0.4, FRONT_R=0.3, MAX_STEER=0.5
    )
    draw_mod.draw_tractor_john_deere(tractor)
    assert counts["cube"] >= 4
    assert counts["wheel"] == 4


# ---------- Obstacle helpers ----------

@pytest.mark.parametrize("size,scale,multiplier", [
    ("small", 1.0, 0.8),
    ("medium", 1.5, 1.0),
    ("large", 2.0, 1.2)
])
def test_effective_scale_respects_multiplier(monkeypatch, size, scale, multiplier):
    monkeypatch.setattr(draw_mod, "SIZE_MULTIPLIERS", {"small": 0.8, "medium": 1.0, "large": 1.2}, raising=False)
    obs = SimpleNamespace(size=size, scale=scale)
    eff = draw_mod._effective_scale(obs)
    assert eff == pytest.approx(scale * multiplier)


@pytest.mark.parametrize("kind,funcname", [
    ("tree", "_draw_tree"),
    ("stone", "_draw_stone"),
    ("bush", "_draw_bush"),
    ("pond", "_draw_pond"),
])
def test_draw_obstacles_dispatches_correct_function(monkeypatch, kind, funcname):
    called = {}
    for fn in ["_draw_tree", "_draw_stone", "_draw_bush", "_draw_pond"]:
        monkeypatch.setattr(draw_mod, fn, (lambda name: (lambda obs=None: called.__setitem__(name, True)))(fn), raising=False)

    obs = [SimpleNamespace(kind=kind, size="medium", scale=1.0)]
    draw_mod.draw_obstacles(obs)
    assert funcname in called
    assert sum(1 for v in called.values() if v) == 1


def test_private_drawers_call_gl(monkeypatch):
    """Smoke-test _draw_tree/_draw_stone/_draw_bush/_draw_pond each runs GL commands."""
    for fn in ["_draw_tree", "_draw_stone", "_draw_bush", "_draw_pond"]:
        obs = SimpleNamespace(x=0.0, z=0.0, rotation=0.0, scale=1.0, kind=fn[6:], size="medium")
        getattr(draw_mod, fn)(obs)
        assert True


# ---------- Crop rendering ----------

def test_draw_crop_two_cubes(monkeypatch):
    counts = {"cube": 0}
    monkeypatch.setattr(draw_mod, "draw_cube", lambda *a, **kw: counts.__setitem__("cube", counts["cube"] + 1), raising=False)
    monkeypatch.setattr(draw_mod, "glPushMatrix", lambda: None, raising=False)
    monkeypatch.setattr(draw_mod, "glPopMatrix", lambda: None, raising=False)
    monkeypatch.setattr(draw_mod, "glTranslatef", lambda *a, **kw: None, raising=False)
    monkeypatch.setattr(draw_mod, "glMaterialfv", lambda *a, **kw: None, raising=False)
    crop = SimpleNamespace(x=0.0, z=0.0, harvested=False, growth=lambda now: 0.5)
    draw_mod.draw_crop(crop, now=5.0)
    assert counts["cube"] == 2


def test_draw_crop_skips_when_harvested(monkeypatch):
    counts = {"cube": 0}
    monkeypatch.setattr(draw_mod, "draw_cube", lambda *a, **kw: counts.__setitem__("cube", counts["cube"] + 1), raising=False)
    crop = SimpleNamespace(x=0.0, z=0.0, harvested=True, growth=lambda now: 1.0)
    draw_mod.draw_crop(crop, now=10.0)
    assert counts["cube"] == 0
