# tests/test_game_full.py
import sys
import os
import json
import math
import random
from types import SimpleNamespace
from pathlib import Path
from datetime import datetime

import pytest
from collections.abc import MutableSequence

# make sure repo root is on sys.path (so tests run from different CWDs)
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Import the module-under-test references
import farm_sim.core.game as game_mod
from farm_sim.core.game import Game
import farm_sim.config as cfg

# Some tests use pygame constants; import pygame only where needed
import pygame

# -------------------------
# Minimal helper tractor used across tests
# -------------------------
def make_stub_tractor(x=0.0, z=0.0, yaw=0.0, working_width=2.0):
    """
    Minimal stub of Tractor needed by Game methods used in tests.
    Must provide: x, z, yaw, spec.working_width, forward_vec(), speed, name, MAX_ACCEL, MIN_TURN_RADIUS, MAX_STEER
    """
    spec = SimpleNamespace(working_width=working_width, wheelbase=1.8)
    tr = SimpleNamespace(
        x=x,
        z=z,
        y=0.0,
        yaw=yaw,
        spec=spec,
        speed=0.0,
        name="stub",
        MAX_ACCEL=1.0,
        MIN_TURN_RADIUS=3.0,
        MAX_STEER=0.5,
    )

    def forward_vec():
        return (math.cos(yaw), -math.sin(yaw))

    tr.forward_vec = forward_vec
    # update() should accept (dt, keys, field_limit) — provide no-op
    tr.update = lambda dt, keys, field_limit: None
    return tr

def make_stub_tractor_min(x=0.0, z=0.0, yaw=0.0, working_width=2.0):
    """Smaller variant used by some tests."""
    spec = SimpleNamespace(working_width=working_width, wheelbase=1.2)
    tr = SimpleNamespace(
        x=x, z=z, y=0.0, yaw=yaw,
        spec=spec,
        speed=0.0,
        name="stub",
        MAX_ACCEL=1.23,
        MIN_TURN_RADIUS=1.0,
        MAX_STEER=0.5
    )
    tr.forward_vec = lambda: (math.cos(yaw), -math.sin(yaw))
    tr.update = lambda dt, keys, limit: None
    return tr

# -------------------------
# Tests from earlier unit file (plant/harvest/geometry/config)
# -------------------------
def test_is_in_soil_area_inside_outside():
    g = Game.__new__(Game)
    g.field_w = 20.0
    g.field_h = 10.0

    assert g._is_in_soil_area(0.0, 0.0) is True

    half_w = g.field_w * 0.5
    half_h = g.field_h * 0.5
    soil_margin = 2.0

    inside_x = half_w - soil_margin - 0.5
    assert g._is_in_soil_area(inside_x, 0.0) is True

    outside_x = half_w - soil_margin + 0.5
    assert g._is_in_soil_area(outside_x, 0.0) is False

    assert g._is_in_soil_area(0.0, half_h + 1.0) is False


def test_plant_crop_snaps_to_grid_and_respects_soil_and_duplicates():
    g = Game.__new__(Game)
    g.field_w = 10.0
    g.field_h = 10.0
    tr = make_stub_tractor(x=0.0, z=0.0, yaw=0.0, working_width=2.0)
    g.tractor = tr
    g.crops = []
    g.time = 0.0

    # call plant_crop — should add crops (left/right) snapped to PLANT_SPACING grid
    g.plant_crop()
    assert isinstance(g.crops, list)
    for c in g.crops:
        assert abs(round(c.x / cfg.PLANT_SPACING) * cfg.PLANT_SPACING - c.x) < 1e-6
        assert abs(round(c.z / cfg.PLANT_SPACING) * cfg.PLANT_SPACING - c.z) < 1e-6

    # Now add a crop at same snapped location and ensure duplicates are not created
    g.crops = []
    fx, fz = tr.forward_vec()
    perp_x, perp_z = -fz, fx
    offset = tr.spec.working_width * 0.3
    px = round((tr.x + perp_x * 1 * offset) / cfg.PLANT_SPACING) * cfg.PLANT_SPACING
    pz = round((tr.z + perp_z * 1 * offset) / cfg.PLANT_SPACING) * cfg.PLANT_SPACING
    existing = SimpleNamespace(x=px, z=pz, planted_time=0.0, harvested=False)
    g.crops.append(existing)
    before = len(g.crops)
    g.plant_crop()
    after = len(g.crops)
    assert after == before or after == before + 1


def test_harvest_nearby_marks_and_increments_score():
    g = Game.__new__(Game)
    g.field_w = 20.0
    g.field_h = 20.0
    g.tractor = make_stub_tractor(x=0.0, z=0.0)
    now = 1000.0
    g.time = now

    c1 = SimpleNamespace(
        x=0.5, z=0.5, planted_time=now - (cfg.CROP_GROW_SECONDS * 2),
        harvested=False, sprayed=False,
    )
    c1.growth = lambda now_dt: 1.0

    c2 = SimpleNamespace(
        x=0.2, z=0.2, planted_time=now,
        harvested=False, sprayed=False,
    )
    c2.growth = lambda now_dt: 0.0

    c3 = SimpleNamespace(
        x=100.0, z=100.0, planted_time=now - (cfg.CROP_GROW_SECONDS * 2),
        harvested=False, sprayed=False,
    )
    c3.growth = lambda now_dt: 1.0

    g.crops = [c1, c2, c3]
    g.score = 0
    g.harvest_nearby()

    assert c1.harvested is True
    assert g.score == 1
    assert c2.harvested is False
    assert c3.harvested is False


def test__derive_autopilot_geometry_adjusts_margin_and_lane_spacing():
    g = Game.__new__(Game)
    spec = SimpleNamespace(working_width=1.6, wheelbase=1.2)
    tr = SimpleNamespace(spec=spec, MIN_TURN_RADIUS=1.0)
    g.tractor = tr
    g.field_w = 6.0
    g.field_h = 6.0

    lane_spacing, margin, turn_inset = g._derive_autopilot_geometry()
    assert lane_spacing >= 3.0
    assert margin >= 0.5
    assert turn_inset >= 3.0 or turn_inset >= lane_spacing * 0.5


def test__configure_autopilot_behavior_sets_speeds():
    g = Game.__new__(Game)
    auto = SimpleNamespace(lane_spacing=6.0)
    g.auto = auto
    g.tractor = SimpleNamespace(MAX_ACCEL=2.0)
    g._configure_autopilot_behavior()
    assert hasattr(g.auto, "v_straight")
    assert hasattr(g.auto, "v_turn")
    assert g.auto.v_straight >= 5.0
    assert g.auto.v_turn >= 2.0


# -------------------------
# Tests from the integration-style file (update() plow/sow/spray + geojson)
# -------------------------
def test_update_records_telemetry_and_plow_furrows(tmp_path, monkeypatch):
    g = Game.__new__(Game)
    g.width = 640
    g.height = 480
    g.field_w = 30.0
    g.field_h = 30.0
    g.tractor = make_stub_tractor(x=0.0, z=0.0, yaw=0.0, working_width=3.0)

    # autopilot enabled: return (throttle, brake, steer_target)
    g.auto = SimpleNamespace(enabled=True, control=lambda t, dt, speed_scale, steer_bias: (True, False, 0.0), reached_end=False)

    g.tractor.implement_enabled = True
    # attach implement by string as Game compares str(...) to "ImplementType.PLOW"
    g.tractor.attached_implement = "ImplementType.PLOW"

    num_lines = 3
    g.multi_furrow_points = [[] for _ in range(num_lines)]

    monkeypatch.setenv("LOG_DIR", str(tmp_path))
    monkeypatch.setattr(cfg, "LOG_DIR", str(tmp_path), raising=False)
    monkeypatch.setattr(game_mod, "LOG_DIR", str(tmp_path), raising=False)

    g.trace_data = []
    g.last_log_time = -1000.0
    g.time = 0.0
    g.time_scale = 1.0
    g.skip_implement_frames = 0
    g.speed_scale = 1.0
    g.steer_bias = 0.0

    # attributes normally created in __init__
    g.IMPLEMENT_OFFSET = 1.8
    g.FURROW_SPACING = 0.7
    g.crops = []

    # run update (small dt)
    g.update(0.05)

    # after update we should have at least one trace_data entry (telemetry)
    assert isinstance(g.trace_data, list)
    assert len(g.trace_data) >= 0  # might be 0 if logging interval not reached; primarily ensure no crash

    # plow should have appended to multi_furrow_points (or remained empty but not crash)
    assert isinstance(g.multi_furrow_points, list)


def test_update_records_sowing_and_spray(tmp_path, monkeypatch):
    g = Game.__new__(Game)
    g.width = 640
    g.height = 480
    g.field_w = 30.0
    g.field_h = 30.0
    g.tractor = make_stub_tractor(x=0.0, z=0.0, yaw=0.0, working_width=4.0)

    # SOWER
    g.tractor.implement_enabled = True
    g.tractor.attached_implement = "ImplementType.SOWER"
    g.sowing_points = []
    g.auto = SimpleNamespace(enabled=True, control=lambda t, dt, speed_scale, steer_bias: (True, False, 0.0), reached_end=False)

    monkeypatch.setenv("LOG_DIR", str(tmp_path))
    monkeypatch.setattr(cfg, "LOG_DIR", str(tmp_path), raising=False)
    monkeypatch.setattr(game_mod, "LOG_DIR", str(tmp_path), raising=False)

    g.trace_data = []
    g.last_log_time = -1000.0
    g.time = 0.0
    g.time_scale = 1.0
    g.skip_implement_frames = 0
    g.speed_scale = 1.0
    g.steer_bias = 0.0

    g.IMPLEMENT_OFFSET = 1.8
    g.FURROW_SPACING = 0.7
    g.sowing_points = g.sowing_points
    g.crops = []

    g.update(0.05)
    assert isinstance(g.sowing_points, MutableSequence)

    # SPRAYER
    g.tractor.attached_implement = "ImplementType.SPRAYER"
    g.multi_spray_points = [[] for _ in range(3)]
    g.update(0.05)
    assert isinstance(g.multi_spray_points, list)


def test__create_geojson_export_creates_file(tmp_path, monkeypatch):
    g = Game.__new__(Game)
    g.trace_data = [
        {"sim_time": 0.0, "real_time": "2025-01-01T00:00:00.000", "x": 0.0, "y": 0.0, "z": 0.0, "speed": 0.0},
        {"sim_time": 1.0, "real_time": "2025-01-01T00:00:01.000", "x": 1.0, "y": 0.0, "z": 1.0, "speed": 1.0},
    ]
    g.gps_boundary = getattr(game_mod, "SAMPLE_GPS_BOUNDARY", [(40.0, -90.0), (40.0, -90.001), (40.001, -90.001)])

    monkeypatch.setenv("LOG_DIR", str(tmp_path))
    monkeypatch.setattr(cfg, "LOG_DIR", str(tmp_path), raising=False)
    monkeypatch.setattr(game_mod, "LOG_DIR", str(tmp_path), raising=False)

    # stub CoordinateConverter used inside _create_geojson_export
    import farm_sim.gps_utils as gps_mod

    class FakeConverter:
        def __init__(self, lat, lon):
            pass
        def local_to_gps(self, x, z):
            return (40.0 + x * 1e-6, -90.0 + z * 1e-6)

    monkeypatch.setattr(gps_mod, "CoordinateConverter", FakeConverter, raising=False)

    telemetry_file = tmp_path / "telemetry.json"
    telemetry_file.write_text(json.dumps(g.trace_data))

    ts = "testts"
    g._create_geojson_export(str(telemetry_file), ts)

    out_path = Path(game_mod.LOG_DIR) / f"vehicle_path_{ts}.geojson"
    assert out_path.exists()
    content = json.loads(out_path.read_text())
    assert content.get("type") == "FeatureCollection"
    assert any(f["properties"]["type"] == "boundary" for f in content["features"])


# -------------------------
# Additional coverage tests (from proposed test_game_more.py)
# -------------------------
def test_derive_autopilot_geometry_small_turnradius():
    g = Game.__new__(Game)
    g.tractor = make_stub_tractor_min(working_width=1.0)
    g.field_w = 4.0
    g.field_h = 4.0

    lane_spacing, margin, turn_inset = g._derive_autopilot_geometry()
    assert lane_spacing >= 3.0
    assert margin >= 0.5
    assert turn_inset >= 0.5


def test_derive_autopilot_geometry_large_wheelbase():
    g = Game.__new__(Game)
    spec = SimpleNamespace(working_width=6.0, wheelbase=6.0)
    g.tractor = SimpleNamespace(spec=spec, MIN_TURN_RADIUS=5.0)
    g.field_w = 120.0
    g.field_h = 80.0

    lane_spacing, margin, turn_inset = g._derive_autopilot_geometry()
    assert lane_spacing >= 3.0
    assert margin >= 0.8
    assert turn_inset >= 3.0


def test_configure_autopilot_behavior_uses_MAX_ACCEL():
    g = Game.__new__(Game)
    g.auto = SimpleNamespace(lane_spacing=10.0)
    g.tractor = SimpleNamespace(MAX_ACCEL=5.0)
    g._configure_autopilot_behavior()
    assert hasattr(g.auto, "v_straight")
    assert hasattr(g.auto, "v_turn")
    assert g.auto.v_straight >= 5.0
    assert g.auto.v_turn >= 2.0


def test_refresh_obstacles_builds_path(monkeypatch):
    g = Game.__new__(Game)
    g.field_w = 50.0
    g.field_h = 30.0

    calls = {}
    def fake_build_path(arg):
        calls['path'] = arg

    fake_auto = SimpleNamespace(build_path=fake_build_path, path=['hint'])
    g.auto = fake_auto

    monkeypatch.setattr(game_mod, "generate_obstacles", lambda fw, fh, hint: [{"x":1, "y":2}])
    g.obstacles_enabled = True

    g._refresh_obstacles(initial=False)
    assert isinstance(g.obstacles, list)
    assert calls.get('path') is not None


def test_load_sample_gps_field_monkeypatched(monkeypatch):
    g = Game.__new__(Game)
    sample = [(40.0, -90.0), (40.0, -90.001), (40.001, -90.001)]

    class StubConverter:
        def __init__(self, center_lat, center_lon):
            self.center = (center_lat, center_lon)
        def local_to_gps(self, x, z):
            return (self.center[0] + x*1e-6, self.center[1] + z*1e-6)

    def fake_create_field(boundary):
        return (123.0, 45.0, StubConverter(40.0, -90.0))

    import farm_sim.gps_utils as gps_mod
    monkeypatch.setattr(gps_mod, "SAMPLE_GPS_BOUNDARY", sample, raising=False)
    monkeypatch.setattr(gps_mod, "create_field_from_gps", lambda b: fake_create_field(b), raising=False)

    g.field_w = 1.0
    g.field_h = 1.0
    g.tractor = make_stub_tractor_min()
    g.load_sample_gps_field()
    assert hasattr(g, "gps_converter")
    assert g.field_w > 1.0


def test_create_geojson_export_writes_file(monkeypatch, tmp_path):
    g = Game.__new__(Game)
    g.trace_data = [
        {"sim_time": 0.0, "real_time": "2025-01-01T00:00:00.000", "x": 0.0, "y": 0.0, "z": 0.0, "speed": 0.0},
        {"sim_time": 1.0, "real_time": "2025-01-01T00:00:01.000", "x": 1.0, "y": 0.0, "z": 1.0, "speed": 1.0},
    ]

    g.gps_boundary = [(40.0, -90.0), (40.0, -90.001), (40.001, -90.001)]

    class FakeConverter:
        def __init__(self, lat, lon):
            pass
        def local_to_gps(self, x, z):
            return (40.0 + x * 1e-6, -90.0 + z * 1e-6)

    monkeypatch.setenv("LOG_DIR", str(tmp_path))
    monkeypatch.setattr(cfg, "LOG_DIR", str(tmp_path), raising=False)
    monkeypatch.setattr(game_mod, "LOG_DIR", str(tmp_path), raising=False)

    import farm_sim.gps_utils as gps_mod
    monkeypatch.setattr(gps_mod, "CoordinateConverter", FakeConverter, raising=False)

    telemetry_file = tmp_path / "telemetry.json"
    telemetry_file.write_text(json.dumps(g.trace_data))

    ts = "unit_test_ts"
    g._create_geojson_export(str(telemetry_file), ts)
    out_path = Path(game_mod.LOG_DIR) / f"vehicle_path_{ts}.geojson"
    assert out_path.exists()
    content = json.loads(out_path.read_text())
    assert content.get("type") == "FeatureCollection"
    assert any(f["properties"]["type"] == "boundary" for f in content["features"])


def test_ask_upload_dialog_success(monkeypatch):
    """Test upload dialog when user clicks yes"""
    g = Game.__new__(Game)
    
    # Mock tkinter components
    mock_root = SimpleNamespace()
    mock_root.withdraw = lambda: None
    mock_root.attributes = lambda *args: None
    mock_root.destroy = lambda: None
    
    def mock_tk():
        return mock_root
    
    def mock_messagebox_askyesno(**kwargs):
        return True
    
    monkeypatch.setattr('tkinter.Tk', mock_tk)
    monkeypatch.setattr('tkinter.messagebox.askyesno', mock_messagebox_askyesno)
    
    result = g._ask_upload_dialog()
    assert result is True


def test_ask_upload_dialog_no(monkeypatch):
    """Test upload dialog when user clicks no"""
    g = Game.__new__(Game)
    
    mock_root = SimpleNamespace()
    mock_root.withdraw = lambda: None
    mock_root.attributes = lambda *args: None
    mock_root.destroy = lambda: None
    
    def mock_tk():
        return mock_root
    
    def mock_messagebox_askyesno(**kwargs):
        return False
    
    monkeypatch.setattr('tkinter.Tk', mock_tk)
    monkeypatch.setattr('tkinter.messagebox.askyesno', mock_messagebox_askyesno)
    
    result = g._ask_upload_dialog()
    assert result is False


def test_ask_upload_dialog_exception(monkeypatch):
    """Test upload dialog when tkinter fails"""
    g = Game.__new__(Game)
    
    def mock_tk():
        raise Exception("No display")
    
    monkeypatch.setattr('tkinter.Tk', mock_tk)
    
    result = g._ask_upload_dialog()
    assert result is False


def test_game_initialization_with_john_deere_api(monkeypatch):
    """Test game initialization with John Deere API success"""
    mock_api = SimpleNamespace()
    mock_api.get_field_boundaries = lambda field_id: [(42.0, -93.0), (42.1, -93.0)]
    
    def mock_jd_api(token):
        return mock_api
    
    def mock_create_field(gps_points):
        return (120.0, 90.0, SimpleNamespace())
    
    monkeypatch.setattr(game_mod, 'JohnDeereAPI', mock_jd_api)
    monkeypatch.setattr(game_mod, 'create_field_from_gps', mock_create_field)
    
    # Mock all the pygame/OpenGL initialization
    monkeypatch.setattr('pygame.display.set_caption', lambda x: None)
    monkeypatch.setattr('pygame.display.set_mode', lambda *args, **kwargs: SimpleNamespace())
    monkeypatch.setattr('pygame.time.Clock', lambda: SimpleNamespace())
    monkeypatch.setattr('pygame.font.init', lambda: None)
    monkeypatch.setattr('pygame.font.SysFont', lambda *args: SimpleNamespace(size=lambda x: (10, 10), get_height=lambda: 10))
    
    # Mock OpenGL functions
    import farm_sim.core.game as game_mod_local
    for gl_func in ['glEnable', 'glCullFace', 'glLightfv', 'glClearColor', 'glBlendFunc', 'glMatrixMode', 'glLoadIdentity', 'gluPerspective']:
        monkeypatch.setattr(game_mod_local, gl_func, lambda *args: None)
    
    # Mock other dependencies
    monkeypatch.setattr(game_mod, 'Tractor', lambda x: make_stub_tractor())
    monkeypatch.setattr(game_mod, 'DriverCamera', lambda **kwargs: SimpleNamespace(mode=SimpleNamespace(name='HOOD')))
    monkeypatch.setattr(game_mod, 'AutoPilot', lambda **kwargs: SimpleNamespace(enabled=False, teleport_to_start=lambda x: None, lane_spacing=6.0, build_path=lambda x: None))
    monkeypatch.setattr(game_mod, 'generate_obstacles', lambda *args: [])
    monkeypatch.setattr(game_mod, 'Crop', lambda *args: SimpleNamespace(x=0, z=0, harvested=False))
    
    game = Game(
        800, 600, 50, 50,
        john_deere_token="test_token",
        field_id="test_field_id"
    )
    
    assert game.field_w == 120.0
    assert game.field_h == 90.0
    assert "JD Field" in game.field_map_name


def test_game_initialization_with_failed_john_deere_api(monkeypatch):
    """Test game initialization when John Deere API fails"""
    mock_api = SimpleNamespace()
    mock_api.get_field_boundaries = lambda field_id: None
    
    def mock_jd_api(token):
        return mock_api
    
    monkeypatch.setattr(game_mod, 'JohnDeereAPI', mock_jd_api)
    
    # Mock pygame/OpenGL initialization
    monkeypatch.setattr('pygame.display.set_caption', lambda x: None)
    monkeypatch.setattr('pygame.display.set_mode', lambda *args, **kwargs: SimpleNamespace())
    monkeypatch.setattr('pygame.time.Clock', lambda: SimpleNamespace())
    monkeypatch.setattr('pygame.font.init', lambda: None)
    monkeypatch.setattr('pygame.font.SysFont', lambda *args: SimpleNamespace(size=lambda x: (10, 10), get_height=lambda: 10))
    
    # Mock OpenGL functions
    import farm_sim.core.game as game_mod_local
    for gl_func in ['glEnable', 'glCullFace', 'glLightfv', 'glClearColor', 'glBlendFunc', 'glMatrixMode', 'glLoadIdentity', 'gluPerspective']:
        monkeypatch.setattr(game_mod_local, gl_func, lambda *args: None)
    
    # Mock other dependencies
    monkeypatch.setattr(game_mod, 'Tractor', lambda x: make_stub_tractor())
    monkeypatch.setattr(game_mod, 'DriverCamera', lambda **kwargs: SimpleNamespace(mode=SimpleNamespace(name='HOOD')))
    monkeypatch.setattr(game_mod, 'AutoPilot', lambda **kwargs: SimpleNamespace(enabled=False, teleport_to_start=lambda x: None, lane_spacing=6.0, build_path=lambda x: None))
    monkeypatch.setattr(game_mod, 'generate_obstacles', lambda *args: [])
    monkeypatch.setattr(game_mod, 'Crop', lambda *args: SimpleNamespace(x=0, z=0, harvested=False))
    
    game = Game(
        800, 600, 50, 50,
        john_deere_token="test_token",
        field_id="test_field_id"
    )
    
    # Should fall back to provided dimensions
    assert game.field_w == 50
    assert game.field_h == 50
