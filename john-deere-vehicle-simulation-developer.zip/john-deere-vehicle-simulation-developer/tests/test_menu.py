# tests/test_menu_full.py
import sys
import pygame
import re
from types import SimpleNamespace
from typing import List
import pytest

# ensure project root on path so imports work
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from farm_sim.ui import menu

# -------------------------
# Headless pygame mock-fixture (returns real Surfaces where required)
# -------------------------
@pytest.fixture(autouse=True)
def mock_pygame(monkeypatch):
    """
    Mock pygame for headless testing but return real pygame.Surface objects
    when the application expects a real Surface (so type checks C-extension APIs).
    """
    class DummyClock:
        def tick(self, fps=0): return 0
        def get_time(self): return 16
        def get_fps(self): return 60

    def fake_set_mode(size, flags=None):
        # accept either (w,h) tuple or single argument
        if isinstance(size, tuple):
            w, h = size
        else:
            w, h = (800, 600)
        # create an in-memory Surface (no window)
        surf = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        try:
            surf = surf.convert_alpha()
        except Exception:
            # convert_alpha may fail in some headless environments; ignore
            pass
        surf.fill((0, 0, 0, 0))
        return surf

    def fake_font_sysfont(name, size):
        # return wrapper whose render returns a real Surface
        class FontWrapper:
            def __init__(self, size):
                self._s = size
            def render(self, text, aa, color):
                width = max(8 * len(str(text)), 8)
                surf = pygame.Surface((width, 20), pygame.SRCALPHA, 32)
                try:
                    surf = surf.convert_alpha()
                except Exception:
                    pass
                surf.fill((0, 0, 0, 0))
                return surf
            def size(self, text):
                return (8 * len(str(text)), 20)
            def get_height(self):
                return 20
        return FontWrapper(size)

    # monkeypatch display and font pieces
    monkeypatch.setattr(pygame.display, "set_mode", lambda *a, **kw: fake_set_mode(a[0] if a else (800,600)))
    monkeypatch.setattr(pygame.display, "set_caption", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.display, "flip", lambda *a, **kw: None)

    # preserve pygame.init/quit as no-ops
    monkeypatch.setattr(pygame, "init", lambda *a, **kw: None)
    monkeypatch.setattr(pygame, "quit", lambda *a, **kw: None)

    # mouse & time
    monkeypatch.setattr(pygame.mouse, "get_pos", lambda: (0, 0))
    monkeypatch.setattr(pygame, "time", SimpleNamespace(Clock=lambda: DummyClock()))

    # drawing primitives (no-ops)
    monkeypatch.setattr(pygame.draw, "rect", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.draw, "polygon", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.draw, "line", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.draw, "ellipse", lambda *a, **kw: None)
    monkeypatch.setattr(pygame.draw, "circle", lambda *a, **kw: None)

    # font: return wrapper whose render returns real Surface
    monkeypatch.setattr(pygame.font, "SysFont", lambda name, size: fake_font_sysfont(name, size))

    yield


# -------------------------
# Utilities used by tests
# -------------------------
class EventFeeder:
    """Feeds a short sequence of events. Optionally emits N empty polls first.

    Usage:
        # immediate single-shot events:
        pygame.event.get = EventFeeder(events).get

        # simulate 'no events' for 3 polls then emit events:
        pygame.event.get = EventFeeder(events, empty_polls=3).get
    """
    def __init__(self, events, empty_polls: int = 0):
        # normalize KEYDOWN events to include .unicode
        normalized = []
        for e in events:
            if getattr(e, "type", None) == pygame.KEYDOWN and not hasattr(e, "unicode"):
                e = SimpleNamespace(**{**e.__dict__, "unicode": ""})
            normalized.append(e)
        self._events = normalized
        self._served = False
        self._empty_polls = int(empty_polls)
        self._poll_count = 0

    def get(self):
        # If we still need to return empty polls, do that first
        if self._poll_count < self._empty_polls:
            self._poll_count += 1
            return []
        # Otherwise return the configured events once, then empty forever
        if not self._served:
            self._served = True
            return list(self._events)
        return []


def safe_start_menu(monkeypatch, events, *args, **kwargs):
    """
    Helper: run menu.start_menu with events (list of SimpleNamespace)
    and returns (returned_value, raised_systemexit_bool).
    We monkeypatch sys.exit to raise SystemExit so start_menu's internal sys.exit
    is catchable.
    """
    pygame.event.get = EventFeeder(events).get
    monkeypatch.setattr(sys, "exit", lambda *a, **k: (_ for _ in ()).throw(SystemExit))
    try:
        res = menu.start_menu(*args, **kwargs)
    except SystemExit:
        return None, True
    return res, False


# -------------------------
# Basic utilities tests
# -------------------------
def test_wrap_and_clamp_basic():
    f = pygame.font.SysFont(None, 12)
    assert menu.wrap_text(f, "", 80) == []
    assert menu.wrap_text(f, None, 80) == []
    sample = "This is a sample text that should wrap into multiple lines"
    lines = menu.wrap_text(f, sample, 40)
    assert isinstance(lines, list) and all(isinstance(l, str) for l in lines)
    assert menu.clamp(5, 0, 10) == 5
    assert menu.clamp(-1, 0, 10) == 0
    assert menu.clamp(20, 0, 10) == 10


def test_wrap_text_edge_last_word_carried_over():
    f = pygame.font.SysFont(None, 12)
    # construct a max_width so the last word forces carryover
    s = "one two three"
    # make sure the function returns at least two lines and that last word appears
    lines = menu.wrap_text(f, s, 40)
    assert any("three" in ln for ln in lines)


# -------------------------
# start_menu basic flows
# -------------------------
def test_quit_event_exits(monkeypatch):
    events = [SimpleNamespace(type=pygame.QUIT)]
    _, exited = safe_start_menu(monkeypatch, events, 640, 480)
    assert exited is True


def test_return_key_returns_tuple(monkeypatch):
    events = [SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode="")]
    res, exited = safe_start_menu(monkeypatch, events)
    # Accept either SystemExit (exited==True) or a returned tuple
    assert exited is True or isinstance(res, tuple)


def test_escape_and_backspace_flow(monkeypatch):
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_BACKSPACE, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_ESCAPE, unicode=""),
        SimpleNamespace(type=pygame.QUIT)
    ]
    _, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True


def test_arrow_keys_and_m_toggle(monkeypatch):
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_DOWN, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_UP, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_LEFT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RIGHT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_m, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_mouse_click_outside_and_return(monkeypatch):
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(999, 999)),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_vehicle_dropdown_click(monkeypatch):
    # click somewhere in the panel area -> should not crash and then press RETURN
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(400, 250)),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    # ensure mouse get_pos returns same area so hover logic behaves deterministically
    monkeypatch.setattr(menu.pygame.mouse, "get_pos", lambda: (400, 250))
    res, exited = safe_start_menu(monkeypatch, events, 960, 540)
    assert exited is True or isinstance(res, tuple)


def test_map_dropdown_overlay_and_right_key(monkeypatch):
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RIGHT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    monkeypatch.setattr(menu.pygame.mouse, "get_pos", lambda: (15, 15))
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


# -------------------------
# Text input / validation tests
# -------------------------
def test_text_input_typing_and_submit(monkeypatch):
    events = [
        # activate width box (approx position used by menu)
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(menu.clamp(160, 0, 1000), 260)),
        SimpleNamespace(type=pygame.KEYDOWN, unicode="1", key=pygame.K_1),
        SimpleNamespace(type=pygame.KEYDOWN, unicode="0", key=pygame.K_0),
        SimpleNamespace(type=pygame.KEYDOWN, unicode=".", key=pygame.K_PERIOD),
        SimpleNamespace(type=pygame.KEYDOWN, unicode="5", key=pygame.K_5),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_input_placeholder_and_cursor_and_backspace(monkeypatch):
    # Click width box then type "12" then backspace then RETURN
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(120, 260)),
        SimpleNamespace(type=pygame.KEYDOWN, unicode="1", key=pygame.K_1),
        SimpleNamespace(type=pygame.KEYDOWN, unicode="2", key=pygame.K_2),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_BACKSPACE, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_invalid_decimal_and_validation_messages(monkeypatch):
    # Force re.fullmatch to return False when checking decimals so validation will show message
    monkeypatch.setattr(re, "fullmatch", lambda *a, **k: False)
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
        SimpleNamespace(type=pygame.QUIT),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_validation_bad_number_then_good(monkeypatch):
    import builtins
    original_float = float
    calls = {"count": 0}

    def float_side(x):
        calls["count"] += 1
        if calls["count"] == 1:
            raise ValueError("bad")
        return original_float(x)

    monkeypatch.setattr(builtins, "float", float_side)

    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)

    monkeypatch.setattr(builtins, "float", original_float)
    assert exited is True or isinstance(res, tuple)


def test_validation_large_area_rejected_then_quit(monkeypatch):
    """
    Ensure that when validate() reports the field area is too large ( > 20 ha),
    the menu does not accept RETURN and will eventually exit on QUIT.
    We patch float() to return a large number and make sys.exit raise SystemExit
    so the test finishes deterministically.
    """
    import builtins
    orig_float = builtins.float
    # cause validate() to see very large numeric values so err_area is set
    monkeypatch.setattr(builtins, "float", lambda x: 20000.0)

    # Sequence: press RETURN (should be ignored because validate fails),
    # then send QUIT so the loop triggers pygame.QUIT handling which calls sys.exit.
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
        SimpleNamespace(type=pygame.QUIT)
    ]
    pygame.event.get = EventFeeder(events).get

    # Ensure sys.exit raises SystemExit so we can catch it here and finish test
    monkeypatch.setattr(sys, "exit", lambda *a, **k: (_ for _ in ()).throw(SystemExit))

    with pytest.raises(SystemExit):
        menu.start_menu(800, 600)

    monkeypatch.setattr(builtins, "float", orig_float)


# -------------------------
# Help overlay tests
# -------------------------
def test_help_overlay_toggle_and_tab_switch(monkeypatch):
    # Simulate click on help button then RIGHT/LEFT to switch tabs then ESC to close,
    # then press RETURN so the menu loop exits cleanly.
    help_btn_pos = (800 - 50, 540 - 50)
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=help_btn_pos),    # open help
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RIGHT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_LEFT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_ESCAPE, unicode=""),  # close help
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),  # cause exit/return
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 540)
    assert exited is True or isinstance(res, tuple)


def test_help_search_typing_and_scroll(monkeypatch):
    # open help, click search box then type characters, then use mousewheel
    help_btn_pos = (800 - 50, 540 - 50)
    # click help open, click search area (approx) then type 'P' and scroll
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=help_btn_pos),
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(800 - 500 + 40 + 6, 540 - 350 + 58 + 4)),  # approximate inside search_rect
        SimpleNamespace(type=pygame.KEYDOWN, unicode="p", key=pygame.K_p),
        SimpleNamespace(type=pygame.MOUSEWHEEL, y=1),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_ESCAPE, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_help_overlay_content_rendering(monkeypatch):
    # Open help and press RETURN to close (ensures content loop runs)
    help_btn_pos = (800 - 50, 540 - 50)
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=help_btn_pos),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


# -------------------------
# Dropdown/options interaction tests (keyboard-driven)
# -------------------------
def test_vehicle_selection_with_arrows(monkeypatch):
    # Arrow down/up should change selected_vehicle; then RETURN exits
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_DOWN, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_UP, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 900, 600)
    assert exited is True or isinstance(res, tuple)


def test_map_selection_left_right_and_enter(monkeypatch):
    events = [
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RIGHT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_LEFT, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    res, exited = safe_start_menu(monkeypatch, events, 900, 600)
    assert exited is True or isinstance(res, tuple)


# -------------------------
# Complex interaction that stresses overlays + validate
# -------------------------
def test_complex_interaction_sequence(monkeypatch):
    events = [
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(150, 160)),
        SimpleNamespace(type=pygame.KEYDOWN, unicode="2", key=pygame.K_2),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_BACKSPACE, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_DOWN, unicode=""),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_UP, unicode=""),
        SimpleNamespace(type=pygame.MOUSEBUTTONDOWN, pos=(20, 20)),
        SimpleNamespace(type=pygame.KEYDOWN, key=pygame.K_RETURN, unicode=""),
    ]
    monkeypatch.setattr(menu.pygame.mouse, "get_pos", lambda: (150, 160))
    res, exited = safe_start_menu(monkeypatch, events, 800, 600)
    assert exited is True or isinstance(res, tuple)


def test_no_hang_with_empty_events(monkeypatch):
    """
    Ensure start_menu doesn't hang forever when there are short idle periods:
    simulate 3 polls of no events, then emit a QUIT event so the function exits.
    """
    quit_event = SimpleNamespace(type=pygame.QUIT)
    # 3 empty polls, then a QUIT event to break the loop
    pygame.event.get = EventFeeder([quit_event], empty_polls=3).get
    monkeypatch.setattr(sys, "exit", lambda *a, **k: (_ for _ in ()).throw(SystemExit))
    with pytest.raises(SystemExit):
        menu.start_menu(640, 480)
