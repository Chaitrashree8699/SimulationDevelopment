import sys, os
import pytest

# --- Add project root to import path ---
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from farm_sim.world.ground import draw_ground


# ---- Mocks for OpenGL ----
class GLMock:
    calls = []
    def __getattr__(self, name):
        def _mock_fn(*args, **kwargs):
            GLMock.calls.append((name, args))
            return None
        return _mock_fn


@pytest.fixture(autouse=True)
def patch_opengl(monkeypatch):
    """Mock OpenGL functions so tests run without a GPU context."""
    mock = GLMock()
    import farm_sim.world.ground as ground
    monkeypatch.setattr(ground, "glIsEnabled", lambda x=None: False)
    for fn in [
        "glDisable", "glEnable", "glColor3f", "glBegin", "glEnd",
        "glVertex3f", "glLineWidth"
    ]:
        monkeypatch.setattr(ground, fn, getattr(mock, fn))
    monkeypatch.setattr(ground, "GRID_SIZE", 1.0)
    GLMock.calls.clear()
    yield mock
    GLMock.calls.clear()


@pytest.fixture
def patch_opengl_culling_enabled(monkeypatch):
    """Mock OpenGL with face culling enabled."""
    mock = GLMock()
    import farm_sim.world.ground as ground
    monkeypatch.setattr(ground, "glIsEnabled", lambda x=None: True)
    for fn in [
        "glDisable", "glEnable", "glColor3f", "glBegin", "glEnd",
        "glVertex3f", "glLineWidth"
    ]:
        monkeypatch.setattr(ground, fn, getattr(mock, fn))
    monkeypatch.setattr(ground, "GRID_SIZE", 1.0)
    GLMock.calls.clear()
    yield mock
    GLMock.calls.clear()


# ---- Tests ----
def test_draw_ground_basic():
    """Ensure draw_ground runs successfully with normal input."""
    draw_ground(10.0, 20.0)
    called_funcs = [fn for fn, _ in GLMock.calls]
    assert "glBegin" in called_funcs
    assert "glEnd" in called_funcs
    assert any(fn == "glColor3f" for fn, _ in GLMock.calls)


def test_draw_ground_zero_values():
    """Should handle zero width/height gracefully."""
    draw_ground(0.0, 0.0)
    assert any(fn == "glBegin" for fn, _ in GLMock.calls)


def test_draw_ground_large_values():
    """Should handle large field dimensions without exceptions."""
    draw_ground(1000.0, 500.0)
    assert any(fn == "glVertex3f" for fn, _ in GLMock.calls)


def test_draw_ground_with_culling_enabled(patch_opengl_culling_enabled):
    """Test ground drawing when face culling is enabled."""
    draw_ground(30.0, 40.0)
    called_funcs = [fn for fn, _ in GLMock.calls]
    assert "glDisable" in called_funcs
    assert "glEnable" in called_funcs
