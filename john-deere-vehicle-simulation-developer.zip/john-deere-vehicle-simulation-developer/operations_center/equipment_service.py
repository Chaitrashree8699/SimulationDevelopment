import os
import requests
import json

from farm_sim.entities.tractor import TRACTOR_SPECS
from .auth import auth_header

# Use sandbox by default; override via env if needed (e.g. JD_ISG_BASE_URL)
BASE_URL = os.getenv("JD_ISG_BASE_URL", "https://sandboxapi.deere.com/isg")
VND = "application/json"


def _get(url: str, *, params: dict | None = None) -> dict:
    """
    Internal helper for GET requests with auth + basic error handling.
    """
    headers = {**auth_header(), "Accept": VND}
    r = requests.get(url, headers=headers, params=params, timeout=30)
    r.raise_for_status()
    return r.json()


# ---------------------------------------------------------------------------
# Equipment READ
# ---------------------------------------------------------------------------

def get_equipment() -> dict:
    """
    Fetch all equipment metadata visible to the current token.
    Wraps: GET /equipment
    """
    url = f"{BASE_URL}/equipment"
    return _get(url)


def get_equipment_by_id(equipment_id: str) -> dict:
    """
    Fetch equipment metadata by its organization-specific ID.
    Wraps: GET /equipment/{id}
    """
    url = f"{BASE_URL}/equipment/{equipment_id}"
    return _get(url)


def get_equipment_make() -> dict:
    """
    Fetch all equipment makes.
    Wraps: GET /equipmentMakes
    """
    url = f"{BASE_URL}/equipmentMakes"
    return _get(url)


def get_equipment_types() -> dict:
    """
    Fetch all equipment ISG types.
    Wraps: GET /equipmentISGTypes
    """
    url = f"{BASE_URL}/equipmentISGTypes"
    return _get(url)


def get_equipment_models() -> dict:
    """
    Fetch equipment models.
    Wraps: GET /equipmentModels
    """
    url = f"{BASE_URL}/equipmentModels"
    return _get(url)


def get_selected_equipment_principal(model_id: int) -> dict:
    """
    Fetch equipment's principal ID by its model ID.
    """
    tractors_ids = []
    equipments = get_equipment()
    for equipment in equipments.get("values"):
        if equipment.get("model").get("id") == str(model_id):
            tractors_ids.append(equipment.get("principalId"))
    if tractors_ids:
        return tractors_ids
    raise ValueError(f"No equipment found with model ID {model_id}")
# ---------------------------------------------------------------------------
# Equipment WRITE
# ---------------------------------------------------------------------------

def ensure_operations_center_tractors(org_id: int) -> None:
    """
    Ensure that Operations Center has equipment entries for the 4
    TRACTOR_SPECS defined in this module.

    - If equipment already exists for a TractorSpec.model_id: log and skip.
    - If not: create a new equipment entry.
    """

    equipment_response = get_equipment()
    equipment_values = equipment_response.get("values", [])

    # Build a set of existing model_ids as strings (to match API return values)
    existing_model_ids: set[str] = set()
    for equipment in equipment_values:
        model = equipment.get("model") or {}
        model_id_raw = model.get("id")
        if model_id_raw:
            existing_model_ids.add(str(model_id_raw))

    # Iterate through our known tractor specs
    for spec in TRACTOR_SPECS:
        model_id_str = str(spec.model_id)

        if model_id_str in existing_model_ids:
            print(
                f"[TRACTOR] Already exists: {spec.key} "
                f"({spec.name}, model_id={spec.model_id})"
            )
            continue

        # Prepare payload for missing tractors
        equipment_payload = {
            "@type": "Machine",
            "name": spec.name,
            "serialNumber": f"sim_{spec.key}",
            "model": {"@type": "EquipmentModel", "id": spec.model_id},
        }

        try:
            location = post_equipment(org_id, equipment_payload)
            print(
                f"[TRACTOR] Created: {spec.key} ({spec.name}, model_id={spec.model_id}) "
                f"→ {location}"
            )
            existing_model_ids.add(model_id_str)
        except Exception as exc:
            print(
                f"[TRACTOR][ERROR] Failed to create {spec.key} "
                f"({spec.name}, model_id={spec.model_id}) → {exc}"
            )


def post_equipment(org_id: int, equipment_data: dict) -> str:
    """
    Create a virtual equipment object in a John Deere Operations Center organization.

    Wraps: POST /organizations/{orgId}/equipment

    Parameters
    ----------
    org_id : int
        Organization ID in Operations Center.
    equipment_data : dict
        JSON body matching Equipment Write API, e.g.:

        {
          "@type": "Machine",
          "name": "Virtual Tractor 1",
          "serialNumber": "sim_tractor_001",
          "model": { "@type": "EquipmentModel", "id": 66280 }
        }

    Returns
    -------
    str
        The Location header containing the newly created equipment resource URL.

    Raises
    ------
    RuntimeError
        If the API returns a non-2xx status or no Location header.
    """
    url = f"{BASE_URL}/organizations/{org_id}/equipment"

    headers = {
        **auth_header(),
        "Accept": VND,
        "Content-Type": VND,
    }

    response = requests.post(url, headers=headers, json=equipment_data, timeout=30)

    # Raise detailed exceptions if the request fails
    try:
        response.raise_for_status()
    except requests.HTTPError as e:
        raise RuntimeError(
            f"Failed to create equipment: {response.status_code} → {response.text}"
        ) from e

    # The API returns the new equipment URL in the Location header
    location = response.headers.get("Location")
    if not location:
        raise RuntimeError("Equipment created but no Location header returned.")

    return location


# ---------------------------------------------------------------------------
# Measurements
# ---------------------------------------------------------------------------


def post_measurements_by_principal(principal_id: str, measurements: list) -> None:
    """
    Post measurements using the (deprecated) Sandbox endpoint:
    POST /equipment/{principalId}/measurements

    """
    url = f"{BASE_URL}/equipment/{principal_id}/measurements"
    headers = {**auth_header(), "Accept": VND, "Content-Type": VND}

    print("[DEBUG] POST", url)
    print("[DEBUG] headers:", headers)
    MAX_CHUNK = 150 # Sandbox may have limits on payload size

    for i in range(0, len(measurements), MAX_CHUNK):
        chunk = measurements[i:i + MAX_CHUNK]
        print(f"[UPLOAD] Sending chunk {i // MAX_CHUNK + 1} with {len(chunk)} measurements")
        # Print the JSON payload being sent (truncated for readability)
        try:
            payload_str = json.dumps(chunk, ensure_ascii=False)
            print("[DEBUG] payload:", payload_str if len(payload_str) < 100 else payload_str[:100] + "...(truncated)")
        except Exception as e:
            print(f"[DEBUG] payload stringify failed: {e}; raw chunk:", chunk)

        r = requests.post(url, headers=headers, json=chunk, timeout=30)

        try:
            r.raise_for_status()
        except requests.HTTPError:
            print("[DEBUG] Status:", r.status_code)
            #print("[DEBUG] Response text:", repr(r.text))
            try:
                print("[DEBUG] JSON:", r.json())
            except Exception:
                print("[DEBUG] No JSON body")
            raise

