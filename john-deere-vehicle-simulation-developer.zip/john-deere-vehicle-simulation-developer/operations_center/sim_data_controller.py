import os
import time

from operations_center.equipment_service import get_selected_equipment_principal, post_measurements_by_principal
from operations_center.oc_measurement_builder import geojson_trace_to_jd_measurements
from .file_service import create_file, upload_file, get_file

def push_simulation(org_id: int, file_path: str) -> str:
    """
    1) Create Deere file record
    2) Upload local file bytes
    3) Return file_id (no machine transfer)
    """
    file_name = os.path.basename(file_path)
    file_id = create_file(org_id, file_name)
    upload_file(file_id, file_path)

    meta = get_file(file_id)
    status = meta.get("status")
    ftype = meta.get("type")
    print(f"File status={status}, type={ftype}")

    return file_id

def push_simulation_sandbox(model_id:int, geojson_path: str) -> None:
    principal_ids = get_selected_equipment_principal(model_id)
    principal_id = principal_ids[0]

    measurements = geojson_trace_to_jd_measurements(geojson_path)
    #measurements = measurements[::5]

    print(f"[UPLOAD] Using principal_id={principal_id} for model_id={model_id}")
    attempts = 1
    for attempt in range(1, attempts + 1):
        print(f"[UPLOAD] Posting measurement batch attempt {attempt}/{attempts}")
        post_measurements_by_principal(principal_id, measurements)
        if attempt < attempts:
            time.sleep(1)
