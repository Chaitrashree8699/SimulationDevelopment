import requests
from .auth import auth_header
from farm_sim.config import ORG_ID

BASE_URL = "https://sandboxapi.deere.com/platform"
VND = "application/vnd.deere.axiom.v3+json"

def get_fields(org_id: int) -> list:
    """Get all fields from John Deere with area information"""
    url = f"{BASE_URL}/organizations/{org_id}/fields"
    headers = {**auth_header(), "Accept": VND}
    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    fields = r.json().get('values', [])
    print(f"Raw field list response: {fields}")
    
    # Get detailed info for each field to fetch area
    for field in fields:
        field_id = field.get('id', '')
        if '/' in field_id:
            field_id = field_id.split('/')[-1]
        try:
            detail_url = f"{BASE_URL}/fields/{field_id}"
            print(f"Fetching field details from: {detail_url}")
            detail_r = requests.get(detail_url, headers=headers, timeout=30)
            print(f"Field detail API response: {detail_r.status_code}")
            if detail_r.status_code == 200:
                detail_data = detail_r.json()
                print(f"Field detail data: {detail_data}")
                area_info = detail_data.get('area', {})
                if area_info and 'value' in area_info:
                    field['area'] = area_info
                    print(f"Found area: {area_info}")
                else:
                    print(f"No area in field details: {area_info}")
            else:
                print(f"Field detail API error: {detail_r.text}")
        except Exception as e:
            print(f"Failed to get area for field {field_id}: {e}")
            pass  # Skip if detail fetch fails
    
    return fields

def get_field_boundaries(field_id: str, org_id: int = None) -> tuple:
    """Get GPS boundary coordinates and area for a field"""
    if org_id is None:
        org_id = int(ORG_ID)
    url = f"{BASE_URL}/organizations/{org_id}/fields/{field_id}/boundaries"
    headers = {**auth_header(), "Accept": VND}
    print(f"Fetching boundaries from: {url}")
    r = requests.get(url, headers=headers, timeout=30)
    print(f"Boundaries API response: {r.status_code}")
    
    if r.status_code != 200:
        print(f"Boundaries API error: {r.text}")
        return [], 0
    
    boundaries = r.json().get('values', [])
    print(f"Raw boundaries response: {boundaries}")
    
    # Extract coordinates and area from first boundary
    if boundaries:
        boundary = boundaries[0]
        area_ha = 0
        
        # Extract area if available
        if 'area' in boundary and 'valueAsDouble' in boundary['area']:
            area_ha = boundary['area']['valueAsDouble']
            print(f"Found area in boundary: {area_ha} ha")
        
        # Check for John Deere format (multipolygons)
        if 'multipolygons' in boundary and boundary['multipolygons']:
            polygon = boundary['multipolygons'][0]
            if 'rings' in polygon and polygon['rings']:
                ring = polygon['rings'][0]
                if 'points' in ring and ring['points']:
                    points = ring['points']
                    gps_points = [(point['lat'], point['lon']) for point in points]
                    print(f"Converted GPS points: {gps_points[:3]}...")
                    return gps_points, area_ha
        # Check for GeoJSON format (fallback)
        elif 'geometry' in boundary:
            coords = boundary['geometry']['coordinates'][0]
            gps_points = [(lat, lon) for lon, lat in coords]  # Convert to (lat, lon)
            print(f"Converted GPS points: {gps_points[:3]}...")
            return gps_points, area_ha
    
    print("No valid boundary geometry found")
    return [], 0
