import os
import json
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional


def _bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Heading from point1 -> point2 in degrees [0, 360)."""
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dlambda = math.radians(lon2 - lon1)

    x = math.sin(dlambda) * math.cos(phi2)
    y = (
        math.cos(phi1) * math.sin(phi2)
        - math.sin(phi1) * math.cos(phi2) * math.cos(dlambda)
    )

    if x == 0.0 and y == 0.0:
        return 0.0

    brng = math.degrees(math.atan2(x, y))
    return (brng + 360.0) % 360.0


def geojson_trace_to_jd_measurements(
    geojson_path: str,
    *,
    base_odometer_km: float = 1000.0,
    base_engine_hours: float = 250.0,
    initial_fuel_pct: float = 80.0,
    fuel_burn_per_km: float = 0.02,   # % per km, very rough
    pto_on: bool = True,
    step_seconds: float = 2.0,        # fallback time delta if we can’t derive from trace
) -> List[Dict[str, Any]]:
    """
    Convert a vehicle_path_*.geojson + matching vehicle_trace_*.json
    into a list of John Deere Operations Center measurement objects.

    * Geometry (lat/lon) comes **only** from the LineString with
      properties.type == "vehicle_path".
    * Speed + sim_time come from the trace JSON.
    * Odometer is integrated from speed (no haversine).
    * Timestamps are synthetic & always in the past to avoid
      'invalid future timestamp' errors in the sandbox.
    """

    # --- derive matching trace path ---
    geo_dir, geo_name = os.path.split(geojson_path)
    trace_name = geo_name.replace("vehicle_path_", "vehicle_trace_").replace(".geojson", ".json")
    trace_path = os.path.join(geo_dir, trace_name)

    if not os.path.isfile(trace_path):
        raise FileNotFoundError(
            f"Trace JSON not found for {geojson_path}. Expected: {trace_path}"
        )

    # --- load GeoJSON (only use the vehicle_path LineString) ---
    with open(geojson_path, "r", encoding="utf-8") as f:
        geo = json.load(f)

    features = geo.get("features", [])
    path_coords = None
    for feat in features:
        props = feat.get("properties", {})
        geom = feat.get("geometry", {})
        if props.get("type") == "vehicle_path" and geom.get("type") == "LineString":
            path_coords = geom.get("coordinates", [])
            break

    if not path_coords or len(path_coords) < 1:
        raise ValueError(f"No valid vehicle_path LineString found in {geojson_path}")

    # GeoJSON coordinates are [lon, lat] → convert to (lat, lon)
    gps_points = [(coord[1], coord[0]) for coord in path_coords]

    # --- load trace JSON ---
    with open(trace_path, "r", encoding="utf-8") as f:
        trace = json.load(f)

    if not isinstance(trace, list) or len(trace) == 0:
        raise ValueError(f"Trace JSON {trace_path} is empty or not a list.")

    # --- Align lengths between gps_points and trace -------------------------
    # We want one trace entry per GPS point.
    n_gps = len(gps_points)
    n_trace = len(trace)

    if n_trace < n_gps:
        # If we have more GPS points than trace entries, extend the trace
        # by copying the last sample and advancing sim_time.
        last = trace[-1]
        last_sim_time = float(last.get("sim_time", 0.0) or 0.0)
        last_speed = float(last.get("speed", 0.0) or 0.0)

        for _ in range(n_trace, n_gps):
            last_sim_time += step_seconds
            trace.append({
                "sim_time": last_sim_time,
                "speed": last_speed,
            })

    elif n_trace > n_gps:
        # If there are more trace entries than GPS points, trim the trace
        trace = trace[:n_gps]

    # Now both lists have the same length and index i matches.
    gps_points = gps_points[:len(trace)]


    # --- synthetic time line based on sim_time ---
    now_utc = datetime.now(timezone.utc)

    sim_time0 = float(trace[0].get("sim_time", 0.0) or 0.0)
    sim_time_last = float(trace[-1].get("sim_time", sim_time0) or sim_time0)
    total_span_sec = max(0.0, sim_time_last - sim_time0)

    # anchor the final point 3 minutes in the past, then walk backward for earlier points
    end_anchor = now_utc - timedelta(minutes=3)
    base_time = end_anchor - timedelta(seconds=total_span_sec)

    measurements_batch: List[Dict[str, Any]] = []

    odometer = float(base_odometer_km)
    fuel_level = float(initial_fuel_pct)

    prev_lat, prev_lon = gps_points[0]

    # Keep track of previous relative sim time for dt computation
    prev_rel_t = 0.0

    for i, ((lat, lon), point) in enumerate(zip(gps_points, trace)):
        # speed from trace (m/s -> kph)
        speed_raw = float(point.get("speed", 0.0))
        speed_kph = max(0.0, speed_raw * 3.6)  # clamp negatives to avoid invalid payloads

        # sim_time in seconds since simulation start
        sim_time = float(point.get("sim_time", 0.0) or 0.0)
        rel_t = max(0.0, sim_time - sim_time0)

        # fallback if sim_time is missing or not strictly increasing
        if i > 0 and rel_t <= prev_rel_t:
            rel_t = prev_rel_t + step_seconds

        dt = rel_t - prev_rel_t
        prev_rel_t = rel_t

        # update odometer from speed * time (km/h * h)
        odometer += speed_kph * (dt / 3600.0)
        fuel_level = max(0.0, fuel_level - (speed_kph * (dt / 3600.0)) * fuel_burn_per_km)

        # engine hours follow total sim time
        engine_hours = base_engine_hours + rel_t / 3600.0

        # heading from previous point → current point
        if i == 0:
            heading = 0.0
        else:
            heading = _bearing_deg(prev_lat, prev_lon, lat, lon)

        prev_lat, prev_lon = lat, lon

        # strictly increasing, always-in-the-past timestamp:
        # base_time + relative sim time
        ts = base_time + timedelta(seconds=rel_t)

        measurement = {
            "timestamp": ts.isoformat(),
            "measurements": [
                {"name": "vehicleSpeed", "value": round(speed_kph, 3), "unit": "kph"},
                {"name": "latitude", "value": lat, "unit": "degrees"},
                {"name": "longitude", "value": lon, "unit": "degrees"},
                {"name": "engineState", "value": "On"},
                {"name": "odometer", "value": round(odometer, 3), "unit": "km"},
                {"name": "engineHours", "value": round(engine_hours, 3), "unit": "hours"},
                {"name": "heading", "value": round(heading, 2), "unit": "degrees"},
                {"name": "fuelLevelPercentage", "value": round(fuel_level, 2), "unit": "percent"},
                {"name": "ptoStatus", "value": "On" if pto_on else "Off"},
            ],
        }

        measurements_batch.append(measurement)

    return measurements_batch
