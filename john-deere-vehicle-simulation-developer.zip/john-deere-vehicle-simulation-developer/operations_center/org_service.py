import requests

_AUTH_EXCEPTION = None

try:
    from .auth import auth_header as _auth_header_impl
except Exception as exc:
    _auth_header_impl = None
    _AUTH_EXCEPTION = exc
else:
    _AUTH_EXCEPTION = None

BASE_URL = "https://sandboxapi.deere.com/platform"
VND = "application/vnd.deere.axiom.v3+json"


def _get(url: str) -> dict:
    if _auth_header_impl is None:
        raise _AUTH_EXCEPTION or RuntimeError("Authorization header unavailable")
    headers = {**_auth_header_impl(), "Accept": VND}
    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()


def get_organization() -> dict:
    """
    Fetch the organization metadata visible to the current token.
    Wraps: GET /organizations
    """
    url = f"{BASE_URL}/organizations"
    return _get(url)


def get_primary_org_id() -> int:
    """
    Return the ID of the first organization in the /organizations response.
    """
    orgs = get_organization()
    values = orgs.get("values") or []

    if not values:
        raise RuntimeError("No organizations found for current token.")

    first = values[0]
    print(f"ORG_Name: {first.get('name')}")
    org_id_raw = first.get("id")
    if org_id_raw is None:
        raise RuntimeError("First organization has no 'id' field.")

    if isinstance(org_id_raw, str):
        org_id_raw = org_id_raw.strip()
        if "/" in org_id_raw:
            org_id_raw = org_id_raw.rsplit("/", 1)[-1]

    try:
        return int(org_id_raw)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"Unexpected organization id format: {org_id_raw!r}") from exc
