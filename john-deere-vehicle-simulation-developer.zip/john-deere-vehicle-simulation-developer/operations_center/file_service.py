import requests
from .auth import auth_header

BASE_URL = "https://sandboxapi.deere.com/platform"
VND = "application/vnd.deere.axiom.v3+json"

def create_file(org_id: int, file_name: str) -> str:
    """Create a new Deere file record and return its ID."""
    url = f"{BASE_URL}/organizations/{org_id}/files"
    headers = {**auth_header(), "Accept": VND, "Content-Type": VND}
    payload = {"name": file_name}
    r = requests.post(url, headers=headers, json=payload, timeout=30)
    r.raise_for_status()
    loc = r.headers.get("Location", "")
    file_id = loc.rsplit("/", 1)[-1]
    print(f"✅ Created file '{file_name}' with ID {file_id}")
    return file_id

def upload_file(file_id: str, file_path: str):
    """Upload local content (raw bytes) to Deere Files API."""
    url = f"{BASE_URL}/files/{file_id}"
    headers = {**auth_header(), "Accept": VND, "Content-Type": "application/octet-stream"}
    with open(file_path, "rb") as f:
        r = requests.put(url, headers=headers, data=f, timeout=120)
    r.raise_for_status()
    print(f"✅ Uploaded file content ({r.status_code}) for ID {file_id}")

def get_file(file_id: str) -> dict:
    """Fetch file metadata (status, type, links)."""
    url = f"{BASE_URL}/files/{file_id}"
    headers = {**auth_header(), "Accept": VND}
    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    return r.json()

    
