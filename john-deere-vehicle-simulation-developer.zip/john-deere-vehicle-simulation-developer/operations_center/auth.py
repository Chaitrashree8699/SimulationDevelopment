"""
operations_center/auth.py

Adds Authorization Code flow with refresh tokens per Deere docs while keeping
client_credentials support as a fallback via env switch `JD_FLOW`.

Env vars used:
  - JD_APP_ID, JD_SECRET
  - JD_AUTH_URL, JD_TOKEN_URL, JD_REDIRECT_URI
  - JD_SCOPES (space or comma separated)
  - JD_FLOW = "auth_code" (default) or "client_credentials"
  - JD_AUDIENCE (optional, for CC only if required by AS)
"""

import os, time, json, base64, requests, re, threading, webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlencode, urlparse, parse_qs
from pathlib import Path
from dotenv import load_dotenv

# Global variables to hold configuration (loaded lazily)
_ENV_LOADED = False
APP_ID = None
SECRET_KEY = None
TOKEN_URL = None
AUTH_URL = None
REDIRECT = None
FLOW = None
AUDIENCE = None
SCOPES_RAW = None
SCOPES_CC = None
SCOPES_AUTH = None

def _load_env():
    """Load .env file and initialize configuration variables (lazy initialization)"""
    global _ENV_LOADED, APP_ID, SECRET_KEY, TOKEN_URL, AUTH_URL, REDIRECT, FLOW, AUDIENCE, SCOPES_RAW, SCOPES_CC, SCOPES_AUTH
    
    if _ENV_LOADED:
        return
    
    # Load .env file
    env_path = Path(__file__).resolve().parents[1] / ".env"
    load_dotenv(env_path)
    
    def _require(name: str) -> str:
        v = os.getenv(name)
        if not v:
            raise RuntimeError(f"Missing env var: {name}")
        return v
    
    # Load required variables
    APP_ID = _require("JD_APP_ID")
    SECRET_KEY = _require("JD_SECRET")
    TOKEN_URL = _require("JD_TOKEN_URL")
    AUTH_URL = os.getenv("JD_AUTH_URL", "").strip()
    REDIRECT = os.getenv("JD_REDIRECT_URI", "").strip()
    
    # Flow selection (default to authorization_code as per Deere docs)
    FLOW = os.getenv("JD_FLOW", "auth_code").strip().lower()
    
    # Optional: audience/resource if your AS requires RFC 8707 resource indicators (CC only)
    AUDIENCE = os.getenv("JD_AUDIENCE", "").strip()
    
    # Raw scopes from env
    SCOPES_RAW = os.getenv("JD_SCOPES", "")
    
    # For client_credentials, offline_access is not valid
    SCOPES_CC = _normalize_scopes(SCOPES_RAW)
    
    # For authorization_code, ensure offline_access is present to receive refresh_token
    SCOPES_AUTH = _ensure_offline_access(SCOPES_RAW)
    
    _ENV_LOADED = True

def _normalize_scopes(raw: str) -> str:
    # Accept comma/space separated, collapse whitespace, dedupe, and drop offline_access for CC
    raw = raw or ""
    parts = [p for p in re.split(r"[,\s]+", raw.strip()) if p]
    # offline_access is not valid for client_credentials
    parts = [p for p in parts if p.lower() != "offline_access"]
    seen = set()
    ordered = []
    for p in parts:
        if p not in seen:
            seen.add(p)
            ordered.append(p)
    return " ".join(ordered)

def _ensure_offline_access(s: str) -> str:
    parts = [p for p in re.split(r"[,\s]+", (s or "").strip()) if p]
    if "offline_access".lower() not in [p.lower() for p in parts]:
        parts.append("offline_access")
    # de-duplicate while keeping order
    seen = set()
    ordered = []
    for p in parts:
        if p not in seen:
            seen.add(p)
            ordered.append(p)
    return " ".join(ordered)

TOKEN_CACHE = Path.home() / ".jd_cc_token.json"
USER_TOKEN_CACHE = Path.home() / ".jd_user_token.json"

def _basic_auth() -> str:
    _load_env()  # Ensure env is loaded
    raw = f"{APP_ID}:{SECRET_KEY}".encode("utf-8")
    return "Basic " + base64.b64encode(raw).decode("ascii")

def _load() -> dict | None:
    if TOKEN_CACHE.exists():
        return json.loads(TOKEN_CACHE.read_text())
    return None

def _save(tok: dict):
    tok["expires_at"] = int(time.time()) + int(tok.get("expires_in", 43200)) - 60
    TOKEN_CACHE.write_text(json.dumps(tok, indent=2))
    try:
        os.chmod(TOKEN_CACHE, 0o600)
    except Exception:
        pass

# ===== Authorization Code Flow (default) =====

def _user_load() -> dict | None:
    if USER_TOKEN_CACHE.exists():
        return json.loads(USER_TOKEN_CACHE.read_text())
    return None

def _user_save(tok: dict):
    # Deere tokens expire in ~12h; use expires_in if present
    tok["expires_at"] = int(time.time()) + int(tok.get("expires_in", 43200)) - 60
    USER_TOKEN_CACHE.write_text(json.dumps(tok, indent=2))
    try:
        os.chmod(USER_TOKEN_CACHE, 0o600)
    except Exception:
        pass

def _exchange_code(code: str) -> dict:
    _load_env()  # Ensure env is loaded
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT,
        "client_id": APP_ID,
        "client_secret": SECRET_KEY,
    }
    r = requests.post(TOKEN_URL, headers=headers, data=data, timeout=60)
    if r.status_code >= 400:
        try:
            err = r.json()
        except Exception:
            err = {"error": "unknown", "error_description": r.text}
        raise RuntimeError(f"Token exchange failed {r.status_code}: {err}")
    tok = r.json()
    _user_save(tok)
    return tok

def _refresh_user_token(refresh_token: str) -> dict:
    _load_env()  # Ensure env is loaded
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "redirect_uri": REDIRECT,
        "client_id": APP_ID,
        "client_secret": SECRET_KEY,
        # Some providers require scopes on refresh; pass same set as initial
        "scope": SCOPES_AUTH,
    }
    r = requests.post(TOKEN_URL, headers=headers, data=data, timeout=60)
    if r.status_code >= 400:
        try:
            err = r.json()
        except Exception:
            err = {"error": "unknown", "error_description": r.text}
        raise RuntimeError(f"Refresh failed {r.status_code}: {err}")
    tok = r.json()
    _user_save(tok)
    return tok

def _random_state() -> str:
    return base64.urlsafe_b64encode(os.urandom(24)).decode("ascii").rstrip("=")

def _start_callback_server(expected_path: str, expected_state: str, timeout: int = 300) -> str:
    _load_env()  # Ensure env is loaded
    received = {"code": None}
    done = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            return  # quiet

        def do_GET(self):
            try:
                parsed = urlparse(self.path)
                if parsed.path != expected_path:
                    self.send_response(404); self.end_headers(); return
                params = parse_qs(parsed.query)
                code = params.get("code", [None])[0]
                state = params.get("state", [None])[0]
                if state != expected_state or not code:
                    self.send_response(400); self.end_headers(); return
                received["code"] = code
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"<html><body><h3>Authorization complete. You may close this window.</h3></body></html>")
            finally:
                done.set()

    # Bind to the host/port in REDIRECT
    u = urlparse(REDIRECT)
    host = u.hostname or "127.0.0.1"
    port = u.port or (443 if u.scheme == "https" else 80)
    httpd = HTTPServer((host, port), Handler)

    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    try:
        if not done.wait(timeout):
            raise TimeoutError("Did not receive OAuth callback in time")
        return received["code"]
    finally:
        httpd.shutdown()
        httpd.server_close()

def _auth_code_flow_access_token() -> str:
    _load_env()  # Ensure env is loaded
    tok = _user_load()
    now = int(time.time())
    if tok and tok.get("expires_at", 0) > now + 10:
        return tok["access_token"]
    if tok and tok.get("refresh_token"):
        tok = _refresh_user_token(tok["refresh_token"])
        return tok["access_token"]

    if not AUTH_URL or not REDIRECT:
        raise RuntimeError("Missing JD_AUTH_URL or JD_REDIRECT_URI for authorization_code flow")

    # Build authorization URL
    state = _random_state()
    params = {
        "response_type": "code",
        "scope": SCOPES_AUTH,
        "client_id": APP_ID,
        "state": state,
        "redirect_uri": REDIRECT,
    }
    auth_uri = f"{AUTH_URL}?{urlencode(params)}"
    try:
        webbrowser.open(auth_uri)
        print("Opened browser for John Deere login…")
    except Exception:
        print("Open this URL in a browser to continue:")
        print(auth_uri)

    # Wait for callback
    code = _start_callback_server(urlparse(REDIRECT).path or "/", state)
    tok = _exchange_code(code)
    return tok["access_token"]

def _fetch_token() -> dict:
    _load_env()  # Ensure env is loaded
    headers = {
        "Authorization": _basic_auth(),
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "grant_type": "client_credentials",
        # Scopes included only if provided via JD_SCOPES.
    }
    if SCOPES_CC:
        data["scope"] = SCOPES_CC
    if AUDIENCE:
        # Some providers expect 'audience', others 'resource'; start with 'audience'
        data["audience"] = AUDIENCE

    r = requests.post(TOKEN_URL, headers=headers, data=data, timeout=30)
    if r.status_code >= 400:
        try:
            err = r.json()
        except Exception:
            err = {"error": "unknown", "error_description": r.text}
        raise RuntimeError(f"Token request failed {r.status_code}: {err}")
    tok = r.json()
    _save(tok)
    return tok

def get_access_token() -> str:
    _load_env()  # Ensure env is loaded
    if FLOW == "client_credentials":
        tok = _load()
        if tok and tok.get("expires_at", 0) > int(time.time()) + 10:
            return tok["access_token"]
        tok = _fetch_token()
        return tok["access_token"]
    else:
        return _auth_code_flow_access_token()

def auth_header() -> dict[str, str]:
    return {"Authorization": f"Bearer {get_access_token()}"}

if __name__ == "__main__":
    _load_env()
    print(f"Flow: {FLOW}")
    if FLOW == "client_credentials":
        if SCOPES_CC:
            print("Using scopes (CC):", SCOPES_CC)
        if AUDIENCE:
            print("Using audience:", AUDIENCE)
    else:
        print("Using scopes (AUTH):", SCOPES_AUTH)
        print("Auth URL:", AUTH_URL)
        print("Redirect URI:", REDIRECT)
    print("Token (first 40):", get_access_token()[:40] + "…")
